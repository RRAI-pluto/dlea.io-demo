import React from 'react';
import { Home, Filter, LayoutGrid, Users, Settings, Moon, LogOut, Book, Brain, Target, Tags, Link, BarChart2, Sun } from 'lucide-react';

interface SidebarProps {
  onNavigate: (view: string) => void;
  activeView: string;
  showNewFunnel: boolean;
  setShowNewFunnel: (show: boolean) => void;
  settingsExpanded: boolean;
  setSettingsExpanded: (expanded: boolean) => void;
  isDarkMode: boolean;
  onDarkModeToggle: () => void;
}

export function Sidebar({
  onNavigate,
  activeView,
  showNewFunnel,
  setShowNewFunnel,
  settingsExpanded,
  setSettingsExpanded,
  isDarkMode,
  onDarkModeToggle
}: SidebarProps) {
  return (
    <div className="fixed left-0 top-0 bottom-0 w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700">
      <div className="flex flex-col h-full">
        <div className="p-6">
          <div className="flex items-center space-x-2">
            <Brain className="w-8 h-8 text-blue-600" />
            <span className="text-xl font-bold text-gray-900 dark:text-white">dlea.io</span>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-1">
          <a 
            href="#"
            onClick={() => onNavigate('dashboard')}
            className={`flex items-center px-4 py-2 rounded-lg ${
              activeView === 'dashboard'
                ? 'bg-blue-600 text-white'
                : 'text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-gray-700'
            }`}
          >
            <Home className="w-5 h-5 mr-3" />
            Home
          </a>

          <a 
            href="#"
            onClick={() => onNavigate('funnel')}
            className={`flex items-center px-4 py-2 rounded-lg ${
              activeView === 'funnel'
                ? 'bg-blue-600 text-white'
                : 'text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-gray-700'
            }`}
          >
            <Filter className="w-5 h-5 mr-3" />
            Funnel Analyst
          </a>

          <a 
            href="#"
            onClick={() => onNavigate('config')}
            className={`flex items-center px-4 py-2 rounded-lg ${
              activeView === 'config'
                ? 'bg-blue-600 text-white'
                : 'text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-gray-700'
            }`}
          >
            <LayoutGrid className="w-5 h-5 mr-3" />
            Project Builder
          </a>

          <a 
            href="#"
            onClick={() => onNavigate('users')}
            className={`flex items-center px-4 py-2 rounded-lg ${
              activeView === 'users'
                ? 'bg-blue-600 text-white'
                : 'text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-gray-700'
            }`}
          >
            <Users className="w-5 h-5 mr-3" />
            Users & Teams
          </a>

          <a 
            href="#"
            onClick={() => onNavigate('tickets')}
            className={`flex items-center px-4 py-2 rounded-lg ${
              activeView === 'tickets'
                ? 'bg-blue-600 text-white'
                : 'text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-gray-700'
            }`}
          >
            <Target className="w-5 h-5 mr-3" />
            Enablement Tickets
          </a>

          <a 
            href="#"
            onClick={() => onNavigate('training')}
            className={`flex items-center px-4 py-2 rounded-lg ${
              activeView === 'training'
                ? 'bg-blue-600 text-white'
                : 'text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-gray-700'
            }`}
          >
            <Book className="w-5 h-5 mr-3" />
            Training
          </a>

          <a 
            href="#"
            onClick={() => onNavigate('reports')}
            className={`flex items-center px-4 py-2 rounded-lg ${
              activeView === 'reports'
                ? 'bg-blue-600 text-white'
                : 'text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-gray-700'
            }`}
          >
            <BarChart2 className="w-5 h-5 mr-3" />
            Reports
          </a>

          <div className="py-4">
            <div className="border-t border-gray-200 dark:border-gray-700"></div>
          </div>

          <div className="space-y-1">
            <button
              onClick={() => setSettingsExpanded(!settingsExpanded)}
              className={`w-full flex items-center justify-between px-4 py-2 rounded-lg ${
                activeView.startsWith('settings-')
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-gray-700'
              }`}
            >
              <div className="flex items-center">
                <Settings className="w-5 h-5 mr-3" />
                Settings
              </div>
            </button>

            {settingsExpanded && (
              <div className="ml-4 space-y-1">
                <a
                  href="#"
                  onClick={() => onNavigate('settings-icp')}
                  className={`flex items-center px-4 py-2 rounded-lg ${
                    activeView === 'settings-icp'
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-gray-700'
                  }`}
                >
                  <Target className="w-4 h-4 mr-3" />
                  ICP Settings
                </a>
                <a
                  href="#"
                  onClick={() => onNavigate('settings-tags')}
                  className={`flex items-center px-4 py-2 rounded-lg ${
                    activeView === 'settings-tags'
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-gray-700'
                  }`}
                >
                  <Tags className="w-4 h-4 mr-3" />
                  Tag Manager
                </a>
                <a
                  href="#"
                  onClick={() => onNavigate('settings-integrations')}
                  className={`flex items-center px-4 py-2 rounded-lg ${
                    activeView === 'settings-integrations'
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-gray-700'
                  }`}
                >
                  <Link className="w-4 h-4 mr-3" />
                  Integrations
                </a>
                <a
                  href="#"
                  onClick={() => onNavigate('settings-gamification')}
                  className={`flex items-center px-4 py-2 rounded-lg ${
                    activeView === 'settings-gamification'
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-gray-700'
                  }`}
                >
                  <Target className="w-4 h-4 mr-3" />
                  Gamification
                </a>
                <a
                  href="#"
                  onClick={() => onNavigate('settings-microlearnings')}
                  className={`flex items-center px-4 py-2 rounded-lg ${
                    activeView === 'settings-microlearnings'
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-700 dark:text-gray-200 hover:bg-blue-50 dark:hover:bg-gray-700'
                  }`}
                >
                  <Brain className="w-4 h-4 mr-3" />
                  Micro-Learnings
                </a>
              </div>
            )}
          </div>
        </nav>

        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <button
              onClick={onDarkModeToggle}
              className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <button className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}