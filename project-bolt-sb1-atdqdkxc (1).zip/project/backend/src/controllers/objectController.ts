import { Request, Response } from 'express';
import { ObjectService } from '../services/objectService';

export class ObjectController {
  private objectService: ObjectService;

  constructor() {
    this.objectService = new ObjectService();
  }

  getFields = async (req: Request, res: Response) => {
    try {
      const { type } = req.params;
      const fields = await this.objectService.getFields(type);
      res.json({ success: true, data: fields });
    } catch (error) {
      res.status(500).json({ success: false, error: 'Failed to fetch fields' });
    }
  };

  createField = async (req: Request, res: Response) => {
    try {
      const { type } = req.params;
      const field = await this.objectService.createField(type, req.body);
      res.status(201).json({ success: true, data: field });
    } catch (error) {
      res.status(500).json({ success: false, error: 'Failed to create field' });
    }
  };

  updateField = async (req: Request, res: Response) => {
    try {
      const { type, id } = req.params;
      const field = await this.objectService.updateField(type, id, req.body);
      if (!field) {
        return res.status(404).json({ success: false, error: 'Field not found' });
      }
      res.json({ success: true, data: field });
    } catch (error) {
      res.status(500).json({ success: false, error: 'Failed to update field' });
    }
  };

  deleteField = async (req: Request, res: Response) => {
    try {
      const { type, id } = req.params;
      const success = await this.objectService.deleteField(type, id);
      if (!success) {
        return res.status(404).json({ success: false, error: 'Field not found' });
      }
      res.json({ success: true, message: 'Field deleted successfully' });
    } catch (error) {
      res.status(500).json({ success: false, error: 'Failed to delete field' });
    }
  };

  updateFieldMappings = async (req: Request, res: Response) => {
    try {
      const { type } = req.params;
      const mappings = await this.objectService.updateFieldMappings(type, req.body);
      res.json({ success: true, data: mappings });
    } catch (error) {
      res.status(500).json({ success: false, error: 'Failed to update field mappings' });
    }
  };
}