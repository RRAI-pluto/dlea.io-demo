import React, { useState, useEffect } from 'react';
import { Book, Video, FileText, Plus, Users, Brain, Target, Tags, Link, BarChart2, User, Download, Settings, Toggle, AlertTriangle, Bot, X } from 'lucide-react';
import { CourseBuilder } from './CourseBuilder';
import { ScormExportModal } from './ScormExportModal';

interface Project {
  id: string;
  title: string;
  description: string;
  type: 'course' | 'assessment' | 'certification';
  thumbnail: string;
  status: 'draft' | 'published' | 'archived';
  author: string;
  lastModified: Date;
  aiGenerated?: boolean;
  assignments?: {
    type: 'user' | 'team';
    id: string;
    name: string;
    dueDate?: Date;
    status: 'assigned' | 'in_progress' | 'completed';
  }[];
}

interface AutomationSettings {
  enabled: boolean;
  frequency: 'daily' | 'weekly' | 'monthly';
  projectTypes: ('course' | 'assessment' | 'certification')[];
  maxProjectsPerCycle: number;
  useAIAssistant: boolean;
}

export function ProjectBuilder() {
  const [showCourseBuilder, setShowCourseBuilder] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'course' | 'assessment' | 'certification'>('all');
  const [showScormModal, setShowScormModal] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [showProjectContent, setShowProjectContent] = useState(false);
  const [projects, setProjects] = useState<Project[]>([
    {
      id: '1',
      title: 'Sales Methodology Mastery',
      description: 'Comprehensive training on modern sales techniques',
      type: 'course',
      thumbnail: 'https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      status: 'published',
      author: 'David Kim',
      lastModified: new Date('2025-01-15'),
      assignments: [
        { type: 'team', id: '1', name: 'Enterprise Sales', dueDate: new Date('2025-02-15'), status: 'assigned' },
        { type: 'user', id: '2', name: 'Michael Rodriguez', dueDate: new Date('2025-02-10'), status: 'in_progress' }
      ]
    },
    {
      id: '2',
      title: 'Product Demo Excellence',
      description: 'Master the art of effective product demonstrations',
      type: 'course',
      thumbnail: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      status: 'draft',
      author: 'Emily Watson',
      lastModified: new Date('2025-01-20')
    },
    {
      id: '3',
      title: 'Sales Certification Program',
      description: 'Official sales methodology certification',
      type: 'certification',
      thumbnail: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      status: 'published',
      author: 'Lisa Johnson',
      lastModified: new Date('2025-01-18')
    }
  ]);

  const [automationSettings, setAutomationSettings] = useState<AutomationSettings>({
    enabled: false,
    frequency: 'weekly',
    projectTypes: ['course', 'assessment'],
    maxProjectsPerCycle: 2,
    useAIAssistant: true
  });

  const [showAutomationSettings, setShowAutomationSettings] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    let automationInterval: NodeJS.Timeout;

    if (automationSettings.enabled) {
      const intervalMap = {
        daily: 24 * 60 * 60 * 1000,
        weekly: 7 * 24 * 60 * 60 * 1000,
        monthly: 30 * 24 * 60 * 60 * 1000
      };

      automationInterval = setInterval(() => {
        generateAIProjects();
      }, intervalMap[automationSettings.frequency]);

      generateAIProjects();
    }

    return () => {
      if (automationInterval) {
        clearInterval(automationInterval);
      }
    };
  }, [automationSettings.enabled, automationSettings.frequency]);

  const generateAIProjects = async () => {
    if (isGenerating) return;
    
    setIsGenerating(true);
    try {
      const numProjects = Math.floor(Math.random() * automationSettings.maxProjectsPerCycle) + 1;
      
      for (let i = 0; i < numProjects; i++) {
        const projectType = automationSettings.projectTypes[
          Math.floor(Math.random() * automationSettings.projectTypes.length)
        ];

        const newProject: Project = {
          id: Date.now().toString() + i,
          title: `AI-Generated ${projectType.charAt(0).toUpperCase() + projectType.slice(1)} ${i + 1}`,
          description: `Automatically generated ${projectType} based on current training needs and performance data.`,
          type: projectType,
          thumbnail: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
          status: 'draft',
          author: 'AI Assistant',
          lastModified: new Date(),
          aiGenerated: true
        };

        setProjects(prev => [...prev, newProject]);
      }

      await new Promise(resolve => setTimeout(resolve, 2000));
    } catch (error) {
      console.error('Error generating AI projects:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const filteredProjects = projects.filter(project => {
    const matchesType = filterType === 'all' || project.type === filterType;
    const matchesSearch = project.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">Project Builder</h1>
              <p className="text-gray-600">Create and manage training content</p>
            </div>
            <div className="flex space-x-4">
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search projects..."
                  className="pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value as any)}
                className="px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Types</option>
                <option value="course">Courses</option>
                <option value="assessment">Assessments</option>
                <option value="certification">Certifications</option>
              </select>
              <button
                onClick={() => setShowAutomationSettings(true)}
                className="flex items-center px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50"
              >
                <Bot className="w-5 h-5 mr-2" />
                AI Automation
              </button>
            </div>
          </div>

          {automationSettings.enabled && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Bot className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">AI Project Automation Active</h3>
                    <p className="text-sm text-gray-600">
                      Generating up to {automationSettings.maxProjectsPerCycle} projects {automationSettings.frequency}
                    </p>
                  </div>
                </div>
                {isGenerating && (
                  <div className="flex items-center text-blue-600">
                    <Bot className="w-5 h-5 mr-2 animate-pulse" />
                    Generating projects...
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map(project => (
              <div key={project.id} className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <div className="relative h-48">
                  <img
                    src={project.thumbnail}
                    alt={project.title}
                    className="w-full h-full object-cover rounded-t-lg"
                  />
                  <div className="absolute top-4 right-4 flex space-x-2">
                    <button
                      onClick={() => {
                        setSelectedProject(project);
                        setShowScormModal(true);
                      }}
                      className="px-3 py-1 bg-white text-blue-600 rounded-lg shadow-sm hover:bg-blue-50 transition-colors flex items-center"
                    >
                      <Download className="w-4 h-4 mr-1" />
                      SCORM
                    </button>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      project.type === 'course' ? 'bg-blue-100 text-blue-800' :
                      project.type === 'assessment' ? 'bg-purple-100 text-purple-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {project.type.charAt(0).toUpperCase() + project.type.slice(1)}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-medium mb-2">{project.title}</h3>
                  <p className="text-gray-600 text-sm mb-4">{project.description}</p>
                  
                  {project.assignments && project.assignments.length > 0 && (
                    <div className="mb-4">
                      <h4 className="text-sm font-medium text-gray-700 mb-2">Assigned to:</h4>
                      <div className="space-y-2">
                        {project.assignments.map((assignment, index) => (
                          <div key={index} className="flex items-center justify-between text-sm">
                            <div className="flex items-center">
                              {assignment.type === 'team' ? (
                                <Users className="w-4 h-4 text-gray-400 mr-2" />
                              ) : (
                                <User className="w-4 h-4 text-gray-400 mr-2" />
                              )}
                              <span>{assignment.name}</span>
                            </div>
                            <div className="flex items-center">
                              {assignment.dueDate && (
                                <span className="text-gray-500 mr-2">
                                  Due {assignment.dueDate.toLocaleDateString()}
                                </span>
                              )}
                              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                                assignment.status === 'completed' ? 'bg-green-100 text-green-800' :
                                assignment.status === 'in_progress' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-blue-100 text-blue-800'
                              }`}>
                                {assignment.status.replace('_', ' ')}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <div className="flex items-center">
                      <Users className="w-4 h-4 mr-1" />
                      <span>{project.author}</span>
                    </div>
                    <span>
                      Updated {project.lastModified.toLocaleDateString()}
                    </span>
                  </div>

                  <div className="mt-4 pt-4 border-t flex justify-between">
                    <button
                      onClick={() => {
                        setSelectedProject(project);
                        setShowProjectContent(true);
                      }}
                      className="flex items-center px-3 py-1.5 text-sm text-blue-600 hover:bg-blue-50 rounded-lg"
                    >
                      <Book className="w-4 h-4 mr-2" />
                      View Content
                    </button>
                    <button
                      onClick={() => {
                        setSelectedProject(project);
                        setShowAssignModal(true);
                      }}
                      className="flex items-center px-3 py-1.5 text-sm text-blue-600 hover:bg-blue-50 rounded-lg"
                    >
                      <Users className="w-4 h-4 mr-2" />
                      Assign Training
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-center mt-8">
            <button
              onClick={() => setShowCourseBuilder(true)}
              className="flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-sm"
            >
              <Plus className="w-5 h-5 mr-2" />
              Create New Project
            </button>
          </div>
        </div>
      </div>

      {showCourseBuilder && <CourseBuilder />}
      
      {showScormModal && selectedProject && (
        <ScormExportModal
          project={selectedProject}
          onClose={() => {
            setShowScormModal(false);
            setSelectedProject(null);
          }}
        />
      )}

      {showAutomationSettings && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg w-[600px] p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold">AI Project Automation</h2>
              <button
                onClick={() => setShowAutomationSettings(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h3 className="font-medium">Enable Automation</h3>
                  <p className="text-sm text-gray-500">Let AI generate projects automatically</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={automationSettings.enabled}
                    onChange={(e) => setAutomationSettings({
                      ...automationSettings,
                      enabled: e.target.checked
                    })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Generation Frequency
                </label>
                <select
                  value={automationSettings.frequency}
                  onChange={(e) => setAutomationSettings({
                    ...automationSettings,
                    frequency: e.target.value as 'daily' | 'weekly' | 'monthly'
                  })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Project Types
                </label>
                <div className="space-y-2">
                  {(['course', 'assessment', 'certification'] as const).map(type => (
                    <label key={type} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={automationSettings.projectTypes.includes(type)}
                        onChange={(e) => {
                          const types = e.target.checked
                            ? [...automationSettings.projectTypes, type]
                            : automationSettings.projectTypes.filter(t => t !== type);
                          setAutomationSettings({
                            ...automationSettings,
                            projectTypes: types
                          });
                        }}
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="ml-2 text-sm text-gray-700">
                        {type.charAt(0).toUpperCase() + type.slice(1)}s
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Maximum Projects Per Cycle
                </label>
                <input
                  type="number"
                  value={automationSettings.maxProjectsPerCycle}
                  onChange={(e) => setAutomationSettings({
                    ...automationSettings,
                    maxProjectsPerCycle: parseInt(e.target.value)
                  })}
                  min="1"
                  max="5"
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h3 className="font-medium">Use AI Assistant</h3>
                  <p className="text-sm text-gray-500">Let AI help customize content</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={automationSettings.useAIAssistant}
                    onChange={(e) => setAutomationSettings({
                      ...automationSettings,
                      useAIAssistant: e.target.checked
                    })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>

              <div className="flex justify-end space-x-4">
                <button
                  onClick={() => setShowAutomationSettings(false)}
                  className="px-4 py-2 text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    setShowAutomationSettings(false);
                    if (automationSettings.enabled) {
                      generateAIProjects();
                    }
                  }}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Save Settings
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}