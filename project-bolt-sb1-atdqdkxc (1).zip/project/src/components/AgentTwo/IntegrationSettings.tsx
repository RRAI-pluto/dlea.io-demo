import React, { useState } from 'react';
import { Settings, Check, AlertTriangle, RefreshCw, Database, Key, Globe, Mail } from 'lucide-react';
import { useConfluence } from '../../hooks/useConfluence';

interface IntegrationConfig {
  type: 'confluence' | 'lms' | 'crm' | 'cms';
  name: string;
  status: 'active' | 'inactive' | 'error';
  icon: React.ReactNode;
}

export function IntegrationSettings() {
  const [confluenceConfig, setConfluenceConfig] = useState({
    baseUrl: '',
    email: '',
    apiKey: ''
  });
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [testResult, setTestResult] = useState<'success' | 'error' | null>(null);

  const { getSpaces, error } = useConfluence(confluenceConfig);

  const integrations: IntegrationConfig[] = [
    { type: 'confluence', name: 'Confluence', status: 'active', icon: <Database className="w-5 h-5" /> },
    { type: 'lms', name: 'Learning Management', status: 'inactive', icon: <Database className="w-5 h-5" /> },
    { type: 'crm', name: 'CRM System', status: 'error', icon: <Database className="w-5 h-5" /> },
    { type: 'cms', name: 'Content Management', status: 'inactive', icon: <Database className="w-5 h-5" /> }
  ];

  const handleTestConnection = async () => {
    setIsTestingConnection(true);
    try {
      await getSpaces();
      setTestResult('success');
    } catch (err) {
      setTestResult('error');
    } finally {
      setIsTestingConnection(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">Integration Settings</h1>
        <p className="text-gray-600">Configure and manage Agent Two's connections to external platforms.</p>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <h2 className="text-lg font-semibold mb-4">Confluence Integration</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Confluence Base URL
            </label>
            <div className="relative">
              <Globe className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={confluenceConfig.baseUrl}
                onChange={(e) => setConfluenceConfig(prev => ({ ...prev, baseUrl: e.target.value }))}
                placeholder="https://your-domain.atlassian.net"
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="email"
                value={confluenceConfig.email}
                onChange={(e) => setConfluenceConfig(prev => ({ ...prev, email: e.target.value }))}
                placeholder="your-email@company.com"
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              API Key
            </label>
            <div className="relative">
              <Key className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="password"
                value={confluenceConfig.apiKey}
                onChange={(e) => setConfluenceConfig(prev => ({ ...prev, apiKey: e.target.value }))}
                placeholder="Enter your API key"
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          <div className="flex items-center space-x-4 pt-4">
            <button
              onClick={handleTestConnection}
              disabled={isTestingConnection}
              className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50"
            >
              {isTestingConnection ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Testing...</span>
                </>
              ) : (
                <>
                  <Settings className="w-4 h-4" />
                  <span>Test Connection</span>
                </>
              )}
            </button>

            {testResult && (
              <div className={`flex items-center space-x-2 ${
                testResult === 'success' ? 'text-green-600' : 'text-red-600'
              }`}>
                {testResult === 'success' ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Connection successful</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-4 h-4" />
                    <span>Connection failed</span>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-lg font-semibold mb-4">Active Integrations</h2>
        <div className="space-y-4">
          {integrations.map((integration) => (
            <div
              key={integration.type}
              className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
            >
              <div className="flex items-center space-x-3">
                {integration.icon}
                <div>
                  <h3 className="font-medium">{integration.name}</h3>
                  <p className="text-sm text-gray-500">Integration Type: {integration.type}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  integration.status === 'active' ? 'bg-green-100 text-green-800' :
                  integration.status === 'error' ? 'bg-red-100 text-red-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {integration.status}
                </span>
                <button className="p-2 text-gray-400 hover:text-gray-600">
                  <Settings className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}