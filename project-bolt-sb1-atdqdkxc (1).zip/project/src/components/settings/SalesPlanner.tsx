import React, { useState } from 'react';
import { DollarSign, Users, Target, BarChart2, Save, Calculator, Calendar, TrendingUp } from 'lucide-react';

interface SalesTarget {
  revenue: number;
  deals: number;
  avgDealSize: number;
  conversionRate: number;
  salesCycle: number;
  teamSize: number;
}

interface SalesMetric {
  label: string;
  value: number;
  prefix?: string;
  suffix?: string;
  icon: React.ReactNode;
}

export function SalesPlanner() {
  const [targets, setTargets] = useState<SalesTarget>({
    revenue: 0,
    deals: 0,
    avgDealSize: 0,
    conversionRate: 0,
    salesCycle: 0,
    teamSize: 0
  });

  const [timeframe, setTimeframe] = useState('quarterly');
  const [hasChanges, setHasChanges] = useState(false);

  const handleInputChange = (field: keyof SalesTarget, value: string) => {
    const numValue = parseFloat(value) || 0;
    setTargets(prev => ({
      ...prev,
      [field]: numValue
    }));
    setHasChanges(true);
  };

  const handleSave = async () => {
    try {
      // Here you would typically save to your backend
      console.log('Saving targets:', targets);
      setHasChanges(false);
    } catch (error) {
      console.error('Error saving targets:', error);
    }
  };

  const calculateMetrics = (): SalesMetric[] => {
    const monthlyRevenue = timeframe === 'quarterly' ? targets.revenue / 3 : targets.revenue / 12;
    const monthlyDeals = timeframe === 'quarterly' ? targets.deals / 3 : targets.deals / 12;
    
    return [
      {
        label: 'Required Monthly Revenue',
        value: monthlyRevenue,
        prefix: '$',
        suffix: 'K',
        icon: <DollarSign className="w-5 h-5 text-green-600" />
      },
      {
        label: 'Required Monthly Deals',
        value: monthlyDeals,
        icon: <Target className="w-5 h-5 text-blue-600" />
      },
      {
        label: 'Deals per Rep',
        value: targets.teamSize ? monthlyDeals / targets.teamSize : 0,
        icon: <Users className="w-5 h-5 text-purple-600" />
      },
      {
        label: 'Required Pipeline',
        value: (monthlyRevenue * (100 / targets.conversionRate)) || 0,
        prefix: '$',
        suffix: 'K',
        icon: <TrendingUp className="w-5 h-5 text-orange-600" />
      }
    ];
  };

  return (
    <div className="max-w-4xl mx-auto py-8">
      <div className="bg-white rounded-lg shadow-sm">
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold">Sales Planner</h1>
              <p className="text-gray-600">Set your baseline sales targets for AI analysis</p>
            </div>
            <div className="flex items-center space-x-4">
              <select
                value={timeframe}
                onChange={(e) => setTimeframe(e.target.value)}
                className="px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="quarterly">Quarterly Targets</option>
                <option value="annual">Annual Targets</option>
              </select>
              <button
                onClick={handleSave}
                disabled={!hasChanges}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </button>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-2 gap-6 mb-8">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Target Revenue ({timeframe === 'quarterly' ? 'Quarter' : 'Year'})
              </label>
              <div className="relative">
                <DollarSign className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="number"
                  value={targets.revenue || ''}
                  onChange={(e) => handleInputChange('revenue', e.target.value)}
                  placeholder="Enter target revenue"
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Target Deals
              </label>
              <div className="relative">
                <Target className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="number"
                  value={targets.deals || ''}
                  onChange={(e) => handleInputChange('deals', e.target.value)}
                  placeholder="Enter target deals"
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Average Deal Size
              </label>
              <div className="relative">
                <Calculator className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="number"
                  value={targets.avgDealSize || ''}
                  onChange={(e) => handleInputChange('avgDealSize', e.target.value)}
                  placeholder="Enter average deal size"
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Conversion Rate (%)
              </label>
              <div className="relative">
                <TrendingUp className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="number"
                  value={targets.conversionRate || ''}
                  onChange={(e) => handleInputChange('conversionRate', e.target.value)}
                  placeholder="Enter conversion rate"
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Sales Cycle (days)
              </label>
              <div className="relative">
                <Calendar className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="number"
                  value={targets.salesCycle || ''}
                  onChange={(e) => handleInputChange('salesCycle', e.target.value)}
                  placeholder="Enter sales cycle length"
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Team Size
              </label>
              <div className="relative">
                <Users className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="number"
                  value={targets.teamSize || ''}
                  onChange={(e) => handleInputChange('teamSize', e.target.value)}
                  placeholder="Enter team size"
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          <div className="border-t pt-8">
            <h2 className="text-lg font-medium mb-4">Calculated Metrics</h2>
            <div className="grid grid-cols-2 gap-6">
              {calculateMetrics().map((metric, index) => (
                <div key={index} className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    {metric.icon}
                    <span className="text-sm text-gray-500">{metric.label}</span>
                  </div>
                  <p className="text-2xl font-bold">
                    {metric.prefix}{Math.round(metric.value).toLocaleString()}{metric.suffix}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}