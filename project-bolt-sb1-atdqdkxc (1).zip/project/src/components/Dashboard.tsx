import React, { useState } from 'react';
import { BarChart2, TrendingUp, Users, DollarSign, ArrowUpRight, ArrowDownRight, Calendar, Filter, Download, ChevronDown, Brain, Zap, Target, PieChart, AlertTriangle, XCircle } from 'lucide-react';

interface LostOpportunity {
  id: string;
  name: string;
  amount: number;
  closeDate: Date;
  reason: string;
  owner: string;
  stage: string;
}

interface LossPattern {
  pattern: string;
  count: number;
  value: number;
  change: number;
  examples: string[];
}

export function Dashboard() {
  const [timeRange, setTimeRange] = useState('30d');
  const [selectedTeam, setSelectedTeam] = useState('all');

  // Sample lost opportunities data
  const lostOpportunities: LostOpportunity[] = [
    {
      id: '1',
      name: 'Enterprise SaaS Solution',
      amount: 450000,
      closeDate: new Date('2025-01-20'),
      reason: 'Competitor pricing',
      owner: 'Sarah Chen',
      stage: 'Proposal'
    },
    {
      id: '2',
      name: 'Global Tech Integration',
      amount: 380000,
      closeDate: new Date('2025-01-18'),
      reason: 'Technical requirements',
      owner: 'Michael Rodriguez',
      stage: 'Technical Review'
    },
    {
      id: '3',
      name: 'Digital Transformation Project',
      amount: 275000,
      closeDate: new Date('2025-01-15'),
      reason: 'Budget constraints',
      owner: 'Emily Watson',
      stage: 'Negotiation'
    }
  ];

  // Loss patterns analysis
  const lossPatterns: LossPattern[] = [
    {
      pattern: 'Technical Requirement Gaps',
      count: 12,
      value: 2450000,
      change: 15,
      examples: ['Missing integration capabilities', 'Complex deployment requirements']
    },
    {
      pattern: 'Competitive Pricing',
      count: 8,
      value: 1850000,
      change: -5,
      examples: ['Lower-cost alternatives', 'Bundled offerings from competitors']
    },
    {
      pattern: 'Budget Timing',
      count: 6,
      value: 1200000,
      change: 10,
      examples: ['Budget freeze', 'Fiscal year alignment issues']
    }
  ];

  const totalLostValue = lostOpportunities.reduce((sum, opp) => sum + opp.amount, 0);

  const metrics = [
    { title: 'Lost Opportunity Value', value: `$${(totalLostValue / 1000).toFixed(1)}K`, change: -12.4, icon: <DollarSign className="w-5 h-5 text-red-600" /> },
    { title: 'Average Loss Stage', value: 'Proposal', change: -2.1, icon: <Target className="w-5 h-5 text-purple-600" /> },
    { title: 'Loss Rate', value: '22.8%', change: 4.7, icon: <TrendingUp className="w-5 h-5 text-orange-600" /> },
    { title: 'Time to Loss', value: '45 days', change: 1.2, icon: <Calendar className="w-5 h-5 text-blue-600" /> }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">Home</h1>
              <p className="text-gray-600">Overview and lost opportunity analysis</p>
            </div>
            <div className="flex space-x-4">
              <div className="relative">
                <select
                  value={selectedTeam}
                  onChange={(e) => setSelectedTeam(e.target.value)}
                  className="appearance-none bg-white border border-gray-200 rounded-lg px-4 py-2 pr-8"
                >
                  <option value="all">All Teams</option>
                  <option value="enterprise">Enterprise</option>
                  <option value="midmarket">Mid-Market</option>
                  <option value="smb">SMB</option>
                </select>
                <ChevronDown className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 transform -translate-y-1/2" />
              </div>
              <div className="relative">
                <select
                  value={timeRange}
                  onChange={(e) => setTimeRange(e.target.value)}
                  className="appearance-none bg-white border border-gray-200 rounded-lg px-4 py-2 pr-8"
                >
                  <option value="7d">Last 7 days</option>
                  <option value="30d">Last 30 days</option>
                  <option value="90d">Last 90 days</option>
                  <option value="1y">Last year</option>
                </select>
                <ChevronDown className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 transform -translate-y-1/2" />
              </div>
              <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <Download className="w-4 h-4" />
                <span>Export</span>
              </button>
            </div>
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            {metrics.map((metric) => (
              <div
                key={metric.title}
                className="bg-white p-6 rounded-lg shadow-sm"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="p-2 bg-gray-50 rounded-lg">
                    {metric.icon}
                  </div>
                  <span className="text-sm text-gray-500">vs last period</span>
                </div>
                <h3 className="text-2xl font-bold mb-1">{metric.value}</h3>
                <div className="flex items-center justify-between">
                  <p className="text-gray-600 text-sm">{metric.title}</p>
                  <div className={`flex items-center ${metric.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {metric.change >= 0 ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                    <span className="text-sm">{Math.abs(metric.change)}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Lost Opportunities and Patterns */}
          <div className="grid grid-cols-2 gap-6">
            {/* Recent Lost Opportunities */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-semibold flex items-center">
                  <XCircle className="w-5 h-5 text-red-600 mr-2" />
                  Recent Lost Opportunities
                </h2>
                <span className="text-red-600 font-medium">
                  ${(totalLostValue / 1000).toFixed(1)}K Total
                </span>
              </div>
              <div className="space-y-4">
                {lostOpportunities.map((opp) => (
                  <div key={opp.id} className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="font-medium">{opp.name}</h3>
                        <p className="text-sm text-gray-500">{opp.owner}</p>
                      </div>
                      <span className="font-medium text-red-600">
                        ${(opp.amount / 1000).toFixed(1)}K
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-500">Lost at {opp.stage}</span>
                      <span className="text-gray-500">
                        {opp.closeDate.toLocaleDateString()}
                      </span>
                    </div>
                    <div className="mt-2 flex items-center">
                      <AlertTriangle className="w-4 h-4 text-orange-500 mr-1" />
                      <span className="text-sm text-orange-600">{opp.reason}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Loss Patterns */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-semibold flex items-center">
                  <Brain className="w-5 h-5 text-purple-600 mr-2" />
                  Recognized Patterns
                </h2>
                <button className="text-sm text-blue-600 hover:text-blue-700">
                  View Details
                </button>
              </div>
              <div className="space-y-4">
                {lossPatterns.map((pattern, index) => (
                  <div key={index} className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="font-medium">{pattern.pattern}</h3>
                        <p className="text-sm text-gray-500">
                          {pattern.count} occurrences
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-red-600">
                          ${(pattern.value / 1000).toFixed(1)}K
                        </div>
                        <div className={`text-sm flex items-center ${
                          pattern.change >= 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {pattern.change >= 0 ? (
                            <ArrowUpRight className="w-3 h-3" />
                          ) : (
                            <ArrowDownRight className="w-3 h-3" />
                          )}
                          <span>{Math.abs(pattern.change)}%</span>
                        </div>
                      </div>
                    </div>
                    <div className="mt-2 space-y-1">
                      {pattern.examples.map((example, i) => (
                        <div key={i} className="flex items-center text-sm text-gray-600">
                          <div className="w-1.5 h-1.5 rounded-full bg-gray-400 mr-2" />
                          {example}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}