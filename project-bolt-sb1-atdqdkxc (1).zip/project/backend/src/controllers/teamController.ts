import { Request, Response } from 'express';
import { TeamService } from '../services/teamService.js';

export class TeamController {
  private teamService: TeamService;

  constructor() {
    this.teamService = new TeamService();
  }

  getTeams = async (req: Request, res: Response) => {
    try {
      const teams = await this.teamService.getTeams();
      res.json({ success: true, data: teams });
    } catch (error) {
      console.error('Error in getTeams:', error);
      res.status(500).json({ success: false, error: 'Failed to fetch teams' });
    }
  };

  getTeamById = async (req: Request, res: Response) => {
    try {
      const team = await this.teamService.getTeamById(req.params.id);
      if (!team) {
        return res.status(404).json({ success: false, error: 'Team not found' });
      }
      res.json({ success: true, data: team });
    } catch (error) {
      console.error('Error in getTeamById:', error);
      res.status(500).json({ success: false, error: 'Failed to fetch team' });
    }
  };

  createTeam = async (req: Request, res: Response) => {
    try {
      const team = await this.teamService.createTeam(req.body);
      res.status(201).json({ success: true, data: team });
    } catch (error) {
      console.error('Error in createTeam:', error);
      res.status(500).json({ success: false, error: 'Failed to create team' });
    }
  };

  updateTeam = async (req: Request, res: Response) => {
    try {
      const team = await this.teamService.updateTeam(req.params.id, req.body);
      if (!team) {
        return res.status(404).json({ success: false, error: 'Team not found' });
      }
      res.json({ success: true, data: team });
    } catch (error) {
      console.error('Error in updateTeam:', error);
      res.status(500).json({ success: false, error: 'Failed to update team' });
    }
  };

  deleteTeam = async (req: Request, res: Response) => {
    try {
      const success = await this.teamService.deleteTeam(req.params.id);
      if (!success) {
        return res.status(404).json({ success: false, error: 'Team not found' });
      }
      res.json({ success: true, message: 'Team deleted successfully' });
    } catch (error) {
      console.error('Error in deleteTeam:', error);
      res.status(500).json({ success: false, error: 'Failed to delete team' });
    }
  };

  getTeamMembers = async (req: Request, res: Response) => {
    try {
      const members = await this.teamService.getTeamMembers(req.params.id);
      res.json({ success: true, data: members });
    } catch (error) {
      console.error('Error in getTeamMembers:', error);
      res.status(500).json({ success: false, error: 'Failed to fetch team members' });
    }
  };

  addTeamMember = async (req: Request, res: Response) => {
    try {
      const { userId, role } = req.body;
      const member = await this.teamService.addTeamMember(req.params.id, userId, role);
      res.status(201).json({ success: true, data: member });
    } catch (error) {
      console.error('Error in addTeamMember:', error);
      res.status(500).json({ success: false, error: 'Failed to add team member' });
    }
  };

  removeTeamMember = async (req: Request, res: Response) => {
    try {
      const success = await this.teamService.removeTeamMember(req.params.id, req.params.userId);
      if (!success) {
        return res.status(404).json({ success: false, error: 'Team member not found' });
      }
      res.json({ success: true, message: 'Team member removed successfully' });
    } catch (error) {
      console.error('Error in removeTeamMember:', error);
      res.status(500).json({ success: false, error: 'Failed to remove team member' });
    }
  };

  getTeamMetrics = async (req: Request, res: Response) => {
    try {
      const metrics = await this.teamService.getTeamMetrics(req.params.id);
      res.json({ success: true, data: metrics });
    } catch (error) {
      console.error('Error in getTeamMetrics:', error);
      res.status(500).json({ success: false, error: 'Failed to fetch team metrics' });
    }
  };

  updateTeamMetrics = async (req: Request, res: Response) => {
    try {
      const metrics = await this.teamService.updateTeamMetrics(req.params.id, req.body);
      res.json({ success: true, data: metrics });
    } catch (error) {
      console.error('Error in updateTeamMetrics:', error);
      res.status(500).json({ success: false, error: 'Failed to update team metrics' });
    }
  };
}