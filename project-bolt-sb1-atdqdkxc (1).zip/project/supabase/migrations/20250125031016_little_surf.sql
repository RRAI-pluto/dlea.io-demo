/*
  # Role-based Access Control System

  1. New Tables
    - `roles`
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `description` (text)
      - `permissions` (jsonb)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
  2. Changes
    - Add `role_id` to `profiles` table
    - Add foreign key constraint
    
  3. Security
    - Enable RLS on `roles` table
    - Add policies for role access
*/

-- Create roles table
CREATE TABLE IF NOT EXISTS roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text,
  permissions jsonb NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add role_id to profiles
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS role_id uuid REFERENCES roles(id);

-- Enable RLS
ALTER TABLE roles ENABLE ROW LEVEL SECURITY;

-- Create default roles
INSERT INTO roles (name, description, permissions) 
VALUES 
  (
    'Super Admin',
    'Full access to all features and data',
    '{
      "dashboard": {"read": true, "write": true},
      "funnel": {"read": true, "write": true},
      "config": {"read": true, "write": true},
      "users": {"read": true, "write": true},
      "tickets": {"read": true, "write": true},
      "reports": {"read": true, "write": true},
      "settings": {"read": true, "write": true},
      "sales_planner": {"read": true, "write": true},
      "all_data": true
    }'
  ),
  (
    'Admin',
    'Access to most features except sales planner',
    '{
      "dashboard": {"read": true, "write": true},
      "funnel": {"read": true, "write": true},
      "config": {"read": true, "write": true},
      "users": {"read": true, "write": true},
      "tickets": {"read": true, "write": true},
      "reports": {"read": true, "write": true},
      "settings": {"read": true, "write": true},
      "sales_planner": {"read": false, "write": false},
      "all_data": true
    }'
  ),
  (
    'Manager',
    'Access to team data and funnels',
    '{
      "dashboard": {"read": true, "write": true},
      "funnel": {"read": true, "write": true},
      "config": {"read": true, "write": true},
      "users": {"read": "team", "write": false},
      "tickets": {"read": "team", "write": true},
      "reports": {"read": true, "write": true},
      "settings": {"read": true, "write": false},
      "sales_planner": {"read": false, "write": false},
      "all_data": false
    }'
  ),
  (
    'User',
    'Access to own data and funnels',
    '{
      "dashboard": {"read": true, "write": false},
      "funnel": {"read": "own", "write": "own"},
      "config": {"read": true, "write": false},
      "users": {"read": "own", "write": false},
      "tickets": {"read": "own", "write": true},
      "reports": {"read": true, "write": false},
      "settings": {"read": false, "write": false},
      "sales_planner": {"read": false, "write": false},
      "all_data": false
    }'
  );

-- Policies for roles table
CREATE POLICY "Super admins can manage roles"
  ON roles
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role_id IN (SELECT id FROM roles WHERE name = 'Super Admin')
    )
  );

CREATE POLICY "Admins can read roles"
  ON roles
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role_id IN (SELECT id FROM roles WHERE name IN ('Admin', 'Super Admin'))
    )
  );

-- Function to check user permissions
CREATE OR REPLACE FUNCTION check_permission(user_id uuid, feature text, action text)
RETURNS boolean AS $$
DECLARE
  user_role_permissions jsonb;
BEGIN
  SELECT r.permissions INTO user_role_permissions
  FROM profiles p
  JOIN roles r ON r.id = p.role_id
  WHERE p.id = user_id;

  IF user_role_permissions->>'all_data' = 'true' THEN
    RETURN true;
  END IF;

  RETURN (user_role_permissions->feature->>action)::boolean;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;