import { Router } from 'express';
import { AIController } from '../controllers/aiController';
import { authMiddleware } from '../middleware/authMiddleware';

const router = Router();
const aiController = new AIController();

// AI Query endpoint
router.post('/query', authMiddleware, aiController.handleQuery);

// Model management
router.get('/models', authMiddleware, aiController.getModels);
router.post('/models', authMiddleware, aiController.createModel);
router.get('/models/:id', authMiddleware, aiController.getModel);
router.put('/models/:id', authMiddleware, aiController.updateModel);
router.delete('/models/:id', authMiddleware, aiController.deleteModel);

// Model performance
router.get('/models/:id/performance', authMiddleware, aiController.getModelPerformance);
router.get('/models/:id/interactions', authMiddleware, aiController.getModelInteractions);

// Specialized endpoints
router.post('/analyze-call', authMiddleware, aiController.analyzeSalesCall);
router.post('/content-suggestions', authMiddleware, aiController.generateContentSuggestions);
router.post('/deal-risks', authMiddleware, aiController.analyzeDealRisks);
router.post('/coaching-insights', authMiddleware, aiController.generateCoachingInsights);

export default router;