import { supabase } from '../lib/supabase';

export interface AIModel {
  id: string;
  name: string;
  description: string;
  type: 'gpt-4' | 'gpt-3.5-turbo';
  purpose: 'sales' | 'support' | 'training';
  config: {
    temperature: number;
    maxTokens: number;
    topP: number;
    frequencyPenalty: number;
    presencePenalty: number;
  };
  prompts: {
    systemPrompt: string;
    examples: Array<{
      input: string;
      output: string;
    }>;
  };
  metadata: Record<string, any>;
  created_at: Date;
  updated_at: Date;
}

export interface AIInteraction {
  id: string;
  model_id: string;
  input: string;
  output: string;
  metadata: {
    timestamp: string;
    latency?: number;
    success?: boolean;
    error?: string;
    tokens?: {
      input: number;
      output: number;
      total: number;
    };
  };
  created_at: Date;
}

export const aiDatabaseService = {
  // Model Management
  models: {
    async create(model: Omit<AIModel, 'id' | 'created_at' | 'updated_at'>) {
      try {
        const { data, error } = await supabase
          .from('ai_models')
          .insert([model])
          .select()
          .single();

        if (error) throw error;
        return data;
      } catch (error) {
        console.error('Error creating AI model:', error);
        throw error;
      }
    },

    async get(id: string) {
      try {
        const { data, error } = await supabase
          .from('ai_models')
          .select('*')
          .eq('id', id)
          .single();

        if (error) throw error;
        return data;
      } catch (error) {
        console.error('Error getting AI model:', error);
        throw error;
      }
    },

    async list() {
      try {
        const { data, error } = await supabase
          .from('ai_models')
          .select('*')
          .order('created_at', { ascending: false });

        if (error) throw error;
        return data;
      } catch (error) {
        console.error('Error listing AI models:', error);
        throw error;
      }
    },

    async update(id: string, updates: Partial<AIModel>) {
      try {
        const { data, error } = await supabase
          .from('ai_models')
          .update(updates)
          .eq('id', id)
          .select()
          .single();

        if (error) throw error;
        return data;
      } catch (error) {
        console.error('Error updating AI model:', error);
        throw error;
      }
    },

    async delete(id: string) {
      try {
        const { error } = await supabase
          .from('ai_models')
          .delete()
          .eq('id', id);

        if (error) throw error;
      } catch (error) {
        console.error('Error deleting AI model:', error);
        throw error;
      }
    }
  },

  // Interaction Management
  interactions: {
    async create(interaction: Omit<AIInteraction, 'id' | 'created_at'>) {
      try {
        const { data, error } = await supabase
          .from('ai_interactions')
          .insert([interaction])
          .select()
          .single();

        if (error) throw error;
        return data;
      } catch (error) {
        console.error('Error creating AI interaction:', error);
        throw error;
      }
    },

    async list(modelId: string, options?: {
      startDate?: Date;
      endDate?: Date;
      limit?: number;
      offset?: number;
    }) {
      try {
        let query = supabase
          .from('ai_interactions')
          .select('*')
          .eq('model_id', modelId);

        if (options?.startDate) {
          query = query.gte('created_at', options.startDate.toISOString());
        }

        if (options?.endDate) {
          query = query.lte('created_at', options.endDate.toISOString());
        }

        query = query.order('created_at', { ascending: false });

        if (options?.limit) {
          query = query.limit(options.limit);
        }

        if (options?.offset) {
          query = query.range(options.offset, options.offset + (options.limit || 10) - 1);
        }

        const { data, error } = await query;

        if (error) throw error;
        return data;
      } catch (error) {
        console.error('Error listing AI interactions:', error);
        throw error;
      }
    },

    async getStats(modelId: string, timeRange: { start: Date; end: Date }) {
      try {
        const { data, error } = await supabase
          .from('ai_interactions')
          .select('*')
          .eq('model_id', modelId)
          .gte('created_at', timeRange.start.toISOString())
          .lte('created_at', timeRange.end.toISOString());

        if (error) throw error;

        // Calculate statistics
        const totalInteractions = data.length;
        const successfulInteractions = data.filter(i => i.metadata?.success).length;
        const totalTokens = data.reduce((acc, i) => acc + (i.metadata?.tokens?.total || 0), 0);
        const avgLatency = data.reduce((acc, i) => acc + (i.metadata?.latency || 0), 0) / totalInteractions;

        return {
          totalInteractions,
          successRate: (successfulInteractions / totalInteractions) * 100,
          totalTokens,
          avgLatency,
          timeRange
        };
      } catch (error) {
        console.error('Error getting AI interaction stats:', error);
        throw error;
      }
    }
  },

  // Training Data Management
  trainingData: {
    async save(modelId: string, data: {
      input: string;
      output: string;
      category?: string;
      metadata?: Record<string, any>;
    }) {
      try {
        const { error } = await supabase
          .from('ai_training_data')
          .insert([{
            model_id: modelId,
            input: data.input,
            output: data.output,
            category: data.category,
            metadata: data.metadata
          }]);

        if (error) throw error;
      } catch (error) {
        console.error('Error saving AI training data:', error);
        throw error;
      }
    },

    async get(modelId: string, category?: string) {
      try {
        let query = supabase
          .from('ai_training_data')
          .select('*')
          .eq('model_id', modelId);

        if (category) {
          query = query.eq('category', category);
        }

        const { data, error } = await query;

        if (error) throw error;
        return data;
      } catch (error) {
        console.error('Error getting AI training data:', error);
        throw error;
      }
    }
  },

  // Performance Monitoring
  performance: {
    async logMetric(modelId: string, metric: {
      name: string;
      value: number;
      metadata?: Record<string, any>;
    }) {
      try {
        const { error } = await supabase
          .from('ai_metrics')
          .insert([{
            model_id: modelId,
            name: metric.name,
            value: metric.value,
            metadata: metric.metadata,
            timestamp: new Date().toISOString()
          }]);

        if (error) throw error;
      } catch (error) {
        console.error('Error logging AI metric:', error);
        throw error;
      }
    },

    async getMetrics(modelId: string, options: {
      metricName?: string;
      startDate?: Date;
      endDate?: Date;
    }) {
      try {
        let query = supabase
          .from('ai_metrics')
          .select('*')
          .eq('model_id', modelId);

        if (options.metricName) {
          query = query.eq('name', options.metricName);
        }

        if (options.startDate) {
          query = query.gte('timestamp', options.startDate.toISOString());
        }

        if (options.endDate) {
          query = query.lte('timestamp', options.endDate.toISOString());
        }

        const { data, error } = await query.order('timestamp', { ascending: true });

        if (error) throw error;
        return data;
      } catch (error) {
        console.error('Error getting AI metrics:', error);
        throw error;
      }
    }
  }
};