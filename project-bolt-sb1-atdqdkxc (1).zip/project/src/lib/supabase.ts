import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  },
  db: {
    schema: 'public'
  }
});

// Auth helpers
export const getUser = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
};

export const getProfile = async () => {
  const user = await getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from('profiles')
    .select('*, teams(*), roles(*)')
    .eq('id', user.id)
    .single();

  if (error) throw error;
  return data;
};

// Team helpers
export const getTeams = async () => {
  const { data, error } = await supabase
    .from('teams')
    .select('*, users_teams(profiles(*))');

  if (error) throw error;
  return data;
};

// Project helpers
export const getProjects = async () => {
  const { data, error } = await supabase
    .from('projects')
    .select('*, assignments(*)');

  if (error) throw error;
  return data;
};

// Notification helpers
export const getNotifications = async () => {
  const user = await getUser();
  if (!user) return [];

  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
};

export const markNotificationAsRead = async (notificationId: string) => {
  const { error } = await supabase
    .from('notifications')
    .update({ status: 'read' })
    .eq('id', notificationId);

  if (error) throw error;
};

// Gamification helpers
export const getGamificationSettings = async () => {
  const { data, error } = await supabase
    .from('gamification_settings')
    .select('*')
    .single();

  if (error) throw error;
  return data;
};

export const getUserPoints = async () => {
  const user = await getUser();
  if (!user) return [];

  const { data, error } = await supabase
    .from('user_points')
    .select('*, point_rules(*)')
    .eq('user_id', user.id)
    .order('earned_at', { ascending: false });

  if (error) throw error;
  return data;
};

// Storage helpers
export const uploadAvatar = async (file: File) => {
  const user = await getUser();
  if (!user) throw new Error('No user');

  const fileExt = file.name.split('.').pop();
  const filePath = `${user.id}/avatar.${fileExt}`;

  const { error: uploadError } = await supabase.storage
    .from('avatars')
    .upload(filePath, file, { upsert: true });

  if (uploadError) throw uploadError;

  const { data: { publicUrl } } = supabase.storage
    .from('avatars')
    .getPublicUrl(filePath);

  const { error: updateError } = await supabase
    .from('profiles')
    .update({ avatar_url: publicUrl })
    .eq('id', user.id);

  if (updateError) throw updateError;

  return publicUrl;
};

// AI Model helpers
export const getAIModels = async () => {
  const { data, error } = await supabase
    .from('ai_models')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
};

export const getAIModelById = async (id: string) => {
  const { data, error } = await supabase
    .from('ai_models')
    .select('*')
    .eq('id', id)
    .single();

  if (error) throw error;
  return data;
};

export const createAIModel = async (model: any) => {
  const { data, error } = await supabase
    .from('ai_models')
    .insert([model])
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const updateAIModel = async (id: string, updates: any) => {
  const { data, error } = await supabase
    .from('ai_models')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const deleteAIModel = async (id: string) => {
  const { error } = await supabase
    .from('ai_models')
    .delete()
    .eq('id', id);

  if (error) throw error;
};

export const getAIModelInteractions = async (modelId: string) => {
  const { data, error } = await supabase
    .from('ai_interactions')
    .select('*')
    .eq('model_id', modelId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
};

export const createAIModelInteraction = async (interaction: any) => {
  const { data, error } = await supabase
    .from('ai_interactions')
    .insert([interaction])
    .select()
    .single();

  if (error) throw error;
  return data;
};