import { v4 as uuidv4 } from 'uuid';

// Sales Call Transcripts
export const salesCallTranscripts = [
  {
    id: uuidv4(),
    title: 'Enterprise SaaS Discovery Call',
    date: '2025-01-15',
    speaker: 'Sarah Chen',
    customer: 'InnovateTech Solutions',
    duration: 45,
    content: `
Rep: Thanks for taking the time today. I'd love to understand more about your current challenges with sales enablement.

Customer: Well, our main issue is scaling our sales team effectively. We've grown from 10 to 50 reps in the last year, and maintaining consistency in our sales process has become challenging.

Rep: That's a significant growth. Could you tell me more about how this inconsistency is impacting your business?

Customer: Sure. Our ramp time for new reps has increased from 3 to 6 months, and we're seeing wide variations in how different reps present our solution. Some focus too much on features without connecting to value.

Rep: I understand. What steps have you taken so far to address these challenges?

Customer: We've tried creating playbooks and doing more training sessions, but it's hard to track adoption and measure effectiveness.

Rep: Got it. What would success look like for you in 12 months?

Customer: Ideally, we'd reduce ramp time back to 3 months, have consistent messaging across the team, and improve our win rates by at least 20%.
    `
  },
  {
    id: uuidv4(),
    title: 'Technical Solution Review',
    date: '2025-01-18',
    speaker: 'Michael Rodriguez',
    customer: 'DataFlow Systems',
    duration: 60,
    content: `
Rep: Today we'll go through the technical architecture and integration requirements. What specific areas would you like to focus on?

Customer: Security is our top concern, followed by the API integration capabilities.

Rep: Perfect. Let's start with our security framework. We're SOC 2 Type II compliant and use end-to-end encryption for all data...

Customer: What about custom SSO options?

Rep: Yes, we support SAML 2.0 and can integrate with any identity provider. We've done implementations with Okta, Azure AD, and custom SAML providers.

Customer: That's good. For the API, we need to sync data with our CRM and BI tools.

Rep: Our REST API supports real-time bidirectional sync. Here's an example of how the integration would work...
    `
  }
];

// Content Library
export const contentLibrary = [
  {
    id: uuidv4(),
    title: 'Enterprise Security Whitepaper',
    type: 'document',
    format: 'pdf',
    tags: ['security', 'enterprise', 'technical'],
    usage: {
      views: 245,
      downloads: 89,
      shares: 34
    },
    effectiveness: {
      winRate: 0.68,
      dealSize: 125000
    }
  },
  {
    id: uuidv4(),
    title: 'ROI Calculator Template',
    type: 'tool',
    format: 'xlsx',
    tags: ['value-proposition', 'sales-tools'],
    usage: {
      views: 189,
      downloads: 156,
      shares: 45
    },
    effectiveness: {
      winRate: 0.72,
      dealSize: 95000
    }
  }
];

// Training Materials
export const trainingMaterials = [
  {
    id: uuidv4(),
    title: 'Value Selling Fundamentals',
    type: 'course',
    modules: [
      {
        title: 'Understanding Customer Pain Points',
        duration: 30,
        content: [
          'Identifying business challenges',
          'Quantifying impact',
          'Connecting solutions to value'
        ]
      },
      {
        title: 'Discovery Question Framework',
        duration: 45,
        content: [
          'Strategic questioning techniques',
          'Active listening skills',
          'Follow-up strategies'
        ]
      }
    ],
    effectiveness: {
      completionRate: 0.85,
      satisfactionScore: 4.6,
      skillImprovement: 0.32
    }
  }
];

// Sales Performance Data
export const salesPerformanceData = [
  {
    id: uuidv4(),
    repName: 'Sarah Chen',
    metrics: {
      revenue: 1250000,
      deals: 12,
      avgDealSize: 104166,
      winRate: 0.68,
      salesCycle: 45
    },
    activities: {
      calls: 145,
      emails: 890,
      meetings: 56,
      proposals: 18
    },
    trends: {
      revenueGrowth: 0.15,
      dealSizeGrowth: 0.08,
      winRateChange: 0.05
    }
  },
  {
    id: uuidv4(),
    repName: 'Michael Rodriguez',
    metrics: {
      revenue: 980000,
      deals: 8,
      avgDealSize: 122500,
      winRate: 0.72,
      salesCycle: 52
    },
    activities: {
      calls: 128,
      emails: 760,
      meetings: 48,
      proposals: 11
    },
    trends: {
      revenueGrowth: 0.12,
      dealSizeGrowth: 0.15,
      winRateChange: -0.02
    }
  }
];

// Customer Interaction Patterns
export const interactionPatterns = [
  {
    id: uuidv4(),
    pattern: 'Technical Deep Dives',
    characteristics: [
      'Multiple technical stakeholders',
      'Detailed architecture discussions',
      'Security focus'
    ],
    effectiveness: {
      conversionRate: 0.45,
      salesCycle: 65,
      dealSize: 150000
    },
    recommendations: [
      'Involve solutions engineer early',
      'Prepare technical documentation',
      'Focus on compliance requirements'
    ]
  },
  {
    id: uuidv4(),
    pattern: 'Value-Driven Discussions',
    characteristics: [
      'Executive stakeholders',
      'ROI focused',
      'Strategic alignment'
    ],
    effectiveness: {
      conversionRate: 0.58,
      salesCycle: 45,
      dealSize: 200000
    },
    recommendations: [
      'Lead with business outcomes',
      'Prepare case studies',
      'Focus on strategic value'
    ]
  }
];

// Loss Patterns
export const lossPatterns = [
  {
    id: uuidv4(),
    pattern: 'Technical Requirements Gap',
    frequency: 0.25,
    avgDealSize: 125000,
    characteristics: [
      'Missing integration capabilities',
      'Performance requirements not met',
      'Security compliance issues'
    ],
    recommendations: [
      'Earlier technical discovery',
      'Clear technical requirements document',
      'Competitive feature comparison'
    ]
  },
  {
    id: uuidv4(),
    pattern: 'Budget/Timing Mismatch',
    frequency: 0.30,
    avgDealSize: 95000,
    characteristics: [
      'Budget cycle misalignment',
      'Pricing objections',
      'Urgent need vs. implementation timeline'
    ],
    recommendations: [
      'Earlier budget qualification',
      'Flexible payment terms',
      'ROI-based pricing discussions'
    ]
  }
];

// AI Training Examples
export const aiTrainingExamples = [
  {
    id: uuidv4(),
    type: 'call_analysis',
    input: `
Rep: Can you tell me about your current challenges?
Customer: We're struggling with long sales cycles and inconsistent messaging.
Rep: What impact is this having on your business?
Customer: We're probably losing about 20% in potential revenue, and our team is frustrated.
    `,
    analysis: {
      strengths: [
        'Good initial discovery question',
        'Followed up on impact'
      ],
      weaknesses: [
        'Could have quantified the revenue impact more precisely',
        'Missing exploration of root causes'
      ],
      suggestions: [
        'Ask about specific examples of messaging inconsistency',
        'Explore current sales cycle length with specific numbers',
        'Discuss impact on team morale and retention'
      ]
    }
  },
  {
    id: uuidv4(),
    type: 'content_recommendation',
    context: {
      dealStage: 'Technical Evaluation',
      industry: 'Financial Services',
      painPoints: ['Security', 'Compliance', 'Integration']
    },
    recommendations: [
      {
        title: 'Security Whitepaper',
        reason: 'Addresses primary concern in regulated industry',
        timing: 'Share before technical deep dive'
      },
      {
        title: 'Integration Guide',
        reason: 'Demonstrates technical feasibility',
        timing: 'Review during solution design'
      }
    ]
  }
];