import React, { useState } from 'react';
import { Save, Plus, X } from 'lucide-react';
import { databaseService } from '../../services/databaseService';

interface ICPCriteria {
  id: string;
  category: string;
  attributes: string[];
}

export function ICPSettings() {
  const [criteria, setCriteria] = useState<ICPCriteria[]>([
    {
      id: '1',
      category: 'Company Size',
      attributes: ['500-1000 employees', '1000-5000 employees', '5000+ employees']
    },
    {
      id: '2',
      category: 'Industry',
      attributes: ['SaaS', 'Financial Services', 'Healthcare', 'Manufacturing']
    },
    {
      id: '3',
      category: 'Technology Stack',
      attributes: ['Salesforce', 'Workday', 'ServiceNow', 'Oracle']
    },
    {
      id: '4',
      category: 'Budget',
      attributes: ['$100k-$500k', '$500k-$1M', '$1M+']
    }
  ]);

  const [newCategory, setNewCategory] = useState('');
  const [newAttribute, setNewAttribute] = useState('');
  const [editingCategoryId, setEditingCategoryId] = useState<string | null>(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  const addCategory = () => {
    if (!newCategory.trim()) return;
    setCriteria([
      ...criteria,
      {
        id: Date.now().toString(),
        category: newCategory,
        attributes: []
      }
    ]);
    setNewCategory('');
    setHasUnsavedChanges(true);
  };

  const addAttribute = (categoryId: string) => {
    if (!newAttribute.trim()) return;
    setCriteria(criteria.map(cat => {
      if (cat.id === categoryId) {
        return {
          ...cat,
          attributes: [...cat.attributes, newAttribute]
        };
      }
      return cat;
    }));
    setNewAttribute('');
    setEditingCategoryId(null);
    setHasUnsavedChanges(true);
  };

  const removeAttribute = (categoryId: string, attribute: string) => {
    setCriteria(criteria.map(cat => {
      if (cat.id === categoryId) {
        return {
          ...cat,
          attributes: cat.attributes.filter(attr => attr !== attribute)
        };
      }
      return cat;
    }));
    setHasUnsavedChanges(true);
  };

  const removeCategory = (categoryId: string) => {
    setCriteria(criteria.filter(cat => cat.id !== categoryId));
    setHasUnsavedChanges(true);
  };

  const handleSaveChanges = async () => {
    try {
      const settings = {
        criteria: criteria
      };

      const { error } = await databaseService.settings.saveICPSettings(settings);
      
      if (error) throw error;
      
      setHasUnsavedChanges(false);
      alert('ICP settings saved successfully');
    } catch (error) {
      console.error('Error saving ICP settings:', error);
      alert('Failed to save settings. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-sm">
          <div className="p-6 border-b">
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-2xl font-bold">Ideal Customer Profile</h1>
                <p className="text-gray-600">Define your target customer characteristics</p>
              </div>
              <button
                onClick={handleSaveChanges}
                disabled={!hasUnsavedChanges}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </button>
            </div>
          </div>

          <div className="p-6">
            <div className="mb-6">
              <div className="flex items-center space-x-4 mb-4">
                <input
                  type="text"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  placeholder="Add new category..."
                  className="flex-1 px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  onClick={addCategory}
                  disabled={!newCategory.trim()}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="space-y-6">
              {criteria.map((category) => (
                <div key={category.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-medium">{category.category}</h3>
                    <button
                      onClick={() => removeCategory(category.id)}
                      className="text-gray-400 hover:text-red-500"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {category.attributes.map((attribute, index) => (
                      <div
                        key={index}
                        className="flex items-center bg-gray-100 px-3 py-1 rounded-full"
                      >
                        <span className="text-sm">{attribute}</span>
                        <button
                          onClick={() => removeAttribute(category.id, attribute)}
                          className="ml-2 text-gray-400 hover:text-red-500"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>

                  {editingCategoryId === category.id ? (
                    <div className="flex items-center space-x-2">
                      <input
                        type="text"
                        value={newAttribute}
                        onChange={(e) => setNewAttribute(e.target.value)}
                        placeholder="Add new attribute..."
                        className="flex-1 px-3 py-1.5 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <button
                        onClick={() => addAttribute(category.id)}
                        disabled={!newAttribute.trim()}
                        className="px-3 py-1.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 disabled:opacity-50"
                      >
                        Add
                      </button>
                      <button
                        onClick={() => setEditingCategoryId(null)}
                        className="px-3 py-1.5 border border-gray-200 text-sm rounded-lg hover:bg-gray-50"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setEditingCategoryId(category.id)}
                      className="text-blue-600 text-sm hover:text-blue-700"
                    >
                      + Add Attribute
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}