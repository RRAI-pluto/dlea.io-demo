import OpenAI from 'openai';
import dotenv from 'dotenv';
import { MemoryService } from './memoryService';

dotenv.config();

export interface AIResponse {
  content: string;
  type: 'text' | 'analysis' | 'suggestion';
  confidence?: number;
  metadata?: Record<string, any>;
}

export class OpenAIService {
  private openai: OpenAI;
  private memoryService: MemoryService;

  constructor(apiKey?: string) {
    this.openai = new OpenAI({
      apiKey: apiKey || process.env.OPENAI_API_KEY
    });
    this.memoryService = new MemoryService();
  }

  async testConnection(apiKey?: string): Promise<boolean> {
    try {
      const testOpenai = new OpenAI({
        apiKey: apiKey || this.openai.apiKey
      });

      // Test the connection by making a simple API call
      await testOpenai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: 'test' }],
        max_tokens: 5
      });

      return true;
    } catch (error) {
      console.error('OpenAI connection test failed:', error);
      throw error;
    }
  }

  // ... (keep existing methods)
}