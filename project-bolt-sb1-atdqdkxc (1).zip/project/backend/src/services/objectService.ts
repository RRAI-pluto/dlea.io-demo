import { pool } from '../config/database';

export class ObjectService {
  async getFields(objectType: string) {
    const result = await pool.query(
      'SELECT * FROM object_fields WHERE object_type = $1 ORDER BY created_at DESC',
      [objectType]
    );
    return result.rows;
  }

  async createField(objectType: string, fieldData: any) {
    const result = await pool.query(
      `INSERT INTO object_fields 
       (object_type, name, label, type, required, mapped_to) 
       VALUES ($1, $2, $3, $4, $5, $6) 
       RETURNING *`,
      [
        objectType,
        fieldData.name,
        fieldData.label,
        fieldData.type,
        fieldData.required,
        fieldData.mappedTo
      ]
    );
    return result.rows[0];
  }

  async updateField(objectType: string, fieldId: string, fieldData: any) {
    const result = await pool.query(
      `UPDATE object_fields 
       SET name = $1, label = $2, type = $3, required = $4, mapped_to = $5
       WHERE id = $6 AND object_type = $7
       RETURNING *`,
      [
        fieldData.name,
        fieldData.label,
        fieldData.type,
        fieldData.required,
        fieldData.mappedTo,
        fieldId,
        objectType
      ]
    );
    return result.rows[0] || null;
  }

  async deleteField(objectType: string, fieldId: string) {
    const result = await pool.query(
      'DELETE FROM object_fields WHERE id = $1 AND object_type = $2',
      [fieldId, objectType]
    );
    return result.rowCount > 0;
  }

  async updateFieldMappings(objectType: string, mappings: any[]) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      for (const mapping of mappings) {
        await client.query(
          `UPDATE object_fields 
           SET mapped_to = $1, mapped = true
           WHERE id = $2 AND object_type = $3`,
          [mapping.mappedTo, mapping.fieldId, objectType]
        );
      }

      await client.query('COMMIT');
      return true;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }
}