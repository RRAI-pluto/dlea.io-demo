import { pool } from '../config/database.js';

export interface Team {
  id: string;
  name: string;
  description: string;
  metrics?: {
    deals: number;
    revenue: number;
    quota: number;
    conversion: number;
  };
  created_at: Date;
  updated_at: Date;
}

export class TeamService {
  async getTeams(): Promise<Team[]> {
    const result = await pool.query(
      'SELECT * FROM teams ORDER BY created_at DESC'
    );
    return result.rows;
  }

  async getTeamById(id: string): Promise<Team | null> {
    const result = await pool.query(
      'SELECT * FROM teams WHERE id = $1',
      [id]
    );
    return result.rows[0] || null;
  }

  async createTeam(teamData: Partial<Team>): Promise<Team> {
    const result = await pool.query(
      `INSERT INTO teams (name, description, metrics)
       VALUES ($1, $2, $3)
       RETURNING *`,
      [teamData.name, teamData.description, teamData.metrics || {}]
    );
    return result.rows[0];
  }

  async updateTeam(id: string, updates: Partial<Team>): Promise<Team | null> {
    const result = await pool.query(
      `UPDATE teams
       SET name = COALESCE($1, name),
           description = COALESCE($2, description),
           metrics = COALESCE($3, metrics),
           updated_at = NOW()
       WHERE id = $4
       RETURNING *`,
      [updates.name, updates.description, updates.metrics, id]
    );
    return result.rows[0] || null;
  }

  async deleteTeam(id: string): Promise<boolean> {
    const result = await pool.query(
      'DELETE FROM teams WHERE id = $1',
      [id]
    );
    return result.rowCount > 0;
  }

  async getTeamMembers(teamId: string) {
    const result = await pool.query(
      `SELECT u.*, ut.role
       FROM users_teams ut
       JOIN profiles u ON u.id = ut.user_id
       WHERE ut.team_id = $1`,
      [teamId]
    );
    return result.rows;
  }

  async addTeamMember(teamId: string, userId: string, role: string) {
    const result = await pool.query(
      `INSERT INTO users_teams (team_id, user_id, role)
       VALUES ($1, $2, $3)
       RETURNING *`,
      [teamId, userId, role]
    );
    return result.rows[0];
  }

  async removeTeamMember(teamId: string, userId: string): Promise<boolean> {
    const result = await pool.query(
      'DELETE FROM users_teams WHERE team_id = $1 AND user_id = $2',
      [teamId, userId]
    );
    return result.rowCount > 0;
  }

  async getTeamMetrics(teamId: string) {
    const result = await pool.query(
      'SELECT metrics FROM teams WHERE id = $1',
      [teamId]
    );
    return result.rows[0]?.metrics || null;
  }

  async updateTeamMetrics(teamId: string, metrics: any) {
    const result = await pool.query(
      `UPDATE teams
       SET metrics = $1,
           updated_at = NOW()
       WHERE id = $2
       RETURNING metrics`,
      [metrics, teamId]
    );
    return result.rows[0]?.metrics || null;
  }
}