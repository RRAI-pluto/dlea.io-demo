import React from 'react';
import { Check, CheckCheck } from 'lucide-react';

interface Message {
  id: string;
  content: string;
  sender: {
    id: string;
    name: string;
    avatar?: string;
    platform: 'dlea' | 'slack';
  };
  timestamp: Date;
  status: 'sent' | 'delivered' | 'read';
}

interface Conversation {
  id: string;
  participants: Array<{
    id: string;
    name: string;
    avatar?: string;
    platform: 'dlea' | 'slack';
  }>;
  platform: 'dlea' | 'slack';
  channelName?: string;
}

interface MessageListProps {
  messages: Message[];
  conversation: Conversation;
  messagesEndRef: React.RefObject<HTMLDivElement>;
}

export function MessageList({ messages, conversation, messagesEndRef }: MessageListProps) {
  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getStatusIcon = (status: Message['status']) => {
    switch (status) {
      case 'read':
        return <CheckCheck className="w-4 h-4 text-blue-600" />;
      case 'delivered':
        return <CheckCheck className="w-4 h-4 text-gray-400" />;
      case 'sent':
        return <Check className="w-4 h-4 text-gray-400" />;
      default:
        return null;
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {messages.map((message) => {
        const isCurrentUser = message.sender.id === 'current-user';
        const isSlackMessage = message.sender.platform === 'slack';

        return (
          <div
            key={message.id}
            className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[70%] flex items-end space-x-2 ${
                isCurrentUser ? 'flex-row-reverse space-x-reverse' : 'flex-row'
              }`}
            >
              {!isCurrentUser && (
                <div className="flex flex-col items-center space-y-1">
                  <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                    {message.sender.avatar ? (
                      <img
                        src={message.sender.avatar}
                        alt={message.sender.name}
                        className="w-8 h-8 rounded-full"
                      />
                    ) : (
                      <span className="text-sm font-medium text-gray-600">
                        {message.sender.name.charAt(0)}
                      </span>
                    )}
                  </div>
                  {isSlackMessage && (
                    <div className="px-1.5 py-0.5 bg-purple-100 rounded text-[10px] text-purple-600 font-medium">
                      Slack
                    </div>
                  )}
                </div>
              )}
              <div>
                {!isCurrentUser && (
                  <p className="text-xs text-gray-500 mb-1">{message.sender.name}</p>
                )}
                <div
                  className={`rounded-lg p-3 ${
                    isCurrentUser
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-800'
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                </div>
                <div
                  className={`flex items-center space-x-2 mt-1 text-xs ${
                    isCurrentUser ? 'justify-end' : 'justify-start'
                  }`}
                >
                  <span className="text-gray-500">
                    {formatTime(message.timestamp)}
                  </span>
                  {isCurrentUser && getStatusIcon(message.status)}
                </div>
              </div>
            </div>
          </div>
        );
      })}
      <div ref={messagesEndRef} />
    </div>
  );
}