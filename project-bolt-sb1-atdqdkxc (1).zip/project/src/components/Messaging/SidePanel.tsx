import React, { useState } from 'react';
import { X, Search, Users, Hash, Plus, Check } from 'lucide-react';

interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: string;
}

interface SidePanelProps {
  onClose: () => void;
  isNewConversation: boolean;
  onStartConversation: (participants: User[]) => void;
  onCreateChannel: (channelData: { name: string; description: string; members: User[] }) => void;
}

export function SidePanel({ onClose, isNewConversation, onStartConversation, onCreateChannel }: SidePanelProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUsers, setSelectedUsers] = useState<User[]>([]);
  const [channelName, setChannelName] = useState('');
  const [channelDescription, setChannelDescription] = useState('');
  const [editingCategoryId, setEditingCategoryId] = useState<string | null>(null);

  // Dummy users data - replace with actual user data from your system
  const users: User[] = [
    { id: '1', name: 'Sarah Chen', email: 'sarah@example.com', role: 'Sales Manager' },
    { id: '2', name: 'Michael Rodriguez', email: 'michael@example.com', role: 'Account Executive' },
    { id: '3', name: 'Emily Watson', email: 'emily@example.com', role: 'Sales Representative' },
    { id: '4', name: 'David Kim', email: 'david@example.com', role: 'Sales Engineer' },
    // Add more users to test scrolling
    { id: '5', name: 'Lisa Johnson', email: 'lisa@example.com', role: 'Sales Manager' },
    { id: '6', name: 'James Wilson', email: 'james@example.com', role: 'Account Executive' },
    { id: '7', name: 'Maria Garcia', email: 'maria@example.com', role: 'Sales Representative' },
    { id: '8', name: 'Robert Lee', email: 'robert@example.com', role: 'Sales Engineer' },
    { id: '9', name: 'Jennifer Brown', email: 'jennifer@example.com', role: 'Sales Manager' },
    { id: '10', name: 'William Davis', email: 'william@example.com', role: 'Account Executive' }
  ];

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleUser = (user: User) => {
    if (selectedUsers.find(u => u.id === user.id)) {
      setSelectedUsers(selectedUsers.filter(u => u.id !== user.id));
    } else {
      setSelectedUsers([...selectedUsers, user]);
    }
  };

  const handleSubmit = () => {
    if (isNewConversation) {
      onStartConversation(selectedUsers);
    } else {
      onCreateChannel({
        name: channelName,
        description: channelDescription,
        members: selectedUsers
      });
    }
  };

  return (
    <div className="w-72 border-l flex flex-col bg-white">
      {/* Fixed Header */}
      <div className="p-4 border-b">
        <div className="flex justify-between items-center">
          <h3 className="font-medium">
            {isNewConversation ? 'New Conversation' : 'Create Channel'}
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto">
        {!isNewConversation && (
          <div className="p-4 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Channel Name
              </label>
              <div className="relative">
                <Hash className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={channelName}
                  onChange={(e) => setChannelName(e.target.value)}
                  placeholder="e.g. sales-team"
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                value={channelDescription}
                onChange={(e) => setChannelDescription(e.target.value)}
                placeholder="What's this channel about?"
                rows={3}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        )}

        <div className="p-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            {isNewConversation ? 'Add People' : 'Add Members'}
          </label>
          <div className="relative mb-4">
            <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by name or email"
              className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {selectedUsers.length > 0 && (
            <div className="mb-4">
              <div className="text-sm text-gray-500 mb-2">Selected:</div>
              <div className="flex flex-wrap gap-2">
                {selectedUsers.map(user => (
                  <div
                    key={user.id}
                    className="flex items-center space-x-1 px-2 py-1 bg-blue-50 text-blue-700 rounded-full text-sm"
                  >
                    <span>{user.name}</span>
                    <button
                      onClick={() => toggleUser(user)}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-2">
            {filteredUsers.map(user => (
              <button
                key={user.id}
                onClick={() => toggleUser(user)}
                className={`w-full flex items-center p-2 rounded-lg hover:bg-gray-50 ${
                  selectedUsers.find(u => u.id === user.id) ? 'bg-blue-50' : ''
                }`}
              >
                <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center mr-3">
                  {user.avatar ? (
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="w-8 h-8 rounded-full"
                    />
                  ) : (
                    <span className="text-sm font-medium text-gray-600">
                      {user.name.charAt(0)}
                    </span>
                  )}
                </div>
                <div className="flex-1 text-left">
                  <div className="font-medium text-sm">{user.name}</div>
                  <div className="text-xs text-gray-500">{user.role}</div>
                </div>
                {selectedUsers.find(u => u.id === user.id) && (
                  <Check className="w-5 h-5 text-blue-600" />
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Fixed Footer */}
      <div className="p-4 border-t bg-white">
        <button
          onClick={handleSubmit}
          disabled={
            isNewConversation
              ? selectedUsers.length === 0
              : !channelName.trim() || selectedUsers.length === 0
          }
          className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
        >
          <Plus className="w-4 h-4" />
          <span>
            {isNewConversation ? 'Start Conversation' : 'Create Channel'}
          </span>
        </button>
      </div>
    </div>
  );
}