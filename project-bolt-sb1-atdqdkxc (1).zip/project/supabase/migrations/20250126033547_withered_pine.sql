/*
  # Add Memory System
  
  1. New Tables
    - `memories` table for storing conversation history and context
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `type` (text, enum: conversation/context/insight)
      - `content` (jsonb)
      - `metadata` (jsonb)
      - `created_at` (timestamptz)
      - `expires_at` (timestamptz)
  
  2. Security
    - Enable RLS on memories table
    - Add policies for user access control
  
  3. Maintenance
    - Add function for cleaning up expired memories
    - Add indexes for performance
*/

-- Create memories table
CREATE TABLE IF NOT EXISTS memories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('conversation', 'context', 'insight')),
  content jsonb NOT NULL,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz
);

-- Create index for faster queries
CREATE INDEX memories_user_type_idx ON memories (user_id, type);
CREATE INDEX memories_expires_idx ON memories (expires_at);

-- Enable RLS
ALTER TABLE memories ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own memories"
  ON memories
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create their own memories"
  ON memories
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Function to clean up expired memories
CREATE OR REPLACE FUNCTION cleanup_expired_memories()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM memories WHERE expires_at < NOW();
END;
$$;

-- Create a scheduled job to clean up expired memories
DO $$
BEGIN
  -- Check if pgcron extension is available
  IF EXISTS (
    SELECT 1 FROM pg_extension WHERE extname = 'pg_cron'
  ) THEN
    -- Create the scheduled job if pg_cron is available
    PERFORM cron.schedule(
      'cleanup-expired-memories',
      '0 0 * * *', -- Run daily at midnight
      'SELECT cleanup_expired_memories()'
    );
  END IF;
END
$$;