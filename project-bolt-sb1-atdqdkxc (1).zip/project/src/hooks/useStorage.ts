import { useState } from 'react';
import { storageService, StorageFile } from '../services/storageService';

export function useStorage() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const uploadFile = async (file: File, path: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await storageService.uploadFile(file, path);
      return result;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to upload file'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const getFileUrl = async (path: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const url = await storageService.getFileUrl(path);
      return url;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to get file URL'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const listFiles = async (folder: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const files = await storageService.listFiles(folder);
      return files;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to list files'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const deleteFile = async (path: string) => {
    setIsLoading(true);
    setError(null);
    try {
      await storageService.deleteFile(path);
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to delete file'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const moveFile = async (fromPath: string, toPath: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await storageService.moveFile(fromPath, toPath);
      return result;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to move file'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const createFolder = async (path: string) => {
    setIsLoading(true);
    setError(null);
    try {
      await storageService.createFolder(path);
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to create folder'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const getFileMetadata = async (path: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const metadata = await storageService.getFileMetadata(path);
      return metadata;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to get file metadata'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    uploadFile,
    getFileUrl,
    listFiles,
    deleteFile,
    moveFile,
    createFolder,
    getFileMetadata,
    isLoading,
    error
  };
}