import request from 'supertest';
import { app } from '../../app';

describe('API Integration Tests', () => {
  describe('Health Check', () => {
    it('should return 200 OK', async () => {
      const response = await request(app).get('/health');
      expect(response.status).toBe(200);
      expect(response.body.status).toBe('healthy');
    });
  });

  describe('AI Endpoints', () => {
    it('should analyze sales call', async () => {
      const response = await request(app)
        .post('/api/ai/analyze-call')
        .send({ transcript: 'test transcript' });
      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
    });

    it('should generate content suggestions', async () => {
      const response = await request(app)
        .post('/api/ai/content-suggestions')
        .send({ context: { type: 'sales', stage: 'discovery' } });
      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
    });
  });

  describe('Authentication', () => {
    it('should require authentication for protected routes', async () => {
      const response = await request(app).get('/api/users');
      expect(response.status).toBe(401);
    });
  });
});