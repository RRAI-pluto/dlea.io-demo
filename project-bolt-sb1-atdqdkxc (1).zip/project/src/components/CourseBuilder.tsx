import React, { useState } from 'react';
import { Layout, Book, Video, FileText, Plus, X, FlipHorizontal as DragHorizontal, Clock, Settings, Save } from 'lucide-react';

interface Section {
  id: string;
  title: string;
  lessons: Lesson[];
}

interface Lesson {
  id: string;
  title: string;
  type: 'video' | 'text' | 'quiz';
  duration: number;
}

export function CourseBuilder() {
  const [courseTitle, setCourseTitle] = useState('');
  const [courseDescription, setCourseDescription] = useState('');
  const [sections, setSections] = useState<Section[]>([
    {
      id: '1',
      title: 'Introduction',
      lessons: [
        { id: '1', title: 'Welcome to the Course', type: 'video', duration: 5 },
        { id: '2', title: 'Course Overview', type: 'text', duration: 10 }
      ]
    }
  ]);

  const addSection = () => {
    setSections([
      ...sections,
      {
        id: Date.now().toString(),
        title: 'New Section',
        lessons: []
      }
    ]);
  };

  const addLesson = (sectionId: string) => {
    setSections(sections.map(section => {
      if (section.id === sectionId) {
        return {
          ...section,
          lessons: [
            ...section.lessons,
            {
              id: Date.now().toString(),
              title: 'New Lesson',
              type: 'video',
              duration: 0
            }
          ]
        };
      }
      return section;
    }));
  };

  const removeSection = (sectionId: string) => {
    setSections(sections.filter(section => section.id !== sectionId));
  };

  const removeLesson = (sectionId: string, lessonId: string) => {
    setSections(sections.map(section => {
      if (section.id === sectionId) {
        return {
          ...section,
          lessons: section.lessons.filter(lesson => lesson.id !== lessonId)
        };
      }
      return section;
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-sm">
          {/* Course Header */}
          <div className="p-6 border-b">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold">Create New Course</h1>
              <div className="flex space-x-4">
                <button className="px-4 py-2 text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50">
                  Preview
                </button>
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
                  <Save className="w-4 h-4 mr-2" />
                  Save Course
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Course Title
                </label>
                <input
                  type="text"
                  value={courseTitle}
                  onChange={(e) => setCourseTitle(e.target.value)}
                  placeholder="Enter course title"
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Category
                </label>
                <select className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option>Web Development</option>
                  <option>Data Science</option>
                  <option>Business Analytics</option>
                  <option>Leadership</option>
                </select>
              </div>
            </div>

            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Course Description
              </label>
              <textarea
                value={courseDescription}
                onChange={(e) => setCourseDescription(e.target.value)}
                rows={4}
                placeholder="Enter course description"
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Course Content */}
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-medium">Course Content</h2>
              <button
                onClick={addSection}
                className="flex items-center px-4 py-2 text-blue-600 border border-blue-200 rounded-lg hover:bg-blue-50"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Section
              </button>
            </div>

            <div className="space-y-4">
              {sections.map((section) => (
                <div key={section.id} className="border border-gray-200 rounded-lg">
                  <div className="p-4 bg-gray-50 border-b flex items-center justify-between">
                    <div className="flex items-center">
                      <DragHorizontal className="w-5 h-5 text-gray-400 mr-2" />
                      <input
                        type="text"
                        value={section.title}
                        onChange={(e) => {
                          setSections(sections.map(s => 
                            s.id === section.id ? { ...s, title: e.target.value } : s
                          ));
                        }}
                        className="bg-transparent border-none focus:outline-none font-medium"
                      />
                    </div>
                    <button
                      onClick={() => removeSection(section.id)}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="p-4">
                    <div className="space-y-3">
                      {section.lessons.map((lesson) => (
                        <div
                          key={lesson.id}
                          className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                        >
                          <div className="flex items-center">
                            <DragHorizontal className="w-5 h-5 text-gray-400 mr-2" />
                            {lesson.type === 'video' && <Video className="w-5 h-5 text-blue-500 mr-2" />}
                            {lesson.type === 'text' && <FileText className="w-5 h-5 text-green-500 mr-2" />}
                            <input
                              type="text"
                              value={lesson.title}
                              onChange={(e) => {
                                setSections(sections.map(s => {
                                  if (s.id === section.id) {
                                    return {
                                      ...s,
                                      lessons: s.lessons.map(l =>
                                        l.id === lesson.id ? { ...l, title: e.target.value } : l
                                      )
                                    };
                                  }
                                  return s;
                                }));
                              }}
                              className="bg-transparent border-none focus:outline-none"
                            />
                          </div>
                          <div className="flex items-center space-x-4">
                            <div className="flex items-center text-gray-500">
                              <Clock className="w-4 h-4 mr-1" />
                              <span className="text-sm">{lesson.duration} min</span>
                            </div>
                            <button className="text-gray-400 hover:text-gray-600">
                              <Settings className="w-5 h-5" />
                            </button>
                            <button
                              onClick={() => removeLesson(section.id, lesson.id)}
                              className="text-gray-400 hover:text-gray-600"
                            >
                              <X className="w-5 h-5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                    <button
                      onClick={() => addLesson(section.id)}
                      className="mt-3 flex items-center px-4 py-2 text-sm text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Lesson
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}