import React, { useState } from 'react';
import { Save, Plus, Trash2, ArrowRight, AlertTriangle, RefreshCw, Settings } from 'lucide-react';

interface Field {
  id: string;
  name: string;
  label: string;
  type: string;
  required: boolean;
  mapped: boolean;
  mappedTo?: string;
  isCustom?: boolean;
}

interface ObjectManagerProps {
  objectType: 'account' | 'contact' | 'opportunity';
}

export function ObjectManager({ objectType }: ObjectManagerProps) {
  const [fields, setFields] = useState<Field[]>(() => {
    // Default Salesforce fields based on object type
    const defaultFields: Field[] = [];
    
    if (objectType === 'account') {
      defaultFields.push(
        { id: '1', name: 'Name', label: 'Account Name', type: 'text', required: true, mapped: false },
        { id: '2', name: 'Industry', label: 'Industry', type: 'picklist', required: false, mapped: false },
        { id: '3', name: 'Type', label: 'Account Type', type: 'picklist', required: false, mapped: false },
        { id: '4', name: 'BillingAddress', label: 'Billing Address', type: 'address', required: false, mapped: false },
        { id: '5', name: 'Phone', label: 'Phone', type: 'phone', required: false, mapped: false },
        { id: '6', name: 'Website', label: 'Website', type: 'url', required: false, mapped: false },
        { id: '7', name: 'AnnualRevenue', label: 'Annual Revenue', type: 'currency', required: false, mapped: false },
        { id: '8', name: 'NumberOfEmployees', label: 'Employees', type: 'number', required: false, mapped: false },
        { id: '9', name: 'Description', label: 'Description', type: 'textarea', required: false, mapped: false }
      );
    } else if (objectType === 'contact') {
      defaultFields.push(
        { id: '1', name: 'Salutation', label: 'Salutation', type: 'picklist', required: false, mapped: false },
        { id: '2', name: 'FirstName', label: 'First Name', type: 'text', required: false, mapped: false },
        { id: '3', name: 'LastName', label: 'Last Name', type: 'text', required: true, mapped: false },
        { id: '4', name: 'AccountId', label: 'Account Name', type: 'lookup', required: false, mapped: false },
        { id: '5', name: 'Title', label: 'Title', type: 'text', required: false, mapped: false },
        { id: '6', name: 'Department', label: 'Department', type: 'text', required: false, mapped: false },
        { id: '7', name: 'Email', label: 'Email', type: 'email', required: false, mapped: false },
        { id: '8', name: 'Phone', label: 'Phone', type: 'phone', required: false, mapped: false },
        { id: '9', name: 'MobilePhone', label: 'Mobile', type: 'phone', required: false, mapped: false },
        { id: '10', name: 'ReportsToId', label: 'Reports To', type: 'lookup', required: false, mapped: false },
        { id: '11', name: 'MailingAddress', label: 'Mailing Address', type: 'address', required: false, mapped: false },
        { id: '12', name: 'LeadSource', label: 'Lead Source', type: 'picklist', required: false, mapped: false }
      );
    } else {
      defaultFields.push(
        { id: '1', name: 'Name', label: 'Opportunity Name', type: 'text', required: true, mapped: false },
        { id: '2', name: 'AccountId', label: 'Account Name', type: 'lookup', required: true, mapped: false },
        { id: '3', name: 'Amount', label: 'Amount', type: 'currency', required: false, mapped: false },
        { id: '4', name: 'CloseDate', label: 'Close Date', type: 'date', required: true, mapped: false },
        { id: '5', name: 'Stage', label: 'Stage', type: 'picklist', required: true, mapped: false },
        { id: '6', name: 'Probability', label: 'Probability (%)', type: 'percent', required: false, mapped: false },
        { id: '7', name: 'Type', label: 'Opportunity Type', type: 'picklist', required: false, mapped: false },
        { id: '8', name: 'LeadSource', label: 'Lead Source', type: 'picklist', required: false, mapped: false },
        { id: '9', name: 'NextStep', label: 'Next Step', type: 'text', required: false, mapped: false },
        { id: '10', name: 'Description', label: 'Description', type: 'textarea', required: false, mapped: false }
      );
    }
    
    return defaultFields;
  });

  const [showNewFieldForm, setShowNewFieldForm] = useState(false);
  const [newField, setNewField] = useState<Partial<Field>>({
    name: '',
    label: '',
    type: 'text',
    required: false,
    mapped: false,
    isCustom: true
  });

  const [isSyncing, setIsSyncing] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  const handleFieldMapping = (fieldId: string, mappedTo: string) => {
    setFields(fields.map(field => {
      if (field.id === fieldId) {
        return {
          ...field,
          mapped: !!mappedTo,
          mappedTo
        };
      }
      return field;
    }));
    setHasUnsavedChanges(true);
  };

  const handleAddCustomField = () => {
    if (!newField.name || !newField.label) return;

    const field: Field = {
      id: Date.now().toString(),
      name: `${newField.name}__c`,
      label: newField.label,
      type: newField.type || 'text',
      required: newField.required || false,
      mapped: false,
      isCustom: true
    };

    setFields([...fields, field]);
    setNewField({
      name: '',
      label: '',
      type: 'text',
      required: false,
      mapped: false,
      isCustom: true
    });
    setShowNewFieldForm(false);
    setHasUnsavedChanges(true);
  };

  const handleDeleteField = (fieldId: string) => {
    const field = fields.find(f => f.id === fieldId);
    if (field?.isCustom) {
      setFields(fields.filter(field => field.id !== fieldId));
      setHasUnsavedChanges(true);
    }
  };

  const handleAutoSync = async () => {
    setIsSyncing(true);
    try {
      // Simulate API call to auto-map fields
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setFields(fields.map(field => ({
        ...field,
        mapped: true,
        mappedTo: field.name.toLowerCase().replace(/[^a-z0-9]/g, '_')
      })));
      
      setHasUnsavedChanges(true);
    } catch (error) {
      console.error('Error syncing fields:', error);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleSaveChanges = () => {
    // Here you would typically save the field mappings to your backend
    console.log('Saving field mappings:', fields);
    setHasUnsavedChanges(false);
  };

  const getObjectTitle = () => {
    switch (objectType) {
      case 'account':
        return 'Account';
      case 'contact':
        return 'Contact';
      case 'opportunity':
        return 'Opportunity';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">{getObjectTitle()} Object Manager</h1>
              <p className="text-gray-600">Map Salesforce fields to your application</p>
            </div>
            <div className="flex space-x-4">
              <button
                onClick={handleAutoSync}
                disabled={isSyncing}
                className="flex items-center px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${isSyncing ? 'animate-spin' : ''}`} />
                {isSyncing ? 'Syncing...' : 'Auto Sync'}
              </button>
              <button
                onClick={() => setShowNewFieldForm(true)}
                className="flex items-center px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Custom Field
              </button>
              <button
                onClick={handleSaveChanges}
                disabled={!hasUnsavedChanges}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </button>
            </div>
          </div>

          {hasUnsavedChanges && (
            <div className="mb-6 p-4 bg-yellow-50 rounded-lg flex items-center text-yellow-800">
              <AlertTriangle className="w-5 h-5 mr-2" />
              You have unsaved changes. Make sure to save your changes before leaving this page.
            </div>
          )}

          {showNewFieldForm && (
            <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
              <h2 className="text-lg font-medium mb-4">Add Custom Field</h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    API Name
                  </label>
                  <input
                    type="text"
                    value={newField.name}
                    onChange={(e) => setNewField({ ...newField, name: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g., Custom_Field"
                  />
                  <p className="mt-1 text-sm text-gray-500">
                    '__c' will be automatically appended
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Label
                  </label>
                  <input
                    type="text"
                    value={newField.label}
                    onChange={(e) => setNewField({ ...newField, label: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g., Custom Field"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Field Type
                  </label>
                  <select
                    value={newField.type}
                    onChange={(e) => setNewField({ ...newField, type: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="text">Text</option>
                    <option value="number">Number</option>
                    <option value="date">Date</option>
                    <option value="picklist">Picklist</option>
                    <option value="checkbox">Checkbox</option>
                    <option value="currency">Currency</option>
                    <option value="percent">Percent</option>
                    <option value="phone">Phone</option>
                    <option value="email">Email</option>
                    <option value="url">URL</option>
                    <option value="textarea">Text Area</option>
                  </select>
                </div>
                <div className="flex items-center">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={newField.required}
                      onChange={(e) => setNewField({ ...newField, required: e.target.checked })}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <span className="ml-2 text-sm text-gray-700">Required Field</span>
                  </label>
                </div>
              </div>
              <div className="flex justify-end space-x-4 mt-6">
                <button
                  onClick={() => setShowNewFieldForm(false)}
                  className="px-4 py-2 text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddCustomField}
                  disabled={!newField.name || !newField.label}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  Add Field
                </button>
              </div>
            </div>
          )}

          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Field Label
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    API Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Required
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Map To
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {fields.map((field) => (
                  <tr key={field.id} className={field.isCustom ? 'bg-blue-50' : ''}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{field.label}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{field.name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500 capitalize">{field.type}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        field.required ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {field.required ? 'Required' : 'Optional'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        <input
                          type="text"
                          value={field.mappedTo || ''}
                          onChange={(e) => handleFieldMapping(field.id, e.target.value)}
                          placeholder="Enter field name"
                          className="px-3 py-1 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                        <ArrowRight className="w-4 h-4 text-gray-400" />
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <button className="text-gray-400 hover:text-gray-600">
                          <Settings className="w-5 h-5" />
                        </button>
                        {field.isCustom && (
                          <button
                            onClick={() => handleDeleteField(field.id)}
                            className="text-gray-400 hover:text-red-500"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}