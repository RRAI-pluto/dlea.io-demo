import { Request, Response, NextFunction } from 'express';
import { createLogger, format, transports } from 'winston';

// Create Winston logger
const logger = createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [
    new transports.Console(),
    new transports.File({ filename: 'error.log', level: 'error' }),
    new transports.File({ filename: 'combined.log' })
  ]
});

// Request logging middleware
export const requestLogger = (req: Request, res: Response, next: NextFunction) => {
  const start = Date.now();

  res.on('finish', () => {
    const duration = Date.now() - start;
    
    logger.info({
      method: req.method,
      url: req.url,
      status: res.statusCode,
      duration,
      userAgent: req.get('user-agent'),
      ip: req.ip
    });

    // Sample performance metrics
    if (Math.random() < Number(process.env.PERFORMANCE_SAMPLE_RATE || 0.05)) {
      logger.info({
        type: 'performance',
        path: req.path,
        duration,
        timestamp: new Date().toISOString()
      });
    }
  });

  next();
};

// Error logging middleware
export const errorLogger = (err: Error, req: Request, res: Response, next: NextFunction) => {
  // Sample errors to avoid overwhelming logs
  if (Math.random() < Number(process.env.ERROR_REPORTING_RATE || 0.1)) {
    logger.error({
      error: {
        message: err.message,
        stack: err.stack,
        name: err.name
      },
      request: {
        method: req.method,
        url: req.url,
        headers: req.headers,
        query: req.query,
        body: req.body
      },
      user: req.user
    });
  }

  next(err);
};

// Health check endpoint
export const healthCheck = async (req: Request, res: Response) => {
  try {
    // Add your health checks here
    const checks = {
      database: await checkDatabaseConnection(),
      redis: await checkRedisConnection(),
      api: await checkExternalAPIs()
    };

    const isHealthy = Object.values(checks).every(check => check.status === 'healthy');

    res.status(isHealthy ? 200 : 503).json({
      status: isHealthy ? 'healthy' : 'unhealthy',
      timestamp: new Date().toISOString(),
      checks
    });
  } catch (error) {
    logger.error('Health check failed:', error);
    res.status(503).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
};

// Helper functions for health checks
async function checkDatabaseConnection() {
  try {
    // Add your database connection check
    return { status: 'healthy' };
  } catch (error) {
    return { status: 'unhealthy', error };
  }
}

async function checkRedisConnection() {
  try {
    // Add your Redis connection check
    return { status: 'healthy' };
  } catch (error) {
    return { status: 'unhealthy', error };
  }
}

async function checkExternalAPIs() {
  try {
    // Add your external API checks
    return { status: 'healthy' };
  } catch (error) {
    return { status: 'unhealthy', error };
  }
}

export const monitor = {
  logger,
  requestLogger,
  errorLogger,
  healthCheck
};