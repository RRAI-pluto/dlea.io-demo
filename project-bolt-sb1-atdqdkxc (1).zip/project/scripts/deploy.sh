#!/bin/bash

# Exit on error
set -e

# Load environment variables
source .env.production

# Deploy backend
echo "Deploying backend..."
ssh root@$DEPLOY_HOST << 'ENDSSH'
  cd /opt/dlea
  git pull origin main
  cd backend
  docker-compose down
  docker-compose build
  docker-compose up -d
  docker system prune -f
ENDSSH

echo "Backend deployment complete!"