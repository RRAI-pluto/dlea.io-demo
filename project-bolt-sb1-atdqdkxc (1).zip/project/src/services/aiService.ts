import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';

export interface AIResponse {
  content: string;
  type: 'text' | 'analysis' | 'suggestion';
  confidence?: number;
  metadata?: Record<string, any>;
}

export const aiService = {
  // Analyze sales call
  async analyzeSalesCall(transcript: string): Promise<AIResponse> {
    try {
      const { data } = await axios.post(`${API_URL}/ai/analyze-call`, { transcript });
      return data.data;
    } catch (error) {
      console.error('Error analyzing sales call:', error);
      throw error;
    }
  },

  // Generate content suggestions
  async generateContentSuggestions(context: {
    dealStage: string;
    industry: string;
    painPoints: string[];
  }): Promise<AIResponse> {
    try {
      const { data } = await axios.post(`${API_URL}/ai/content-suggestions`, context);
      return data.data;
    } catch (error) {
      console.error('Error generating content suggestions:', error);
      throw error;
    }
  },

  // Analyze deal risks
  async analyzeDealRisks(dealData: {
    stage: string;
    value: number;
    interactions: any[];
    timeline: any[];
  }): Promise<AIResponse> {
    try {
      const { data } = await axios.post(`${API_URL}/ai/deal-risks`, dealData);
      return data.data;
    } catch (error) {
      console.error('Error analyzing deal risks:', error);
      throw error;
    }
  },

  // Generate coaching insights
  async generateCoachingInsights(performanceData: {
    metrics: any[];
    calls: any[];
    deals: any[];
  }): Promise<AIResponse> {
    try {
      const { data } = await axios.post(`${API_URL}/ai/coaching-insights`, performanceData);
      return data.data;
    } catch (error) {
      console.error('Error generating coaching insights:', error);
      throw error;
    }
  }
};