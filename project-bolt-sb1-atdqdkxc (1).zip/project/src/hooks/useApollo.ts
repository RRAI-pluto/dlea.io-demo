import { useState, useCallback } from 'react';
import ApolloAPI from '../services/apolloApi';

interface UseApolloConfig {
  apiKey: string;
  organizationId: string;
}

interface ApolloStats {
  credits_used: number;
  credits_remaining: number;
  requests_made: number;
  last_sync: string;
}

export function useApollo(config: UseApolloConfig) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [stats, setStats] = useState<ApolloStats | null>(null);

  const api = new ApolloAPI(config);

  const testConnection = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await api.testConnection();
      return result;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('An error occurred'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [api]);

  const searchPeople = useCallback(async (query: any) => {
    setIsLoading(true);
    setError(null);
    try {
      const results = await api.searchPeople(query);
      return results;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('An error occurred'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [api]);

  const enrichContact = useCallback(async (email: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await api.enrichContact(email);
      return result;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('An error occurred'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [api]);

  const getAccount = useCallback(async (domain: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await api.getAccount(domain);
      return result;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('An error occurred'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [api]);

  const getTeamStats = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await api.getTeamStats();
      setStats(result);
      return result;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('An error occurred'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [api]);

  const getApiUsage = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await api.getApiUsage();
      return result;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('An error occurred'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [api]);

  return {
    testConnection,
    searchPeople,
    enrichContact,
    getAccount,
    getTeamStats,
    getApiUsage,
    stats,
    isLoading,
    error
  };
}