import { supabase } from '../lib/supabase';
import OpenAI from 'openai';

interface AIModel {
  id: string;
  name: string;
  type: 'gpt-4' | 'gpt-3.5-turbo';
  purpose: 'sales' | 'support' | 'training';
  config: {
    temperature: number;
    maxTokens: number;
    topP: number;
    frequencyPenalty: number;
    presencePenalty: number;
  };
  prompts: {
    systemPrompt: string;
    examples: Array<{
      input: string;
      output: string;
    }>;
  };
  metadata: Record<string, any>;
  created_at: Date;
  updated_at: Date;
}

interface ModelResponse {
  id: string;
  content: string;
  type: 'text' | 'analysis' | 'suggestion';
  confidence: number;
  metadata?: Record<string, any>;
}

export class AIModelService {
  private openai: OpenAI;

  constructor(apiKey: string) {
    this.openai = new OpenAI({ 
      apiKey,
      dangerouslyAllowBrowser: true // Required for browser usage
    });
  }

  async createModel(model: Omit<AIModel, 'id' | 'created_at' | 'updated_at'>) {
    try {
      const { data, error } = await supabase
        .from('ai_models')
        .insert([model])
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error creating AI model:', error);
      throw error;
    }
  }

  async getModel(id: string) {
    try {
      const { data, error } = await supabase
        .from('ai_models')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error getting AI model:', error);
      throw error;
    }
  }

  async updateModel(id: string, updates: Partial<AIModel>) {
    try {
      const { data, error } = await supabase
        .from('ai_models')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error updating AI model:', error);
      throw error;
    }
  }

  async generateResponse(modelId: string, input: string): Promise<ModelResponse> {
    try {
      // Get model configuration
      const model = await this.getModel(modelId);
      if (!model) throw new Error('Model not found');

      // Prepare messages array
      const messages = [
        { role: 'system', content: model.prompts.systemPrompt },
        ...model.prompts.examples.flatMap(example => [
          { role: 'user', content: example.input },
          { role: 'assistant', content: example.output }
        ]),
        { role: 'user', content: input }
      ];

      // Generate response using OpenAI
      const completion = await this.openai.chat.completions.create({
        model: model.type,
        messages: messages as any,
        temperature: model.config.temperature,
        max_tokens: model.config.maxTokens,
        top_p: model.config.topP,
        frequency_penalty: model.config.frequencyPenalty,
        presence_penalty: model.config.presencePenalty
      });

      // Store the interaction
      await this.storeInteraction(modelId, input, completion.choices[0].message.content);

      return {
        id: completion.id,
        content: completion.choices[0].message.content,
        type: 'text',
        confidence: completion.choices[0].finish_reason === 'stop' ? 1 : 0.8,
        metadata: {
          model: model.type,
          usage: completion.usage
        }
      };
    } catch (error) {
      console.error('Error generating response:', error);
      throw error;
    }
  }

  private async storeInteraction(modelId: string, input: string, output: string) {
    try {
      const { error } = await supabase
        .from('ai_interactions')
        .insert([{
          model_id: modelId,
          input,
          output,
          metadata: {
            timestamp: new Date().toISOString()
          }
        }]);

      if (error) throw error;
    } catch (error) {
      console.error('Error storing interaction:', error);
      // Don't throw here to avoid interrupting the main flow
    }
  }

  async getModelPerformance(modelId: string, timeRange: { start: Date; end: Date }) {
    try {
      const { data, error } = await supabase
        .from('ai_interactions')
        .select('*')
        .eq('model_id', modelId)
        .gte('created_at', timeRange.start.toISOString())
        .lte('created_at', timeRange.end.toISOString());

      if (error) throw error;

      // Calculate performance metrics
      const totalInteractions = data.length;
      const successfulInteractions = data.filter(i => i.metadata?.success).length;
      const averageLatency = data.reduce((acc, i) => acc + (i.metadata?.latency || 0), 0) / totalInteractions;

      return {
        totalInteractions,
        successRate: (successfulInteractions / totalInteractions) * 100,
        averageLatency,
        interactions: data
      };
    } catch (error) {
      console.error('Error getting model performance:', error);
      throw error;
    }
  }
}

// Export singleton instance
export const aiModelService = new AIModelService(import.meta.env.VITE_OPENAI_API_KEY || '');