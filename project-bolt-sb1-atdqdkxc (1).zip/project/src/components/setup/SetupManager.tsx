import React, { useState } from 'react';
import { Building, Package, Users, Target, Save } from 'lucide-react';
import { InitialSetup } from './InitialSetup';

export function SetupManager() {
  const [activeTab, setActiveTab] = useState('company');
  const [setupData, setSetupData] = useState({
    companyInfo: {
      name: 'Acme Corp',
      size: '51-200',
      industry: 'Technology',
      website: 'https://acme.com'
    },
    productInfo: {
      name: 'Acme Platform',
      type: 'saas',
      priceRange: '10001-50000',
      salesCycle: '31-90'
    },
    customerInfo: {
      targetMarket: 'enterprise',
      avgDealSize: '50001-100000',
      decisionMakers: ['CXO', 'VP'],
      painPoints: ['Efficiency', 'Cost']
    },
    goalsInfo: {
      primaryObjective: 'revenue_growth',
      revenueTarget: '10000000',
      timeframe: '1year',
      specificGoals: ['Increase win rate', 'Reduce sales cycle']
    }
  });

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">Setup Manager</h1>
              <p className="text-gray-600">Manage your business configuration</p>
            </div>
            <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              <Save className="w-5 h-5 mr-2" />
              Save Changes
            </button>
          </div>

          <div className="bg-white rounded-lg shadow-sm">
            <div className="border-b">
              <nav className="flex -mb-px">
                <button
                  onClick={() => setActiveTab('company')}
                  className={`px-6 py-4 text-sm font-medium border-b-2 ${
                    activeTab === 'company'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  } flex items-center`}
                >
                  <Building className="w-5 h-5 mr-2" />
                  Company
                </button>
                <button
                  onClick={() => setActiveTab('product')}
                  className={`px-6 py-4 text-sm font-medium border-b-2 ${
                    activeTab === 'product'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  } flex items-center`}
                >
                  <Package className="w-5 h-5 mr-2" />
                  Product
                </button>
                <button
                  onClick={() => setActiveTab('customers')}
                  className={`px-6 py-4 text-sm font-medium border-b-2 ${
                    activeTab === 'customers'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  } flex items-center`}
                >
                  <Users className="w-5 h-5 mr-2" />
                  Customers
                </button>
                <button
                  onClick={() => setActiveTab('goals')}
                  className={`px-6 py-4 text-sm font-medium border-b-2 ${
                    activeTab === 'goals'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  } flex items-center`}
                >
                  <Target className="w-5 h-5 mr-2" />
                  Goals
                </button>
              </nav>
            </div>

            <div className="p-6">
              {/* Render form fields based on active tab */}
              <InitialSetup />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}