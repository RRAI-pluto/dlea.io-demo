import React, { useState } from 'react';
import { Filter, Plus, ChevronDown, Search } from 'lucide-react';
import { NewFunnelModal } from './NewFunnelModal';

interface Stage {
  id: string;
  name: string;
  targetConversion: number;
}

interface Funnel {
  id: string;
  teamName: string;
  stages: Stage[];
  createdAt: Date;
}

interface FunnelAnalystProps {
  isNewFunnel?: boolean;
}

export function FunnelAnalyst({ isNewFunnel = false }: FunnelAnalystProps) {
  const [showNewFunnel, setShowNewFunnel] = useState(isNewFunnel);
  const [funnels, setFunnels] = useState<Funnel[]>([]);
  const [selectedFunnel, setSelectedFunnel] = useState<Funnel | null>(null);

  const handleSaveFunnel = (newFunnel: { teamName: string; stages: Stage[] }) => {
    const funnel: Funnel = {
      id: Date.now().toString(),
      ...newFunnel,
      createdAt: new Date()
    };
    setFunnels([...funnels, funnel]);
    setSelectedFunnel(funnel);
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">Funnel Analyst</h1>
              <p className="text-gray-600">Monitor and analyze your sales funnels</p>
            </div>
            <button
              onClick={() => setShowNewFunnel(true)}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Plus className="w-5 h-5 mr-2" />
              New Funnel
            </button>
          </div>

          {/* Funnel Selection */}
          {funnels.length > 0 && (
            <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
              <div className="flex items-center space-x-4">
                <div className="relative flex-1">
                  <select
                    value={selectedFunnel?.id || ''}
                    onChange={(e) => setSelectedFunnel(funnels.find(f => f.id === e.target.value) || null)}
                    className="w-full appearance-none bg-gray-50 border border-gray-200 rounded-lg pl-4 pr-10 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select a funnel</option>
                    {funnels.map(funnel => (
                      <option key={funnel.id} value={funnel.id}>
                        {funnel.teamName} Funnel
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="w-5 h-5 text-gray-400 absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none" />
                </div>
                <div className="relative flex-1">
                  <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search opportunities..."
                    className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Selected Funnel Visualization */}
          {selectedFunnel && (
            <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
              <h2 className="text-lg font-medium mb-4">{selectedFunnel.teamName} Sales Funnel</h2>
              <div className="relative h-[400px]">
                {selectedFunnel.stages.map((stage, index) => {
                  const width = 100 - (index * (100 / selectedFunnel.stages.length));
                  return (
                    <div
                      key={stage.id}
                      className="absolute left-1/2 transform -translate-x-1/2"
                      style={{
                        top: `${index * (400 / selectedFunnel.stages.length)}px`,
                        width: `${width}%`,
                        height: `${400 / selectedFunnel.stages.length}px`
                      }}
                    >
                      <div
                        className="h-full bg-gradient-to-b from-blue-500 to-blue-600 opacity-20 rounded-lg"
                        style={{
                          clipPath: 'polygon(0 0, 100% 0, 95% 100%, 5% 100%)'
                        }}
                      />
                      <div className="absolute top-1/2 left-4 transform -translate-y-1/2 text-gray-700">
                        <div className="font-medium">{stage.name}</div>
                        <div className="text-sm text-gray-500">Target: {stage.targetConversion}%</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Empty State */}
          {funnels.length === 0 && (
            <div className="bg-white p-8 rounded-lg shadow-sm text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Filter className="w-8 h-8 text-blue-600" />
              </div>
              <h2 className="text-xl font-medium mb-2">No Funnels Created Yet</h2>
              <p className="text-gray-600 mb-6">
                Create your first sales funnel to start monitoring team performance
              </p>
              <button
                onClick={() => setShowNewFunnel(true)}
                className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Plus className="w-5 h-5 mr-2" />
                Create New Funnel
              </button>
            </div>
          )}
        </div>
      </div>

      {/* New Funnel Modal */}
      {showNewFunnel && (
        <NewFunnelModal
          onClose={() => setShowNewFunnel(false)}
          onSave={handleSaveFunnel}
        />
      )}
    </div>
  );
}