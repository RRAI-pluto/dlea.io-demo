import { useState, useCallback } from 'react';
import ConfluenceAPI from '../services/confluenceApi';

interface UseConfluenceConfig {
  baseUrl: string;
  email: string;
  apiKey: string;
}

export function useConfluence(config: UseConfluenceConfig) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const api = new ConfluenceAPI(config);

  const searchContent = useCallback(async (query: string, spaceKey?: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const results = await api.searchContent(query, spaceKey);
      return results;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('An error occurred'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [api]);

  const getPage = useCallback(async (pageId: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const page = await api.getPage(pageId);
      return page;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('An error occurred'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [api]);

  const getSpaces = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const spaces = await api.getSpaces();
      return spaces;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('An error occurred'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [api]);

  return {
    searchContent,
    getPage,
    getSpaces,
    isLoading,
    error
  };
}