import React, { useState } from 'react';
import { X, Plus, Trash2, AlertCircle } from 'lucide-react';

interface Stage {
  id: string;
  name: string;
  targetConversion: number;
}

interface NewFunnelModalProps {
  onClose: () => void;
  onSave: (funnel: { teamName: string; stages: Stage[] }) => void;
}

export function NewFunnelModal({ onClose, onSave }: NewFunnelModalProps) {
  const [teamName, setTeamName] = useState('');
  const [stages, setStages] = useState<Stage[]>([
    { id: '1', name: 'Lead', targetConversion: 100 },
    { id: '2', name: 'Qualified', targetConversion: 70 },
    { id: '3', name: 'Proposal', targetConversion: 50 },
    { id: '4', name: 'Negotiation', targetConversion: 30 },
    { id: '5', name: 'Closed', targetConversion: 20 }
  ]);

  const addStage = () => {
    setStages([
      ...stages,
      {
        id: Date.now().toString(),
        name: 'New Stage',
        targetConversion: 0
      }
    ]);
  };

  const removeStage = (id: string) => {
    setStages(stages.filter(stage => stage.id !== id));
  };

  const updateStage = (id: string, field: keyof Stage, value: string | number) => {
    setStages(stages.map(stage => {
      if (stage.id === id) {
        return { ...stage, [field]: value };
      }
      return stage;
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!teamName.trim()) return;
    onSave({ teamName, stages });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-[800px] max-h-[80vh] overflow-y-auto">
        <div className="p-6 border-b flex justify-between items-center">
          <h2 className="text-xl font-bold">Create New Sales Funnel</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Team Name
            </label>
            <input
              type="text"
              value={teamName}
              onChange={(e) => setTeamName(e.target.value)}
              placeholder="Enter team name"
              className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div className="mb-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">Sales Stages</h3>
              <button
                type="button"
                onClick={addStage}
                className="flex items-center px-3 py-1.5 text-sm text-blue-600 border border-blue-200 rounded-lg hover:bg-blue-50"
              >
                <Plus className="w-4 h-4 mr-1" />
                Add Stage
              </button>
            </div>

            <div className="space-y-3">
              {stages.map((stage, index) => (
                <div key={stage.id} className="flex items-center space-x-4">
                  <div className="w-8 h-8 flex items-center justify-center bg-blue-100 text-blue-600 rounded-lg">
                    {index + 1}
                  </div>
                  <input
                    type="text"
                    value={stage.name}
                    onChange={(e) => updateStage(stage.id, 'name', e.target.value)}
                    placeholder="Stage name"
                    className="flex-1 px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                  <div className="w-48">
                    <div className="flex items-center">
                      <input
                        type="number"
                        value={stage.targetConversion}
                        onChange={(e) => updateStage(stage.id, 'targetConversion', parseInt(e.target.value))}
                        min="0"
                        max="100"
                        className="w-20 px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                      <span className="ml-2 text-gray-500">%</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeStage(stage.id)}
                    className="text-gray-400 hover:text-red-500"
                    disabled={stages.length <= 2}
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>

            {stages.length <= 2 && (
              <div className="mt-3 flex items-center text-amber-600 text-sm">
                <AlertCircle className="w-4 h-4 mr-2" />
                At least two stages are required
              </div>
            )}
          </div>

          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              disabled={!teamName.trim() || stages.length < 2}
            >
              Create Funnel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}