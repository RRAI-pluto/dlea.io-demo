import React, { useState } from 'react';
import { Book, Video, FileText, Brain, Target, Clock, Calendar, CheckCircle, ArrowRight, AlertTriangle, BarChart2 } from 'lucide-react';

interface TrainingTicket {
  id: string;
  title: string;
  description: string;
  type: 'course' | 'assessment' | 'certification';
  status: 'assigned' | 'in_progress' | 'completed';
  dueDate: Date;
  progress: number;
  assignedBy: string;
  assignedAt: Date;
  content: {
    modules: {
      id: string;
      title: string;
      completed: boolean;
      lessons: {
        id: string;
        title: string;
        type: 'video' | 'text' | 'quiz';
        duration: number;
        completed: boolean;
      }[];
    }[];
  };
  metrics?: {
    label: string;
    value: string;
    change: number;
  }[];
}

export function TrainingTickets() {
  const [tickets, setTickets] = useState<TrainingTicket[]>([
    {
      id: '1',
      title: 'Sales Methodology Mastery',
      description: 'Complete the comprehensive training on modern sales techniques',
      type: 'course',
      status: 'in_progress',
      dueDate: new Date('2025-02-15'),
      progress: 45,
      assignedBy: 'Sarah Chen',
      assignedAt: new Date('2025-01-24'),
      content: {
        modules: [
          {
            id: 'm1',
            title: 'Foundations of Modern Sales',
            completed: true,
            lessons: [
              {
                id: 'l1',
                title: 'Introduction to Modern Sales',
                type: 'video',
                duration: 15,
                completed: true
              },
              {
                id: 'l2',
                title: 'Understanding the Buyer Journey',
                type: 'text',
                duration: 20,
                completed: true
              },
              {
                id: 'l3',
                title: 'Value-Based Selling Quiz',
                type: 'quiz',
                duration: 10,
                completed: false
              }
            ]
          },
          {
            id: 'm2',
            title: 'Advanced Discovery Techniques',
            completed: false,
            lessons: [
              {
                id: 'l4',
                title: 'Strategic Questioning',
                type: 'video',
                duration: 25,
                completed: false
              },
              {
                id: 'l5',
                title: 'Active Listening Skills',
                type: 'text',
                duration: 15,
                completed: false
              }
            ]
          }
        ]
      },
      metrics: [
        { label: 'Quiz Score', value: '85%', change: 12 },
        { label: 'Time Spent', value: '2.5h', change: 8 },
        { label: 'Completion Rate', value: '45%', change: 15 }
      ]
    }
  ]);

  const [selectedTicket, setSelectedTicket] = useState<TrainingTicket | null>(null);
  const [filterStatus, setFilterStatus] = useState<'all' | 'assigned' | 'in_progress' | 'completed'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'assigned':
        return 'bg-blue-100 text-blue-800';
      case 'in_progress':
        return 'bg-yellow-100 text-yellow-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'course':
        return <Book className="w-5 h-5 text-blue-600" />;
      case 'assessment':
        return <Target className="w-5 h-5 text-purple-600" />;
      case 'certification':
        return <Brain className="w-5 h-5 text-green-600" />;
      default:
        return <FileText className="w-5 h-5 text-gray-600" />;
    }
  };

  const filteredTickets = tickets.filter(ticket => {
    const matchesStatus = filterStatus === 'all' || ticket.status === filterStatus;
    const matchesSearch = ticket.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">Training Tickets</h1>
              <p className="text-gray-600">Your assigned training and certifications</p>
            </div>
            <div className="flex space-x-4">
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Status</option>
                <option value="assigned">Assigned</option>
                <option value="in_progress">In Progress</option>
                <option value="completed">Completed</option>
              </select>
            </div>
          </div>

          <div className="space-y-4">
            {filteredTickets.map((ticket) => (
              <div key={ticket.id} className="bg-white rounded-lg shadow-sm">
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-gray-50 rounded-lg">
                        {getTypeIcon(ticket.type)}
                      </div>
                      <div>
                        <h3 className="font-medium">{ticket.title}</h3>
                        <p className="text-sm text-gray-500 mt-1">{ticket.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <div className="flex items-center space-x-2">
                          <Clock className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-500">
                            Due {ticket.dueDate.toLocaleDateString()}
                          </span>
                        </div>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium mt-1 ${
                          getStatusColor(ticket.status)
                        }`}>
                          {ticket.status.replace('_', ' ')}
                        </span>
                      </div>
                      <button
                        onClick={() => setSelectedTicket(selectedTicket?.id === ticket.id ? null : ticket)}
                        className="text-blue-600 hover:bg-blue-50 px-3 py-1.5 rounded-lg flex items-center"
                      >
                        <ArrowRight className="w-4 h-4 mr-1" />
                        Continue Training
                      </button>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-gray-600">Progress</span>
                      <span className="text-sm font-medium">{ticket.progress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${ticket.progress}%` }}
                      />
                    </div>
                  </div>

                  {/* Metrics */}
                  {ticket.metrics && (
                    <div className="grid grid-cols-3 gap-4 mb-4">
                      {ticket.metrics.map((metric, index) => (
                        <div key={index} className="bg-gray-50 p-3 rounded-lg">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm text-gray-500">{metric.label}</span>
                            <span className={`text-xs font-medium ${
                              metric.change > 0 ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {metric.change > 0 ? '+' : ''}{metric.change}%
                            </span>
                          </div>
                          <p className="text-lg font-medium">{metric.value}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Modules */}
                  {selectedTicket?.id === ticket.id && (
                    <div className="mt-6 pt-6 border-t">
                      <h4 className="font-medium mb-4">Course Modules</h4>
                      <div className="space-y-4">
                        {ticket.content.modules.map((module) => (
                          <div key={module.id} className="border rounded-lg">
                            <div className="p-4">
                              <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center">
                                  {module.completed ? (
                                    <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                                  ) : (
                                    <Target className="w-5 h-5 text-blue-600 mr-2" />
                                  )}
                                  <h5 className="font-medium">{module.title}</h5>
                                </div>
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                  module.completed ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                                }`}>
                                  {module.completed ? 'Completed' : 'In Progress'}
                                </span>
                              </div>

                              <div className="space-y-2 mt-4">
                                {module.lessons.map((lesson) => (
                                  <div
                                    key={lesson.id}
                                    className="flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg"
                                  >
                                    <div className="flex items-center">
                                      {lesson.type === 'video' && <Video className="w-4 h-4 text-blue-600 mr-2" />}
                                      {lesson.type === 'text' && <FileText className="w-4 h-4 text-green-600 mr-2" />}
                                      {lesson.type === 'quiz' && <Brain className="w-4 h-4 text-purple-600 mr-2" />}
                                      <span className="text-sm">{lesson.title}</span>
                                    </div>
                                    <div className="flex items-center space-x-3">
                                      <span className="text-sm text-gray-500">
                                        {lesson.duration} min
                                      </span>
                                      {lesson.completed && (
                                        <CheckCircle className="w-4 h-4 text-green-600" />
                                      )}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Empty State */}
          {filteredTickets.length === 0 && (
            <div className="bg-white rounded-lg shadow-sm p-8 text-center">
              <Book className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Training Tickets</h3>
              <p className="text-gray-500">You don't have any training tickets assigned yet.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}