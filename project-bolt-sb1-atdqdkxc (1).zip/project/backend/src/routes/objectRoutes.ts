import { Router } from 'express';
import { ObjectController } from '../controllers/objectController';
import { authMiddleware } from '../middleware/authMiddleware';

const router = Router();
const objectController = new ObjectController();

router.get('/:type/fields', authMiddleware, objectController.getFields);
router.post('/:type/fields', authMiddleware, objectController.createField);
router.put('/:type/fields/:id', authMiddleware, objectController.updateField);
router.delete('/:type/fields/:id', authMiddleware, objectController.deleteField);
router.post('/:type/fields/mapping', authMiddleware, objectController.updateFieldMappings);

export default router;