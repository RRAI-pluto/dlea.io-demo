import React, { useState, useEffect } from 'react';
import { Users, Plus, Trash2, Building, Mail, Phone, Shield, ChevronDown, Search, Filter, BarChart2, Target, Brain, Zap, Settings, X } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  role: string;
  teamId: string;
  createdAt: Date;
  metrics?: {
    label: string;
    value: string;
    change: number;
  }[];
}

interface Team {
  id: string;
  name: string;
  description: string;
  metrics?: {
    deals: number;
    revenue: number;
    quota: number;
    conversion: number;
  };
}

export function UsersAndTeams() {
  const [activeTab, setActiveTab] = useState<'users' | 'teams'>('teams');
  const [teams, setTeams] = useState<Team[]>([
    { 
      id: '1', 
      name: 'Enterprise Sales',
      description: 'Strategic enterprise accounts team',
      metrics: {
        deals: 45,
        revenue: 2500000,
        quota: 85,
        conversion: 32
      }
    },
    { 
      id: '2', 
      name: 'Mid-Market Sales',
      description: 'Mid-sized business accounts team',
      metrics: {
        deals: 78,
        revenue: 1800000,
        quota: 92,
        conversion: 28
      }
    }
  ]);

  const [users, setUsers] = useState<User[]>([]);
  const [showNewTeamModal, setShowNewTeamModal] = useState(false);
  const [showNewUserModal, setShowNewUserModal] = useState(false);
  const [newTeam, setNewTeam] = useState<Partial<Team>>({
    name: '',
    description: ''
  });
  const [newUser, setNewUser] = useState<Partial<User>>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    role: '',
    teamId: ''
  });

  const [selectedTeam, setSelectedTeam] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    generateDummyUsers();
  }, []);

  const generateDummyUsers = () => {
    const dummyUsers: User[] = [
      {
        id: '1',
        firstName: 'Sarah',
        lastName: 'Chen',
        email: 'sarah.chen@example.com',
        phone: '+1 (555) 123-4567',
        role: 'Super Admin',
        teamId: '1',
        createdAt: new Date('2024-12-15'),
        metrics: [
          { label: 'Deals Closed', value: '45', change: 12 },
          { label: 'Revenue', value: '$1.2M', change: 8 },
          { label: 'Win Rate', value: '68%', change: 5 }
        ]
      },
      {
        id: '2',
        firstName: 'Michael',
        lastName: 'Rodriguez',
        email: 'michael.r@example.com',
        phone: '+1 (555) 234-5678',
        role: 'Admin',
        teamId: '2',
        createdAt: new Date('2024-12-20'),
        metrics: [
          { label: 'Deals Closed', value: '38', change: -3 },
          { label: 'Revenue', value: '$980K', change: 15 },
          { label: 'Win Rate', value: '72%', change: 2 }
        ]
      }
    ];

    setUsers(dummyUsers);
  };

  const handleCreateTeam = () => {
    if (!newTeam.name) return;

    const team: Team = {
      id: Date.now().toString(),
      name: newTeam.name,
      description: newTeam.description || '',
      metrics: {
        deals: 0,
        revenue: 0,
        quota: 0,
        conversion: 0
      }
    };

    setTeams([...teams, team]);
    setNewTeam({ name: '', description: '' });
    setShowNewTeamModal(false);
  };

  const handleCreateUser = async () => {
    if (!newUser.firstName || !newUser.lastName || !newUser.email || !newUser.role || !newUser.teamId) return;

    try {
      // Create auth user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: newUser.email,
        password: 'temporary-password', // You should implement a secure password system
        options: {
          data: {
            full_name: `${newUser.firstName} ${newUser.lastName}`
          }
        }
      });

      if (authError) throw authError;

      // Add to local state
      const user: User = {
        id: authData.user?.id || Date.now().toString(),
        firstName: newUser.firstName,
        lastName: newUser.lastName,
        email: newUser.email,
        phone: newUser.phone || '',
        role: newUser.role,
        teamId: newUser.teamId,
        createdAt: new Date()
      };

      setUsers([...users, user]);
      setNewUser({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        role: '',
        teamId: ''
      });
      setShowNewUserModal(false);
    } catch (error) {
      console.error('Error creating user:', error);
    }
  };

  const handleDeleteTeam = (teamId: string) => {
    setTeams(teams.filter(team => team.id !== teamId));
  };

  const handleDeleteUser = (userId: string) => {
    setUsers(users.filter(user => user.id !== userId));
  };

  const getTeamName = (teamId: string) => {
    return teams.find(team => team.id === teamId)?.name || 'Unknown Team';
  };

  const filteredUsers = users.filter(user => {
    const matchesTeam = selectedTeam === 'all' || user.teamId === selectedTeam;
    const matchesSearch = 
      user.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTeam && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">Users & Teams</h1>
              <p className="text-gray-600">Manage users and team assignments</p>
            </div>
            <div className="flex space-x-4">
              <button
                onClick={() => setShowNewTeamModal(true)}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Building className="w-5 h-5 mr-2" />
                New Team
              </button>
              <button
                onClick={() => setShowNewUserModal(true)}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Users className="w-5 h-5 mr-2" />
                New User
              </button>
            </div>
          </div>

          {/* Tabs */}
          <div className="border-b border-gray-200 mb-6">
            <nav className="-mb-px flex space-x-8">
              <button
                onClick={() => setActiveTab('teams')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'teams'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Teams
              </button>
              <button
                onClick={() => setActiveTab('users')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'users'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Users
              </button>
            </nav>
          </div>

          {activeTab === 'teams' ? (
            <div className="grid grid-cols-2 gap-6">
              {teams.map(team => (
                <div key={team.id} className="bg-white p-6 rounded-lg shadow-sm">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-medium">{team.name}</h3>
                      <p className="text-sm text-gray-500">{team.description}</p>
                    </div>
                    <button
                      onClick={() => handleDeleteTeam(team.id)}
                      className="text-gray-400 hover:text-red-500"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-gray-500">Members</span>
                        <Users className="w-4 h-4 text-gray-400" />
                      </div>
                      <span className="text-lg font-medium">
                        {users.filter(u => u.teamId === team.id).length}
                      </span>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-gray-500">Revenue</span>
                        <BarChart2 className="w-4 h-4 text-gray-400" />
                      </div>
                      <span className="text-lg font-medium">
                        ${(team.metrics?.revenue || 0).toLocaleString()}
                      </span>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-gray-500">Quota</span>
                        <Target className="w-4 h-4 text-gray-400" />
                      </div>
                      <span className="text-lg font-medium">
                        {team.metrics?.quota || 0}%
                      </span>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-gray-500">Conversion</span>
                        <Brain className="w-4 h-4 text-gray-400" />
                      </div>
                      <span className="text-lg font-medium">
                        {team.metrics?.conversion || 0}%
                      </span>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Team Members</h4>
                    <div className="space-y-2">
                      {users
                        .filter(user => user.teamId === team.id)
                        .map(user => (
                          <div key={user.id} className="flex items-center justify-between">
                            <div className="flex items-center">
                              <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                                <span className="text-sm font-medium text-gray-600">
                                  {user.firstName[0]}{user.lastName[0]}
                                </span>
                              </div>
                              <div className="ml-3">
                                <p className="text-sm font-medium">{user.firstName} {user.lastName}</p>
                                <p className="text-xs text-gray-500">{user.role}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-sm">
              <div className="p-6 border-b">
                <div className="flex space-x-4">
                  <div className="flex-1 relative">
                    <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search users..."
                      className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <select
                    value={selectedTeam}
                    onChange={(e) => setSelectedTeam(e.target.value)}
                    className="px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="all">All Teams</option>
                    {teams.map(team => (
                      <option key={team.id} value={team.id}>{team.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      User
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Contact
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Role
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Team
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Metrics
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredUsers.map((user) => (
                    <tr key={user.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                          {user.firstName} {user.lastName}
                        </div>
                        <div className="text-sm text-gray-500">
                          Joined {user.createdAt.toLocaleDateString()}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex flex-col">
                          <div className="text-sm text-gray-900 flex items-center">
                            <Mail className="w-4 h-4 mr-2 text-gray-400" />
                            {user.email}
                          </div>
                          {user.phone && (
                            <div className="text-sm text-gray-500 flex items-center mt-1">
                              <Phone className="w-4 h-4 mr-2 text-gray-400" />
                              {user.phone}
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <Shield className="w-4 h-4 mr-2 text-gray-400" />
                          <span className="text-sm text-gray-900">{user.role}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <Building className="w-4 h-4 mr-2 text-gray-400" />
                          <span className="text-sm text-gray-900">{getTeamName(user.teamId)}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {user.metrics && (
                          <div className="flex flex-col space-y-1">
                            {user.metrics.map((metric, index) => (
                              <div key={index} className="flex items-center justify-between text-sm">
                                <span className="text-gray-500">{metric.label}:</span>
                                <span className={`font-medium ${
                                  metric.change > 0 ? 'text-green-600' : 
                                  metric.change < 0 ? 'text-red-600' : 
                                  'text-gray-900'
                                }`}>
                                  {metric.value}
                                  <span className="ml-1 text-xs">
                                    ({metric.change > 0 ? '+' : ''}{metric.change}%)
                                  </span>
                                </span>
                              </div>
                            ))}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <button
                          onClick={() => handleDeleteUser(user.id)}
                          className="text-gray-400 hover:text-red-500"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* New Team Modal */}
      {showNewTeamModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg w-[500px] p-6">
            <h2 className="text-lg font-medium mb-4">Create New Team</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Team Name
                </label>
                <input
                  type="text"
                  value={newTeam.name}
                  onChange={(e) => setNewTeam({ ...newTeam, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  value={newTeam.description}
                  onChange={(e) => setNewTeam({ ...newTeam, description: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={3}
                />
              </div>
              <div className="flex justify-end space-x-4">
                <button
                  onClick={() => setShowNewTeamModal(false)}
                  className="px-4 py-2 text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCreateTeam}
                  disabled={!newTeam.name}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  Create Team
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* New User Modal */}
      {showNewUserModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg w-[600px] p-6">
            <h2 className="text-lg font-medium mb-4">Add New User</h2>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  First Name
                </label>
                <input
                  type="text"
                  value={newUser.firstName}
                  onChange={(e) => setNewUser({ ...newUser, firstName: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Last Name
                </label>
                <input
                  type="text"
                  value={newUser.lastName}
                  onChange={(e) => setNewUser({ ...newUser, lastName: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Phone
                </label>
                <input
                  type="tel"
                  value={newUser.phone}
                  onChange={(e) => setNewUser({ ...newUser, phone: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Role
                </label>
                <select
                  value={newUser.role}
                  onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select a role</option>
                  <option value="Super Admin">Super Admin</option>
                  <option value="Admin">Admin</option>
                  <option value="Manager">Manager</option>
                  <option value="User">User</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Team
                </label>
                <select
                  value={newUser.teamId}
                  onChange={(e) => setNewUser({ ...newUser, teamId: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select a team</option>
                  {teams.map(team => (
                    <option key={team.id} value={team.id}>{team.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex justify-end space-x-4 mt-6">
              <button
                onClick={() => setShowNewUserModal(false)}
                className="px-4 py-2 text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateUser}
                disabled={!newUser.firstName || !newUser.lastName || !newUser.email || !newUser.role || !newUser.teamId}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                Create User
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}