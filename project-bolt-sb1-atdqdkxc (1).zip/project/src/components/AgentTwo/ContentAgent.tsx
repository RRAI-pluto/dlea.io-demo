import React, { useState, useEffect } from 'react';
import { Book, FileText, Users, RefreshCcw, Search, X, Presentation as PresentationScreen, Video, Image, FileAudio } from 'lucide-react';
import { useConfluence } from '../../hooks/useConfluence';

interface ContentSuggestion {
  id: string;
  type: 'text' | 'multimedia' | 'training';
  title: string;
  description: string;
  format: string;
  relevance: number;
}

export function ContentAgent() {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'discover' | 'recent' | 'recommended'>('discover');
  const [searchQuery, setSearchQuery] = useState('');
  const [contentType, setContentType] = useState<'all' | 'text' | 'multimedia' | 'training'>('all');
  const [confluenceResults, setConfluenceResults] = useState<any[]>([]);

  const confluenceConfig = {
    baseUrl: 'https://your-domain.atlassian.net',
    email: 'your-email@company.com',
    apiKey: 'your-api-key'
  };

  const { searchContent, isLoading, error } = useConfluence(confluenceConfig);

  useEffect(() => {
    if (searchQuery) {
      const searchConfluence = async () => {
        try {
          const results = await searchContent(searchQuery);
          setConfluenceResults(results.results);
        } catch (err) {
          console.error('Error searching Confluence:', err);
        }
      };
      searchConfluence();
    }
  }, [searchQuery, searchContent]);

  const contentSuggestions: ContentSuggestion[] = [
    {
      id: '1',
      type: 'text',
      title: 'Sales Pitch Template - Enterprise',
      description: 'Customizable pitch deck for enterprise clients',
      format: 'presentation',
      relevance: 95
    },
    {
      id: '2',
      type: 'multimedia',
      title: 'Product Demo Video',
      description: 'Latest feature walkthrough',
      format: 'video',
      relevance: 88
    },
    {
      id: '3',
      type: 'training',
      title: 'Advanced Negotiation Skills',
      description: 'Interactive training module',
      format: 'course',
      relevance: 82
    }
  ];

  const getFormatIcon = (format: string) => {
    switch (format) {
      case 'presentation':
        return <PresentationScreen className="w-4 h-4" />;
      case 'video':
        return <Video className="w-4 h-4" />;
      case 'image':
        return <Image className="w-4 h-4" />;
      case 'audio':
        return <FileAudio className="w-4 h-4" />;
      default:
        return <FileText className="w-4 h-4" />;
    }
  };

  if (!isOpen) {
    return (
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-20 w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center shadow-lg hover:bg-purple-700 transition-colors"
      >
        <Book className="w-6 h-6 text-white" />
      </button>
    );
  }

  return (
    <div className="fixed bottom-4 right-20 w-96 h-[600px] bg-white rounded-lg shadow-xl flex flex-col">
      <div className="p-4 border-b flex justify-between items-center bg-purple-50 rounded-t-lg">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
            <Book className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-medium">Agent Two</h3>
            <p className="text-xs text-gray-500">Content Assistant</p>
          </div>
        </div>
        <button 
          onClick={() => setIsOpen(false)}
          className="text-gray-400 hover:text-gray-600"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="p-4 border-b">
        <div className="relative">
          <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search content..."
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>
      </div>

      <div className="flex border-b">
        <button
          onClick={() => setActiveTab('discover')}
          className={`flex-1 px-4 py-2 text-sm font-medium ${
            activeTab === 'discover'
              ? 'text-purple-600 border-b-2 border-purple-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Discover
        </button>
        <button
          onClick={() => setActiveTab('recent')}
          className={`flex-1 px-4 py-2 text-sm font-medium ${
            activeTab === 'recent'
              ? 'text-purple-600 border-b-2 border-purple-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Recent
        </button>
        <button
          onClick={() => setActiveTab('recommended')}
          className={`flex-1 px-4 py-2 text-sm font-medium ${
            activeTab === 'recommended'
              ? 'text-purple-600 border-b-2 border-purple-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          For You
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        <div className="flex space-x-2 mb-4">
          <button
            onClick={() => setContentType('all')}
            className={`px-3 py-1.5 rounded-full text-sm ${
              contentType === 'all'
                ? 'bg-purple-100 text-purple-600'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setContentType('text')}
            className={`px-3 py-1.5 rounded-full text-sm ${
              contentType === 'text'
                ? 'bg-purple-100 text-purple-600'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Documents
          </button>
          <button
            onClick={() => setContentType('multimedia')}
            className={`px-3 py-1.5 rounded-full text-sm ${
              contentType === 'multimedia'
                ? 'bg-purple-100 text-purple-600'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Media
          </button>
          <button
            onClick={() => setContentType('training')}
            className={`px-3 py-1.5 rounded-full text-sm ${
              contentType === 'training'
                ? 'bg-purple-100 text-purple-600'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Training
          </button>
        </div>

        <div className="space-y-3">
          {contentSuggestions.map((content) => (
            <div
              key={content.id}
              className="p-3 bg-white border border-gray-200 rounded-lg hover:border-purple-300 transition-colors cursor-pointer"
            >
              <div className="flex items-start space-x-3">
                <div className="p-2 bg-purple-50 rounded-lg">
                  {getFormatIcon(content.format)}
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-sm">{content.title}</h4>
                  <p className="text-xs text-gray-500 mt-1">{content.description}</p>
                  <div className="flex items-center space-x-2 mt-2">
                    <span className="text-xs bg-purple-50 text-purple-600 px-2 py-0.5 rounded">
                      {content.format}
                    </span>
                    <span className="text-xs text-gray-500">
                      {content.relevance}% relevant
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="p-4 border-t bg-gray-50">
        <div className="flex justify-between items-center text-sm text-gray-600">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <FileText className="w-4 h-4" />
              <span>150+ docs</span>
            </div>
            <div className="flex items-center space-x-1">
              <Users className="w-4 h-4" />
              <span>Team access</span>
            </div>
          </div>
          <button className="text-purple-600 hover:text-purple-700">
            <RefreshCcw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}