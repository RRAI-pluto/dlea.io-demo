import React, { useState, useEffect } from 'react';
import { Database, Link as LinkIcon, Phone, Send, Check, AlertTriangle, RefreshCw, Key, Globe, Mail, Building, ChevronDown, BarChart2, X, Brain } from 'lucide-react';
import { useConfluence } from '../../hooks/useConfluence';
import { useApollo } from '../../hooks/useApollo';
import { supabase } from '../../lib/supabase';
import { databaseService } from '../../services/databaseService';

interface Integration {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  status: 'connected' | 'disconnected' | 'error';
  lastSync?: Date;
  stats?: {
    label: string;
    value: string;
    change?: number;
  }[];
}

interface IntegrationConfig {
  confluenceUrl?: string;
  confluenceEmail?: string;
  confluenceApiKey?: string;
  apolloApiKey?: string;
  apolloOrgId?: string;
  salesforceUrl?: string;
  salesforceClientId?: string;
  salesforceClientSecret?: string;
  openaiApiKey?: string;
  openaiModel?: string;
}

export function IntegrationsSettings() {
  const [integrations, setIntegrations] = useState<Integration[]>([]);
  const [selectedIntegration, setSelectedIntegration] = useState<Integration | null>(null);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [config, setConfig] = useState<IntegrationConfig>({});
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [testResult, setTestResult] = useState<'success' | 'error' | null>(null);
  const [showImportModal, setShowImportModal] = useState(false);
  const [importStatus, setImportStatus] = useState<'idle' | 'loading' | 'preview' | 'error'>('idle');
  const [importPreview, setImportPreview] = useState<ImportPreview[]>([]);
  const [selectedSpaceKey, setSelectedSpaceKey] = useState('');
  const [spaces, setSpaces] = useState<Array<{ key: string; name: string }>>([]);

  const handleSaveConfig = async () => {
    try {
      const settings = {
        type: selectedIntegration?.name.toLowerCase(),
        config: config
      };

      const { error } = await databaseService.integrations.saveIntegrationSettings(settings);
      
      if (error) throw error;
      
      setShowConfigModal(false);
      alert('Integration settings saved successfully');
    } catch (error) {
      console.error('Error saving integration settings:', error);
      alert('Failed to save settings. Please try again.');
    }
  };

  const testOpenAIConnection = async (apiKey: string) => {
    try {
      const response = await fetch('/api/ai/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        }
      });
      
      if (!response.ok) throw new Error('Failed to connect to OpenAI');
      
      return true;
    } catch (error) {
      console.error('OpenAI connection test failed:', error);
      throw error;
    }
  };

  const getIntegrationIcon = (type: string) => {
    switch (type) {
      case 'salesforce':
        return <Building className="w-6 h-6 text-blue-600" />;
      case 'confluence':
        return <Database className="w-6 h-6 text-blue-600" />;
      case 'apollo':
        return <Globe className="w-6 h-6 text-purple-600" />;
      case 'outreach':
        return <Send className="w-6 h-6 text-green-600" />;
      case 'openai':
        return <Brain className="w-6 h-6 text-green-600" />;
      default:
        return <LinkIcon className="w-6 h-6 text-gray-600" />;
    }
  };

  const handleTestConnection = async (type: string) => {
    setIsTestingConnection(true);
    setTestResult(null);
    
    try {
      switch (type) {
        case 'confluence':
          await testConfluence();
          break;
        case 'apollo':
          await testApollo();
          break;
        case 'openai':
          await testOpenAIConnection(config.openaiApiKey || '');
          break;
        case 'salesforce':
          // Implement Salesforce connection test
          break;
      }
      
      setTestResult('success');
      
      // Update integration status in database
      await supabase
        .from('integrations')
        .update({ status: 'connected', last_sync: new Date().toISOString() })
        .eq('type', type);
        
      await loadIntegrations();
    } catch (error) {
      console.error(`Error testing ${type} connection:`, error);
      setTestResult('error');
    } finally {
      setIsTestingConnection(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-8">
      <div className="bg-white rounded-lg shadow-sm">
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-50 rounded-lg">
                <LinkIcon className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">Integrations</h1>
                <p className="text-gray-600">Connect and manage external services</p>
              </div>
            </div>
            <button
              onClick={() => setShowConfigModal(true)}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Integration
            </button>
          </div>
        </div>

        <div className="p-6">
          {/* Integration Cards */}
          <div className="grid grid-cols-1 gap-6">
            {integrations.map((integration) => (
              <div
                key={integration.id}
                className="border rounded-lg p-6"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-gray-50 rounded-lg">
                      {integration.icon}
                    </div>
                    <div>
                      <h3 className="font-medium">{integration.name}</h3>
                      <p className="text-sm text-gray-500">{integration.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      integration.status === 'connected' ? 'bg-green-100 text-green-800' :
                      integration.status === 'error' ? 'bg-red-100 text-red-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {integration.status}
                    </span>
                    <button
                      onClick={() => {
                        setSelectedIntegration(integration);
                        setShowConfigModal(true);
                      }}
                      className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
                    >
                      <Settings className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                {integration.stats && (
                  <div className="grid grid-cols-3 gap-4 mt-4">
                    {integration.stats.map((stat, index) => (
                      <div key={index} className="bg-gray-50 p-3 rounded-lg">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm text-gray-500">{stat.label}</span>
                          {stat.change && (
                            <span className={`text-xs font-medium ${
                              stat.change > 0 ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {stat.change > 0 ? '+' : ''}{stat.change}%
                            </span>
                          )}
                        </div>
                        <p className="text-lg font-medium">{stat.value}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Empty State */}
          {integrations.length === 0 && (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <LinkIcon className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Integrations</h3>
              <p className="text-gray-500 mb-4">Connect your first integration to get started</p>
              <button
                onClick={() => setShowConfigModal(true)}
                className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Integration
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Configuration Modal */}
      {showConfigModal && selectedIntegration && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg w-[600px] max-h-[80vh] overflow-y-auto">
            <div className="p-6 border-b">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold">Configure {selectedIntegration.name}</h2>
                <button
                  onClick={() => setShowConfigModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="p-6">
              {selectedIntegration.name === 'OpenAI' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      API Key
                    </label>
                    <input
                      type="password"
                      value={config.openaiApiKey || ''}
                      onChange={(e) => setConfig({ ...config, openaiApiKey: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter your OpenAI API key"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Model
                    </label>
                    <select
                      value={config.openaiModel || 'gpt-4'}
                      onChange={(e) => setConfig({ ...config, openaiModel: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="gpt-4">GPT-4</option>
                      <option value="gpt-4-turbo">GPT-4 Turbo</option>
                      <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
                    </select>
                  </div>
                </div>
              )}

              {testResult === 'success' && (
                <div className="mt-4 p-4 bg-green-50 text-green-800 rounded-lg flex items-center">
                  <Check className="w-5 h-5 mr-2" />
                  Connection successful
                </div>
              )}

              {testResult === 'error' && (
                <div className="mt-4 p-4 bg-red-50 text-red-800 rounded-lg flex items-center">
                  <AlertTriangle className="w-5 h-5 mr-2" />
                  Connection failed. Please check your credentials.
                </div>
              )}

              <div className="flex justify-end space-x-4 mt-6">
                <button
                  onClick={() => setShowConfigModal(false)}
                  className="px-4 py-2 text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleTestConnection(selectedIntegration.name.toLowerCase())}
                  disabled={isTestingConnection}
                  className="px-4 py-2 border border-blue-600 text-blue-600 rounded-lg hover:bg-blue-50"
                >
                  {isTestingConnection ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Testing...
                    </>
                  ) : (
                    'Test Connection'
                  )}
                </button>
                <button
                  onClick={handleSaveConfig}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Save Configuration
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}