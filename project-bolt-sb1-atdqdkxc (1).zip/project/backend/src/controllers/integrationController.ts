import { Request, Response } from 'express';
import { IntegrationService } from '../services/integrationService';

export class IntegrationController {
  private integrationService: IntegrationService;

  constructor() {
    this.integrationService = new IntegrationService();
  }

  getIntegrations = async (req: Request, res: Response) => {
    try {
      const integrations = await this.integrationService.getIntegrations();
      res.json({ success: true, data: integrations });
    } catch (error) {
      res.status(500).json({ success: false, error: 'Failed to fetch integrations' });
    }
  };

  testConnection = async (req: Request, res: Response) => {
    try {
      const { type, config } = req.body;
      const result = await this.integrationService.testConnection(type, config);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: 'Connection test failed' });
    }
  };

  configureIntegration = async (req: Request, res: Response) => {
    try {
      const { type, config } = req.body;
      const result = await this.integrationService.configureIntegration(type, config);
      res.json({ success: true, data: result });
    } catch (error) {
      res.status(500).json({ success: false, error: 'Failed to configure integration' });
    }
  };
}