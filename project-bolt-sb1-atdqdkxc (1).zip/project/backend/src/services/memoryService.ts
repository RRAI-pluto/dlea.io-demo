import { pool } from '../config/database';

export interface Memory {
  id: string;
  userId: string;
  type: 'conversation' | 'context' | 'insight';
  content: any;
  metadata?: Record<string, any>;
  createdAt: Date;
  expiresAt?: Date;
}

export class MemoryService {
  async storeMemory(memory: Omit<Memory, 'id' | 'createdAt'>): Promise<Memory> {
    const query = `
      INSERT INTO memories (user_id, type, content, metadata, expires_at)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING *
    `;

    const values = [
      memory.userId,
      memory.type,
      memory.content,
      memory.metadata || {},
      memory.expiresAt
    ];

    const result = await pool.query(query, values);
    return result.rows[0];
  }

  async getMemories(userId: string, type?: string, limit = 10): Promise<Memory[]> {
    const query = `
      SELECT *
      FROM memories
      WHERE user_id = $1
      ${type ? 'AND type = $2' : ''}
      AND (expires_at IS NULL OR expires_at > NOW())
      ORDER BY created_at DESC
      LIMIT $${type ? '3' : '2'}
    `;

    const values = type ? [userId, type, limit] : [userId, limit];
    const result = await pool.query(query, values);
    return result.rows;
  }

  async getConversationHistory(userId: string, limit = 10): Promise<Memory[]> {
    return this.getMemories(userId, 'conversation', limit);
  }

  async getContextualMemories(userId: string): Promise<Memory[]> {
    return this.getMemories(userId, 'context');
  }

  async clearExpiredMemories(): Promise<void> {
    const query = `
      DELETE FROM memories
      WHERE expires_at < NOW()
    `;
    await pool.query(query);
  }

  async summarizeMemories(userId: string): Promise<string> {
    const memories = await this.getMemories(userId);
    // Group memories by type
    const grouped = memories.reduce((acc, memory) => {
      if (!acc[memory.type]) {
        acc[memory.type] = [];
      }
      acc[memory.type].push(memory);
      return acc;
    }, {} as Record<string, Memory[]>);

    // Create summary
    let summary = '';
    if (grouped.conversation) {
      summary += 'Recent Conversations:\n';
      summary += grouped.conversation
        .map(m => `- ${new Date(m.createdAt).toLocaleDateString()}: ${m.content}`)
        .join('\n');
    }
    if (grouped.insight) {
      summary += '\n\nKey Insights:\n';
      summary += grouped.insight
        .map(m => `- ${m.content}`)
        .join('\n');
    }
    if (grouped.context) {
      summary += '\n\nContextual Information:\n';
      summary += grouped.context
        .map(m => `- ${m.content}`)
        .join('\n');
    }

    return summary;
  }
}