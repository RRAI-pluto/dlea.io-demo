import { Router } from 'express';
import userRoutes from './userRoutes.js';
import teamRoutes from './teamRoutes.js';
import integrationRoutes from './integrationRoutes.js';
import objectRoutes from './objectRoutes.js';

const router = Router();

router.use('/users', userRoutes);
router.use('/teams', teamRoutes);
router.use('/integrations', integrationRoutes);
router.use('/objects', objectRoutes);

// Basic health check route
router.get('/', (req, res) => {
  res.json({ status: 'ok', message: 'API is working' });
});

export default router;