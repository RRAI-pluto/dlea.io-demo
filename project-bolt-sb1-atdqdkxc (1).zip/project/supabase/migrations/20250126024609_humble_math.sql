/*
  # Initial Schema Setup

  1. New Tables
    - teams
      - id (uuid, primary key)
      - name (text)
      - description (text)
      - metrics (jsonb)
      - created_at (timestamptz)
      - updated_at (timestamptz)
    
    - users_teams
      - user_id (uuid, references profiles)
      - team_id (uuid, references teams)
      - role (text)
      - created_at (timestamptz)
    
    - projects
      - id (uuid, primary key)
      - title (text)
      - description (text)
      - type (text)
      - status (text)
      - author_id (uuid, references profiles)
      - created_at (timestamptz)
      - updated_at (timestamptz)
    
    - assignments
      - id (uuid, primary key)
      - project_id (uuid, references projects)
      - assignee_id (uuid, references profiles)
      - team_id (uuid, references teams)
      - status (text)
      - due_date (timestamptz)
      - created_at (timestamptz)
      - updated_at (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create teams table
CREATE TABLE IF NOT EXISTS teams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  metrics jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create users_teams table
CREATE TABLE IF NOT EXISTS users_teams (
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  team_id uuid REFERENCES teams(id) ON DELETE CASCADE,
  role text NOT NULL,
  created_at timestamptz DEFAULT now(),
  PRIMARY KEY (user_id, team_id)
);

-- Create projects table
CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  type text NOT NULL CHECK (type IN ('course', 'assessment', 'certification')),
  status text NOT NULL CHECK (status IN ('draft', 'published', 'archived')),
  author_id uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create assignments table
CREATE TABLE IF NOT EXISTS assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES projects(id) ON DELETE CASCADE,
  assignee_id uuid REFERENCES profiles(id),
  team_id uuid REFERENCES teams(id),
  status text NOT NULL CHECK (status IN ('assigned', 'in_progress', 'completed')),
  due_date timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CHECK (assignee_id IS NOT NULL OR team_id IS NOT NULL)
);

-- Enable RLS
ALTER TABLE teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE users_teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE assignments ENABLE ROW LEVEL SECURITY;

-- Teams policies
CREATE POLICY "Users can view all teams"
  ON teams
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage teams"
  ON teams
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role_id IN (SELECT id FROM roles WHERE name IN ('Admin', 'Super Admin'))
    )
  );

-- Users_teams policies
CREATE POLICY "Users can view their team memberships"
  ON users_teams
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can manage team memberships"
  ON users_teams
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role_id IN (SELECT id FROM roles WHERE name IN ('Admin', 'Super Admin'))
    )
  );

-- Projects policies
CREATE POLICY "Users can view all projects"
  ON projects
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage their own projects"
  ON projects
  USING (author_id = auth.uid());

CREATE POLICY "Admins can manage all projects"
  ON projects
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role_id IN (SELECT id FROM roles WHERE name IN ('Admin', 'Super Admin'))
    )
  );

-- Assignments policies
CREATE POLICY "Users can view assignments they're involved in"
  ON assignments
  FOR SELECT
  TO authenticated
  USING (
    assignee_id = auth.uid() OR
    team_id IN (
      SELECT team_id FROM users_teams WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update their own assignments"
  ON assignments
  FOR UPDATE
  TO authenticated
  USING (assignee_id = auth.uid())
  WITH CHECK (assignee_id = auth.uid());

CREATE POLICY "Admins can manage all assignments"
  ON assignments
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role_id IN (SELECT id FROM roles WHERE name IN ('Admin', 'Super Admin'))
    )
  );

-- Add updated_at triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_teams_updated_at
  BEFORE UPDATE ON teams
  FOR EACH ROW
  EXECUTE PROCEDURE update_updated_at_column();

CREATE TRIGGER update_projects_updated_at
  BEFORE UPDATE ON projects
  FOR EACH ROW
  EXECUTE PROCEDURE update_updated_at_column();

CREATE TRIGGER update_assignments_updated_at
  BEFORE UPDATE ON assignments
  FOR EACH ROW
  EXECUTE PROCEDURE update_updated_at_column();