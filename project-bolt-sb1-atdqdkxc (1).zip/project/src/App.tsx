import React, { useState, useEffect } from 'react';
import { Home, Filter, LayoutGrid, Users, Settings, Moon, LogOut, Search, Bot, Bell, Mail, ChevronDown, Plus, AlertTriangle, Database, Target, Tags, Link, BarChart2, Sun } from 'lucide-react';
import { ProjectBuilder } from './components/ProjectBuilder';
import { ContentAgent } from './components/AgentTwo/ContentAgent';
import { UserDetails } from './components/UserDetails';
import { Dashboard } from './components/Dashboard';
import { AIChat } from './components/AIChat';
import { SignIn } from './components/auth/SignIn';
import { SignUp } from './components/auth/SignUp';
import { FunnelAnalyst } from './components/FunnelAnalyst';
import { EnablementTickets } from './components/EnablementTickets';
import { SalesforceDataChat } from './components/SalesforceDataChat';
import { ICPSettings } from './components/settings/ICPSettings';
import { TagManager } from './components/settings/TagManager';
import { IntegrationsSettings } from './components/settings/IntegrationsSettings';
import { GamificationSettings } from './components/settings/GamificationSettings';
import { MicroLearningsSettings } from './components/settings/MicroLearningsSettings';
import { Reports } from './components/Reports';
import { MessagingPanel } from './components/Messaging/MessagingPanel';
import { TrainingTickets } from './components/TrainingTickets';
import { Sidebar } from './components/Sidebar';
import { UsersAndTeams } from './components/UsersAndTeams';
import { NotificationCenter } from './components/notifications/NotificationCenter';

type ViewType = 'dashboard' | 'funnel' | 'config' | 'users' | 'tickets' | 'reports' | 'settings-icp' | 'settings-tags' | 'settings-integrations' | 'settings-gamification' | 'settings-microlearnings' | 'training';

function App() {
  const [view, setView] = useState<ViewType>('dashboard');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showSignUp, setShowSignUp] = useState(false);
  const [showNewFunnel, setShowNewFunnel] = useState(false);
  const [showDataChat, setShowDataChat] = useState(false);
  const [showMessaging, setShowMessaging] = useState(false);
  const [settingsExpanded, setSettingsExpanded] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    const savedDarkMode = localStorage.getItem('darkMode') === 'true';
    setIsDarkMode(savedDarkMode);
    if (savedDarkMode) {
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleDarkMode = () => {
    const newDarkMode = !isDarkMode;
    setIsDarkMode(newDarkMode);
    localStorage.setItem('darkMode', String(newDarkMode));
    document.documentElement.classList.toggle('dark');
  };

  const handleNavigateToTicket = (ticketId: string) => {
    setView('tickets');
  };

  if (!isAuthenticated) {
    if (showSignUp) {
      return (
        <SignUp
          onSuccess={() => setIsAuthenticated(true)}
          onSignInClick={() => setShowSignUp(false)}
        />
      );
    }
    return (
      <SignIn
        onSuccess={() => setIsAuthenticated(true)}
        onSignUpClick={() => setShowSignUp(true)}
      />
    );
  }

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark' : ''} bg-gray-50 dark:bg-gray-900`}>
      <Sidebar 
        onNavigate={setView} 
        activeView={view}
        showNewFunnel={showNewFunnel}
        setShowNewFunnel={setShowNewFunnel}
        settingsExpanded={settingsExpanded}
        setSettingsExpanded={setSettingsExpanded}
        isDarkMode={isDarkMode}
        onDarkModeToggle={toggleDarkMode}
      />
      <div className="ml-64">
        <Header 
          onDataChatToggle={() => setShowDataChat(!showDataChat)} 
          onMessagingToggle={() => setShowMessaging(!showMessaging)}
          onNavigateToTicket={handleNavigateToTicket}
          isDarkMode={isDarkMode} 
        />
        <main className="pt-16">
          {view === 'dashboard' && <Dashboard />}
          {view === 'funnel' && <FunnelAnalyst isNewFunnel={showNewFunnel} />}
          {view === 'config' && <ProjectBuilder />}
          {view === 'users' && <UsersAndTeams />}
          {view === 'tickets' && <EnablementTickets onNavigate={setView} />}
          {view === 'training' && <TrainingTickets />}
          {view === 'reports' && <Reports />}
          {view === 'settings-icp' && <ICPSettings />}
          {view === 'settings-tags' && <TagManager />}
          {view === 'settings-integrations' && <IntegrationsSettings />}
          {view === 'settings-gamification' && <GamificationSettings />}
          {view === 'settings-microlearnings' && <MicroLearningsSettings />}
        </main>
      </div>
      <AIChat />
      <ContentAgent />
      <SalesforceDataChat isOpen={showDataChat} onClose={() => setShowDataChat(false)} />
      <MessagingPanel isOpen={showMessaging} onClose={() => setShowMessaging(false)} />
    </div>
  );
}

interface HeaderProps {
  onDataChatToggle: () => void;
  onMessagingToggle: () => void;
  onNavigateToTicket: (ticketId: string) => void;
  isDarkMode: boolean;
}

function Header({ onDataChatToggle, onMessagingToggle, onNavigateToTicket, isDarkMode }: HeaderProps) {
  return (
    <header className="h-16 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 fixed top-0 left-64 right-0 z-10">
      <div className="flex items-center justify-between h-full px-6">
        <div className="flex-1 max-w-2xl">
          <div className="relative">
            <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search..."
              className="w-full pl-10 pr-4 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
            />
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <button 
            onClick={onDataChatToggle}
            className="p-2 text-gray-600 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
          >
            <Database className="w-6 h-6" />
          </button>
          <button className="p-2 text-gray-600 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
            <Bot className="w-6 h-6" />
          </button>
          <div className="h-6 w-px bg-gray-200 dark:bg-gray-700"></div>
          <NotificationCenter onNavigateToTicket={onNavigateToTicket} />
          <button 
            onClick={onMessagingToggle}
            className="p-2 text-gray-600 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
          >
            <Mail className="w-6 h-6" />
          </button>
          <button className="flex items-center space-x-2 pl-4">
            <div className="flex flex-col items-end">
              <span className="font-medium text-gray-900 dark:text-white">Dominic Lacy</span>
              <span className="text-sm text-gray-500 dark:text-gray-400">VP of Enablement</span>
            </div>
            <img
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
              alt="Profile"
              className="w-10 h-10 rounded-full"
            />
            <ChevronDown className="w-5 h-5 text-gray-500 dark:text-gray-400" />
          </button>
        </div>
      </div>
    </header>
  );
}

export default App;