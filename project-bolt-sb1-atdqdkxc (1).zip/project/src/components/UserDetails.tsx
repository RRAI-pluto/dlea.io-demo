import React, { useState } from 'react';
import { Trash2, Link, ChevronLeft, BarChart2, Brain, Zap, Award } from 'lucide-react';

interface MetricDetailsProps {
  metric: string;
  value: number;
  data: any[];
  onClose: () => void;
}

function MetricDetails({ metric, value, data, onClose }: MetricDetailsProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-[800px] max-h-[80vh] overflow-y-auto">
        <div className="p-6 border-b">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <button onClick={onClose} className="hover:bg-gray-100 p-2 rounded-lg">
                <ChevronLeft className="w-5 h-5" />
              </button>
              <h2 className="text-xl font-bold">{metric} Details</h2>
            </div>
            <span className="text-2xl font-bold text-blue-600">{value}%</span>
          </div>
        </div>
        
        <div className="p-6">
          <div className="space-y-6">
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="font-medium mb-1">Historical Average</h3>
                <p className="text-2xl font-bold text-blue-600">78%</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="font-medium mb-1">Team Average</h3>
                <p className="text-2xl font-bold text-green-600">82%</p>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <h3 className="font-medium mb-1">Target</h3>
                <p className="text-2xl font-bold text-purple-600">85%</p>
              </div>
            </div>

            <div className="bg-white border rounded-lg p-4">
              <h3 className="font-medium mb-4">Performance Trend</h3>
              <div className="h-64 w-full bg-gray-50 rounded flex items-center justify-center">
                [Performance Chart Would Go Here]
              </div>
            </div>

            <div className="bg-white border rounded-lg p-4">
              <h3 className="font-medium mb-4">Improvement Suggestions</h3>
              <ul className="space-y-3">
                <li className="flex items-start space-x-3">
                  <div className="p-1.5 bg-blue-100 rounded-lg">
                    <Brain className="w-4 h-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium">Complete Advanced Training</p>
                    <p className="text-sm text-gray-600">Enroll in the advanced sales techniques course</p>
                  </div>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="p-1.5 bg-green-100 rounded-lg">
                    <Zap className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium">Increase Demo Quality</p>
                    <p className="text-sm text-gray-600">Focus on personalized product demonstrations</p>
                  </div>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="p-1.5 bg-purple-100 rounded-lg">
                    <Award className="w-4 h-4 text-purple-600" />
                  </div>
                  <div>
                    <p className="font-medium">Optimize Follow-up Strategy</p>
                    <p className="text-sm text-gray-600">Implement structured follow-up sequence</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function UserDetails() {
  const [selectedMetric, setSelectedMetric] = useState<string | null>(null);
  
  const metrics = [
    { name: 'Quota Attainment', value: 90, icon: BarChart2 },
    { name: 'Learning Score', value: 60, icon: Brain },
    { name: 'Velocity', value: 20, icon: Zap },
    { name: 'Skill Proficiency', value: 100, icon: Award }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow">
          {/* Profile Section */}
          <div className="px-8 py-8">
            <div className="flex justify-between items-start mb-6">
              <div className="flex items-center space-x-5">
                <img
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
                  alt="Profile"
                  className="w-24 h-24 rounded-full border-4 border-white shadow-lg"
                />
                <div>
                  <h1 className="text-2xl font-bold">Dominic Lacy</h1>
                  <p className="text-gray-600">VP of Enablement</p>
                </div>
              </div>
              <div className="flex space-x-3">
                <button className="p-2 text-gray-400 hover:text-gray-500">
                  <Trash2 className="w-5 h-5" />
                </button>
                <button className="p-2 text-gray-400 hover:text-gray-500">
                  <Link className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Key Information */}
            <div className="grid grid-cols-3 gap-6 mb-8">
              <div>
                <h3 className="text-sm font-medium text-gray-500">Team</h3>
                <p className="mt-1 text-lg font-medium">Enterprise Sales</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Manager</h3>
                <p className="mt-1 text-lg font-medium">Chris Chan</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Quota</h3>
                <p className="mt-1 text-lg font-medium">$25,000</p>
              </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-4 gap-4">
              {metrics.map((metric) => {
                const Icon = metric.icon;
                return (
                  <button
                    key={metric.name}
                    onClick={() => setSelectedMetric(metric.name)}
                    className="p-4 bg-white border rounded-lg hover:border-blue-500 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="p-2 bg-blue-50 rounded-lg">
                        <Icon className="w-5 h-5 text-blue-600" />
                      </div>
                      <span className="text-sm text-gray-500">vs last period</span>
                    </div>
                    <h3 className="text-2xl font-bold mb-1">{metric.value}%</h3>
                    <p className="text-gray-600 text-sm">{metric.name}</p>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Metric Details Modal */}
        {selectedMetric && (
          <MetricDetails
            metric={selectedMetric}
            value={metrics.find(m => m.name === selectedMetric)?.value || 0}
            data={[]}
            onClose={() => setSelectedMetric(null)}
          />
        )}
      </div>
    </div>
  );
}