import { Router } from 'express';
import { IntegrationController } from '../controllers/integrationController';
import { authMiddleware } from '../middleware/authMiddleware';

const router = Router();
const integrationController = new IntegrationController();

router.get('/', authMiddleware, integrationController.getIntegrations);
router.post('/test-connection', authMiddleware, integrationController.testConnection);
router.post('/configure', authMiddleware, integrationController.configureIntegration);

export default router;