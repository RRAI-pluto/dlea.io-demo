import { v4 as uuidv4 } from 'uuid';

export interface Notification {
  id: string;
  title: string;
  description: string;
  type: 'alert' | 'insight' | 'message';
  status: 'unread' | 'read';
  createdAt: Date;
  priority?: 'high' | 'medium' | 'low';
  metrics?: {
    label: string;
    value: string;
    change: number;
  }[];
  ticketId?: string;
}

export const dummyNotifications: Notification[] = [
  {
    id: uuidv4(),
    title: 'New Call Recording Available',
    description: 'Technical Requirements Review with Enterprise SaaS client has been analyzed',
    type: 'alert',
    status: 'unread',
    createdAt: new Date(),
    priority: 'high',
    ticketId: '3'
  },
  {
    id: uuidv4(),
    title: 'Timeline Risk Detected',
    description: 'AI analysis detected potential timeline risks in Global Financial Solutions deal',
    type: 'alert',
    status: 'unread',
    createdAt: new Date(),
    priority: 'high',
    metrics: [
      { label: 'Risk Score', value: '85%', change: 15 },
      { label: 'Timeline Impact', value: '2 weeks', change: 10 }
    ]
  },
  {
    id: uuidv4(),
    title: 'Content Recommendation',
    description: 'New security whitepaper matches Enterprise SaaS opportunity requirements',
    type: 'insight',
    status: 'read',
    createdAt: new Date(),
    priority: 'medium'
  }
];