import React, { useState } from 'react';
import { Users, Plus, Trash2, DollarSign, Target, TrendingUp, BarChart2 } from 'lucide-react';

interface TeamMember {
  id: string;
  name: string;
  role: string;
}

interface TeamMetrics {
  revenue: number;
  quota: number;
  deals: number;
  conversion: number;
}

interface Team {
  id: string;
  name: string;
  description: string;
  members: TeamMember[];
  metrics: TeamMetrics;
  createdAt: Date;
}

export function TeamManagement() {
  const [teams, setTeams] = useState<Team[]>([]);
  const [showNewTeamForm, setShowNewTeamForm] = useState(false);
  const [newTeam, setNewTeam] = useState<Partial<Team>>({
    name: '',
    description: '',
    members: [],
    metrics: {
      revenue: 0,
      quota: 0,
      deals: 0,
      conversion: 0
    }
  });

  const handleCreateTeam = () => {
    if (!newTeam.name) return;

    const team: Team = {
      id: Date.now().toString(),
      name: newTeam.name!,
      description: newTeam.description || '',
      members: newTeam.members || [],
      metrics: newTeam.metrics as TeamMetrics,
      createdAt: new Date()
    };

    setTeams([...teams, team]);
    setNewTeam({
      name: '',
      description: '',
      members: [],
      metrics: {
        revenue: 0,
        quota: 0,
        deals: 0,
        conversion: 0
      }
    });
    setShowNewTeamForm(false);
  };

  const handleDeleteTeam = (teamId: string) => {
    setTeams(teams.filter(team => team.id !== teamId));
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">Team Management</h1>
              <p className="text-gray-600">Create and manage sales teams</p>
            </div>
            <button
              onClick={() => setShowNewTeamForm(true)}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Plus className="w-5 h-5 mr-2" />
              Create New Team
            </button>
          </div>

          {showNewTeamForm && (
            <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
              <h2 className="text-lg font-medium mb-4">Create New Team</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Team Name
                  </label>
                  <input
                    type="text"
                    value={newTeam.name}
                    onChange={(e) => setNewTeam({ ...newTeam, name: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter team name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    value={newTeam.description}
                    onChange={(e) => setNewTeam({ ...newTeam, description: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter team description"
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Revenue Target ($)
                    </label>
                    <input
                      type="number"
                      value={newTeam.metrics?.revenue}
                      onChange={(e) => setNewTeam({
                        ...newTeam,
                        metrics: { ...newTeam.metrics as TeamMetrics, revenue: Number(e.target.value) }
                      })}
                      className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter revenue target"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Quota ($)
                    </label>
                    <input
                      type="number"
                      value={newTeam.metrics?.quota}
                      onChange={(e) => setNewTeam({
                        ...newTeam,
                        metrics: { ...newTeam.metrics as TeamMetrics, quota: Number(e.target.value) }
                      })}
                      className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter quota"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Deal Target
                    </label>
                    <input
                      type="number"
                      value={newTeam.metrics?.deals}
                      onChange={(e) => setNewTeam({
                        ...newTeam,
                        metrics: { ...newTeam.metrics as TeamMetrics, deals: Number(e.target.value) }
                      })}
                      className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter deal target"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Target Conversion Rate (%)
                    </label>
                    <input
                      type="number"
                      value={newTeam.metrics?.conversion}
                      onChange={(e) => setNewTeam({
                        ...newTeam,
                        metrics: { ...newTeam.metrics as TeamMetrics, conversion: Number(e.target.value) }
                      })}
                      className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter conversion rate"
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-4 pt-4">
                  <button
                    onClick={() => setShowNewTeamForm(false)}
                    className="px-4 py-2 text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleCreateTeam}
                    disabled={!newTeam.name}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  >
                    Create Team
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Teams Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {teams.map((team) => (
              <div key={team.id} className="bg-white rounded-lg shadow-sm">
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-medium">{team.name}</h3>
                      <p className="text-gray-600 text-sm">{team.description}</p>
                    </div>
                    <button
                      onClick={() => handleDeleteTeam(team.id)}
                      className="text-gray-400 hover:text-red-500"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-2 mb-2">
                        <DollarSign className="w-5 h-5 text-green-600" />
                        <span className="text-sm font-medium">Revenue Target</span>
                      </div>
                      <p className="text-xl font-bold">${team.metrics.revenue.toLocaleString()}</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-2 mb-2">
                        <Target className="w-5 h-5 text-blue-600" />
                        <span className="text-sm font-medium">Quota</span>
                      </div>
                      <p className="text-xl font-bold">${team.metrics.quota.toLocaleString()}</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-2 mb-2">
                        <BarChart2 className="w-5 h-5 text-purple-600" />
                        <span className="text-sm font-medium">Deal Target</span>
                      </div>
                      <p className="text-xl font-bold">{team.metrics.deals}</p>
                    </div>
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-2 mb-2">
                        <TrendingUp className="w-5 h-5 text-orange-600" />
                        <span className="text-sm font-medium">Conversion</span>
                      </div>
                      <p className="text-xl font-bold">{team.metrics.conversion}%</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}