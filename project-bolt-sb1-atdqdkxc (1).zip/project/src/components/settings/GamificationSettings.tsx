import React, { useState } from 'react';
import { Brain, Save, Clock, AlertTriangle, HelpCircle, Plus, X, MessageSquare, Calendar } from 'lucide-react';
import { databaseService } from '../../services/databaseService';

interface PointRule {
  id: string;
  type: string;
  points: number;
  description: string;
  enabled: boolean;
}

interface AchievementLevel {
  id: string;
  name: string;
  points: number;
  badge: string;
  enabled: boolean;
}

export function GamificationSettings() {
  const [isEnabled, setIsEnabled] = useState(false);
  const [pointTerm, setPointTerm] = useState('points');
  const [leaderboardVisible, setLeaderboardVisible] = useState(true);
  const [pointExpiration, setPointExpiration] = useState(90); // days
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  const [pointRules, setPointRules] = useState<PointRule[]>([
    {
      id: '1',
      type: 'course_completion',
      points: 100,
      description: 'Complete a training course',
      enabled: true
    },
    {
      id: '2',
      type: 'assessment_score',
      points: 50,
      description: 'Score 90% or higher on assessment',
      enabled: true
    },
    {
      id: '3',
      type: 'completion_streak',
      points: 25,
      description: 'Complete 3 courses in a week',
      enabled: true
    },
    {
      id: '4',
      type: 'early_completion',
      points: 30,
      description: 'Complete course before due date',
      enabled: true
    }
  ]);

  const handleSaveChanges = async () => {
    try {
      const settings = {
        enabled: isEnabled,
        point_term: pointTerm,
        point_expiration_days: pointExpiration,
        leaderboard_visible: leaderboardVisible,
        point_rules: pointRules
      };

      const { error } = await databaseService.settings.saveGamificationSettings(settings);
      
      if (error) throw error;
      
      setHasUnsavedChanges(false);
      alert('Settings saved successfully');
    } catch (error) {
      console.error('Error saving gamification settings:', error);
      alert('Failed to save settings. Please try again.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-8">
      <div className="bg-white rounded-lg shadow-sm">
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-50 rounded-lg">
                <Brain className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">Gamification</h1>
                <p className="text-gray-600">Configure the platform's reward system</p>
              </div>
            </div>
            <button
              onClick={handleSaveChanges}
              disabled={!hasUnsavedChanges}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </button>
          </div>
        </div>

        <div className="p-6 space-y-8">
          {/* Master Toggle */}
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <MessageSquare className="w-5 h-5 text-purple-600" />
              <div>
                <h3 className="font-medium">Enable Gamification</h3>
                <p className="text-sm text-gray-500">Turn on points and rewards system platform-wide</p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={isEnabled}
                onChange={(e) => {
                  setIsEnabled(e.target.checked);
                  setHasUnsavedChanges(true);
                }}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          {/* Point Rules */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Point Rules</h3>
            <div className="space-y-4">
              {pointRules.map((rule) => (
                <div key={rule.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={rule.enabled}
                      onChange={(e) => {
                        setPointRules(rules =>
                          rules.map(r =>
                            r.id === rule.id ? { ...r, enabled: e.target.checked } : r
                          )
                        );
                        setHasUnsavedChanges(true);
                      }}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <div>
                      <p className="font-medium">{rule.description}</p>
                      <p className="text-sm text-gray-500">{rule.points} {pointTerm}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Settings */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Settings</h3>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Point Terminology
                </label>
                <select
                  value={pointTerm}
                  onChange={(e) => {
                    setPointTerm(e.target.value);
                    setHasUnsavedChanges(true);
                  }}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="points">Points</option>
                  <option value="credits">Credits</option>
                  <option value="stars">Stars</option>
                  <option value="tokens">Tokens</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Point Expiration (Days)
                </label>
                <input
                  type="number"
                  value={pointExpiration}
                  onChange={(e) => {
                    setPointExpiration(parseInt(e.target.value));
                    setHasUnsavedChanges(true);
                  }}
                  min="0"
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Leaderboard Settings */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Leaderboard Settings</h3>
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <h4 className="font-medium">Show Leaderboard</h4>
                <p className="text-sm text-gray-500">Display rankings and achievements to all users</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={leaderboardVisible}
                  onChange={(e) => {
                    setLeaderboardVisible(e.target.checked);
                    setHasUnsavedChanges(true);
                  }}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}