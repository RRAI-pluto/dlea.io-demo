import React, { useState } from 'react';
import { Mic, Play, Pause, SkipForward, SkipBack, Upload, Bot, Brain, ChevronDown, Search, Filter, AlertTriangle, BarChart2, MessageSquare, Clock, Download, Settings, RefreshCw } from 'lucide-react';

interface CallRecording {
  id: string;
  title: string;
  date: Date;
  duration: number;
  speaker: string;
  source: 'gong' | 'chorus' | 'salesforce';
  status: 'analyzed' | 'pending' | 'error';
  sentiment: 'positive' | 'neutral' | 'negative';
  keyInsights: string[];
  transcriptUrl: string;
  scorecard?: {
    name: string;
    score: number;
    criteria: {
      name: string;
      score: number;
      weight: number;
      type: 'behavior' | 'keyword' | 'sentiment';
    }[];
  };
  metrics: {
    talkRatio: number;
    interruptionRate: number;
    questionRate: number;
    paceWPM: number;
  };
}

export function CallRecordingManager() {
  const [recordings, setRecordings] = useState<CallRecording[]>([]);
  const [selectedRecording, setSelectedRecording] = useState<CallRecording | null>(null);
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSource, setFilterSource] = useState<'all' | 'gong' | 'chorus' | 'salesforce'>('all');
  const [filterSentiment, setFilterSentiment] = useState<'all' | 'positive' | 'neutral' | 'negative'>('all');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showImport, setShowImport] = useState(false);

  const handleImportRecordings = async () => {
    setIsAnalyzing(true);
    try {
      // Simulate API call to import and analyze recordings
      await new Promise(resolve => setTimeout(resolve, 2000));

      const newRecordings: CallRecording[] = [
        {
          id: '1',
          title: 'Enterprise Deal Discovery Call',
          date: new Date('2025-01-24T10:30:00'),
          duration: 45,
          speaker: 'Sarah Chen',
          source: 'gong',
          status: 'analyzed',
          sentiment: 'positive',
          keyInsights: [
            'Strong needs analysis conducted',
            'Customer expressed budget concerns',
            'Technical requirements well documented',
            'Next steps clearly defined'
          ],
          transcriptUrl: '#',
          scorecard: {
            name: 'Discovery Excellence',
            score: 85,
            criteria: [
              { name: 'Needs Analysis', score: 90, weight: 30, type: 'behavior' },
              { name: 'Active Listening', score: 85, weight: 25, type: 'behavior' },
              { name: 'Value Articulation', score: 80, weight: 25, type: 'keyword' },
              { name: 'Engagement Level', score: 85, weight: 20, type: 'sentiment' }
            ]
          },
          metrics: {
            talkRatio: 45,
            interruptionRate: 2,
            questionRate: 12,
            paceWPM: 150
          }
        },
        {
          id: '2',
          title: 'Technical Solution Review',
          date: new Date('2025-01-24T14:15:00'),
          duration: 60,
          speaker: 'Michael Rodriguez',
          source: 'chorus',
          status: 'analyzed',
          sentiment: 'neutral',
          keyInsights: [
            'Complex integration requirements discussed',
            'Security concerns addressed',
            'Performance benchmarks reviewed',
            'Follow-up demo scheduled'
          ],
          transcriptUrl: '#',
          scorecard: {
            name: 'Technical Presentation',
            score: 78,
            criteria: [
              { name: 'Technical Accuracy', score: 95, weight: 35, type: 'keyword' },
              { name: 'Solution Alignment', score: 75, weight: 25, type: 'behavior' },
              { name: 'Clarity of Explanation', score: 70, weight: 25, type: 'behavior' },
              { name: 'Customer Comprehension', score: 70, weight: 15, type: 'sentiment' }
            ]
          },
          metrics: {
            talkRatio: 60,
            interruptionRate: 4,
            questionRate: 8,
            paceWPM: 165
          }
        }
      ];

      setRecordings(prev => [...prev, ...newRecordings]);
    } catch (error) {
      console.error('Error importing recordings:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive':
        return 'bg-green-100 text-green-800';
      case 'negative':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const getSourceIcon = (source: string) => {
    switch (source) {
      case 'gong':
        return <Mic className="w-5 h-5 text-purple-600" />;
      case 'chorus':
        return <Mic className="w-5 h-5 text-blue-600" />;
      case 'salesforce':
        return <Mic className="w-5 h-5 text-green-600" />;
      default:
        return <Mic className="w-5 h-5 text-gray-600" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-8">
      <div className="bg-white rounded-lg shadow-sm">
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold">Call Recording Analysis</h1>
              <p className="text-gray-600">Import and analyze sales call recordings</p>
            </div>
            <div className="flex space-x-4">
              <button
                onClick={handleImportRecordings}
                disabled={isAnalyzing}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                {isAnalyzing ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4 mr-2" />
                    Import Recordings
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        <div className="p-6">
          {/* Search and Filters */}
          <div className="flex space-x-4 mb-6">
            <div className="flex-1 relative">
              <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search recordings..."
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <select
              value={filterSource}
              onChange={(e) => setFilterSource(e.target.value as any)}
              className="px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Sources</option>
              <option value="gong">Gong</option>
              <option value="chorus">Chorus</option>
              <option value="salesforce">Salesforce</option>
            </select>
            <select
              value={filterSentiment}
              onChange={(e) => setFilterSentiment(e.target.value as any)}
              className="px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Sentiment</option>
              <option value="positive">Positive</option>
              <option value="neutral">Neutral</option>
              <option value="negative">Negative</option>
            </select>
          </div>

          {/* Recordings List */}
          <div className="space-y-4">
            {recordings.map((recording) => (
              <div key={recording.id} className="border rounded-lg">
                <div className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-gray-50 rounded-lg">
                        {getSourceIcon(recording.source)}
                      </div>
                      <div>
                        <h3 className="font-medium">{recording.title}</h3>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-sm text-gray-500">
                            {recording.speaker}
                          </span>
                          <span className="text-sm text-gray-500">
                            • {recording.duration} min
                          </span>
                          <span className="text-sm text-gray-500">
                            • {recording.date.toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        getSentimentColor(recording.sentiment)
                      }`}>
                        {recording.sentiment}
                      </span>
                      <button
                        onClick={() => {
                          setSelectedRecording(recording);
                          setShowAnalysis(true);
                        }}
                        className="flex items-center space-x-1 px-3 py-1.5 text-sm text-blue-600 hover:bg-blue-50 rounded-lg"
                      >
                        <Brain className="w-4 h-4" />
                        <span>View Analysis</span>
                      </button>
                    </div>
                  </div>

                  {/* Quick Metrics */}
                  <div className="grid grid-cols-4 gap-4 mb-4">
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-gray-500">Talk Ratio</span>
                        <MessageSquare className="w-4 h-4 text-blue-600" />
                      </div>
                      <p className="text-lg font-medium">{recording.metrics.talkRatio}%</p>
                    </div>
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-gray-500">Interruptions</span>
                        <AlertTriangle className="w-4 h-4 text-yellow-600" />
                      </div>
                      <p className="text-lg font-medium">{recording.metrics.interruptionRate}/hr</p>
                    </div>
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-gray-500">Questions</span>
                        <Filter className="w-4 h-4 text-purple-600" />
                      </div>
                      <p className="text-lg font-medium">{recording.metrics.questionRate}/hr</p>
                    </div>
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-gray-500">Pace</span>
                        <Clock className="w-4 h-4 text-green-600" />
                      </div>
                      <p className="text-lg font-medium">{recording.metrics.paceWPM} WPM</p>
                    </div>
                  </div>

                  {/* Key Insights */}
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Key Insights</h4>
                    <div className="flex flex-wrap gap-2">
                      {recording.keyInsights.map((insight, index) => (
                        <span
                          key={index}
                          className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm"
                        >
                          {insight}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Scorecard Summary */}
                  {recording.scorecard && (
                    <div className="mt-4 pt-4 border-t">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-medium text-gray-700">
                          {recording.scorecard.name}
                        </h4>
                        <span className={`text-lg font-medium ${
                          recording.scorecard.score >= 80 ? 'text-green-600' :
                          recording.scorecard.score >= 60 ? 'text-yellow-600' :
                          'text-red-600'
                        }`}>
                          {recording.scorecard.score}%
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        {recording.scorecard.criteria.map((criterion, index) => (
                          <div key={index} className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">{criterion.name}</span>
                            <span className={`text-sm font-medium ${
                              criterion.score >= 80 ? 'text-green-600' :
                              criterion.score >= 60 ? 'text-yellow-600' :
                              'text-red-600'
                            }`}>
                              {criterion.score}%
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Empty State */}
          {recordings.length === 0 && (
            <div className="text-center py-12">
              <Mic className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Recordings Analyzed</h3>
              <p className="text-gray-500 mb-4">Import recordings to start analyzing sales conversations</p>
              <button
                onClick={handleImportRecordings}
                disabled={isAnalyzing}
                className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Upload className="w-4 h-4 mr-2" />
                Import Recordings
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}