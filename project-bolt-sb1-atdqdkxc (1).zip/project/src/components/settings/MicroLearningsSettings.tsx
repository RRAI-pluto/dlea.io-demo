import React, { useState } from 'react';
import { Brain, Save, Clock, AlertTriangle, HelpCircle, Plus, X, MessageSquare, Calendar } from 'lucide-react';
import { databaseService } from '../../services/databaseService';

interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  category: string;
  enabled: boolean;
}

interface Schedule {
  frequency: 'daily' | 'weekly';
  questionsPerDay: number;
  timeWindow: {
    start: string;
    end: string;
  };
}

export function MicroLearningsSettings() {
  const [isEnabled, setIsEnabled] = useState(false);
  const [schedule, setSchedule] = useState<Schedule>({
    frequency: 'daily',
    questionsPerDay: 2,
    timeWindow: {
      start: '09:00',
      end: '17:00'
    }
  });

  const [questions, setQuestions] = useState<Question[]>([
    {
      id: '1',
      question: 'What is the key benefit of our enterprise security feature?',
      options: [
        'Faster performance',
        'Enhanced data protection',
        'Better UI experience',
        'Lower cost'
      ],
      correctAnswer: 1,
      category: 'Product Knowledge',
      enabled: true
    },
    {
      id: '2',
      question: 'Which stage of the sales process typically follows discovery?',
      options: [
        'Closing',
        'Proposal',
        'Solution presentation',
        'Negotiation'
      ],
      correctAnswer: 2,
      category: 'Sales Process',
      enabled: true
    }
  ]);

  const [showNewQuestion, setShowNewQuestion] = useState(false);
  const [newQuestion, setNewQuestion] = useState<Partial<Question>>({
    question: '',
    options: ['', '', '', ''],
    correctAnswer: 0,
    category: 'Product Knowledge',
    enabled: true
  });

  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  const handleSaveChanges = async () => {
    try {
      const settings = {
        enabled: isEnabled,
        schedule,
        questions
      };

      const { error } = await databaseService.settings.saveMicroLearningSettings(settings);
      
      if (error) throw error;
      
      setHasUnsavedChanges(false);
      alert('Settings saved successfully');
    } catch (error) {
      console.error('Error saving micro-learning settings:', error);
      alert('Failed to save settings. Please try again.');
    }
  };

  const handleAddQuestion = () => {
    if (!newQuestion.question || newQuestion.options.some(opt => !opt)) return;

    const question: Question = {
      id: Date.now().toString(),
      question: newQuestion.question,
      options: newQuestion.options,
      correctAnswer: newQuestion.correctAnswer || 0,
      category: newQuestion.category || 'Product Knowledge',
      enabled: true
    };

    setQuestions([...questions, question]);
    setNewQuestion({
      question: '',
      options: ['', '', '', ''],
      correctAnswer: 0,
      category: 'Product Knowledge',
      enabled: true
    });
    setShowNewQuestion(false);
    setHasUnsavedChanges(true);
  };

  return (
    <div className="max-w-4xl mx-auto py-8">
      <div className="bg-white rounded-lg shadow-sm">
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-50 rounded-lg">
                <Brain className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">Micro-Learnings</h1>
                <p className="text-gray-600">Configure bite-sized learning questions</p>
              </div>
            </div>
            <button
              onClick={handleSaveChanges}
              disabled={!hasUnsavedChanges}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </button>
          </div>
        </div>

        <div className="p-6 space-y-8">
          {/* Master Toggle */}
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <MessageSquare className="w-5 h-5 text-purple-600" />
              <div>
                <h3 className="font-medium">Enable Micro-Learnings</h3>
                <p className="text-sm text-gray-500">Send quick questions to users throughout the day</p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={isEnabled}
                onChange={(e) => {
                  setIsEnabled(e.target.checked);
                  setHasUnsavedChanges(true);
                }}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          {/* Schedule Settings */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Schedule Settings</h3>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Frequency
                </label>
                <select
                  value={schedule.frequency}
                  onChange={(e) => {
                    setSchedule({ ...schedule, frequency: e.target.value as 'daily' | 'weekly' });
                    setHasUnsavedChanges(true);
                  }}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Questions Per Day
                </label>
                <input
                  type="number"
                  value={schedule.questionsPerDay}
                  onChange={(e) => {
                    setSchedule({ ...schedule, questionsPerDay: parseInt(e.target.value) });
                    setHasUnsavedChanges(true);
                  }}
                  min="1"
                  max="5"
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Start Time
                </label>
                <input
                  type="time"
                  value={schedule.timeWindow.start}
                  onChange={(e) => {
                    setSchedule({
                      ...schedule,
                      timeWindow: { ...schedule.timeWindow, start: e.target.value }
                    });
                    setHasUnsavedChanges(true);
                  }}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  End Time
                </label>
                <input
                  type="time"
                  value={schedule.timeWindow.end}
                  onChange={(e) => {
                    setSchedule({
                      ...schedule,
                      timeWindow: { ...schedule.timeWindow, end: e.target.value }
                    });
                    setHasUnsavedChanges(true);
                  }}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Questions List */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Questions</h3>
              <button
                onClick={() => setShowNewQuestion(true)}
                className="flex items-center px-3 py-1.5 text-sm text-blue-600 hover:bg-blue-50 rounded-lg"
              >
                <Plus className="w-4 h-4 mr-1" />
                Add Question
              </button>
            </div>

            <div className="space-y-4">
              {questions.map(question => (
                <div key={question.id} className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <input
                        type="checkbox"
                        checked={question.enabled}
                        onChange={(e) => {
                          setQuestions(questions.map(q =>
                            q.id === question.id ? { ...q, enabled: e.target.checked } : q
                          ));
                          setHasUnsavedChanges(true);
                        }}
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs font-medium rounded">
                        {question.category}
                      </span>
                    </div>
                    <button
                      onClick={() => {
                        setQuestions(questions.filter(q => q.id !== question.id));
                        setHasUnsavedChanges(true);
                      }}
                      className="text-gray-400 hover:text-red-500"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="font-medium mb-3">{question.question}</p>
                  <div className="space-y-2">
                    {question.options.map((option, index) => (
                      <div
                        key={index}
                        className={`p-2 rounded ${
                          index === question.correctAnswer
                            ? 'bg-green-50 border border-green-200'
                            : 'bg-gray-50'
                        }`}
                      >
                        {option}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* New Question Form */}
          {showNewQuestion && (
            <div className="border-t pt-6">
              <h3 className="text-lg font-medium mb-4">Add New Question</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Question
                  </label>
                  <input
                    type="text"
                    value={newQuestion.question}
                    onChange={(e) => setNewQuestion({ ...newQuestion, question: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter your question"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Category
                  </label>
                  <select
                    value={newQuestion.category}
                    onChange={(e) => setNewQuestion({ ...newQuestion, category: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="Product Knowledge">Product Knowledge</option>
                    <option value="Sales Process">Sales Process</option>
                    <option value="Technical">Technical</option>
                    <option value="Industry">Industry</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Options
                  </label>
                  <div className="space-y-2">
                    {newQuestion.options.map((option, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <input
                          type="radio"
                          name="correct-answer"
                          checked={newQuestion.correctAnswer === index}
                          onChange={() => setNewQuestion({ ...newQuestion, correctAnswer: index })}
                          className="text-blue-600 focus:ring-blue-500"
                        />
                        <input
                          type="text"
                          value={option}
                          onChange={(e) => {
                            const newOptions = [...newQuestion.options];
                            newOptions[index] = e.target.value;
                            setNewQuestion({ ...newQuestion, options: newOptions });
                          }}
                          className="flex-1 px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          placeholder={`Option ${index + 1}`}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end space-x-4">
                  <button
                    onClick={() => setShowNewQuestion(false)}
                    className="px-4 py-2 text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleAddQuestion}
                    disabled={!newQuestion.question || newQuestion.options.some(opt => !opt)}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  >
                    Add Question
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}