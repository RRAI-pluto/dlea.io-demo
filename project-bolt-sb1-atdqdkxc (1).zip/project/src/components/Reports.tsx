import React, { useState } from 'react';
import { BarChart2, TrendingUp, Users, Target, Calendar, Download, ChevronDown, Brain, Zap, ArrowUpRight, ArrowDownRight, LayoutGrid } from 'lucide-react';
import { CustomReportBuilder } from './Reports/CustomReportBuilder';
import { DashboardBuilder } from './Reports/DashboardBuilder';

interface MetricCard {
  title: string;
  value: string;
  change: number;
  trend: 'up' | 'down';
  icon: React.ReactNode;
}

interface TrendData {
  date: string;
  value: number;
}

export function Reports() {
  const [activeTab, setActiveTab] = useState<'overview' | 'custom' | 'dashboards'>('overview');
  const [timeRange, setTimeRange] = useState('30d');
  const [reportType, setReportType] = useState('all');

  const metrics: MetricCard[] = [
    {
      title: 'Average Ramp Time',
      value: '45 days',
      change: -15,
      trend: 'down',
      icon: <Zap className="w-5 h-5 text-green-600" />
    },
    {
      title: 'Training Completion',
      value: '92%',
      change: 8,
      trend: 'up',
      icon: <Brain className="w-5 h-5 text-purple-600" />
    },
    {
      title: 'Content Engagement',
      value: '78%',
      change: 12,
      trend: 'up',
      icon: <Target className="w-5 h-5 text-blue-600" />
    },
    {
      title: 'Active Learners',
      value: '1,247',
      change: 5,
      trend: 'up',
      icon: <Users className="w-5 h-5 text-orange-600" />
    }
  ];

  const trendData: TrendData[] = [
    { date: 'Jan 1', value: 65 },
    { date: 'Jan 8', value: 68 },
    { date: 'Jan 15', value: 75 },
    { date: 'Jan 22', value: 78 }
  ];

  if (activeTab === 'custom') {
    return (
      <div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="border-b mb-6">
            <nav className="flex -mb-px">
              <button
                onClick={() => setActiveTab('overview')}
                className={`px-6 py-4 text-sm font-medium border-b-2 ${
                  activeTab === 'overview'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                } flex items-center`}
              >
                <BarChart2 className="w-5 h-5 mr-2" />
                Overview
              </button>
              <button
                onClick={() => setActiveTab('custom')}
                className={`px-6 py-4 text-sm font-medium border-b-2 ${
                  activeTab === 'custom'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                } flex items-center`}
              >
                <Target className="w-5 h-5 mr-2" />
                Custom Reports
              </button>
              <button
                onClick={() => setActiveTab('dashboards')}
                className={`px-6 py-4 text-sm font-medium border-b-2 ${
                  activeTab === 'dashboards'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                } flex items-center`}
              >
                <LayoutGrid className="w-5 h-5 mr-2" />
                Dashboards
              </button>
            </nav>
          </div>
        </div>
        <CustomReportBuilder />
      </div>
    );
  }

  if (activeTab === 'dashboards') {
    return (
      <div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="border-b mb-6">
            <nav className="flex -mb-px">
              <button
                onClick={() => setActiveTab('overview')}
                className={`px-6 py-4 text-sm font-medium border-b-2 ${
                  activeTab === 'overview'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                } flex items-center`}
              >
                <BarChart2 className="w-5 h-5 mr-2" />
                Overview
              </button>
              <button
                onClick={() => setActiveTab('custom')}
                className={`px-6 py-4 text-sm font-medium border-b-2 ${
                  activeTab === 'custom'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                } flex items-center`}
              >
                <Target className="w-5 h-5 mr-2" />
                Custom Reports
              </button>
              <button
                onClick={() => setActiveTab('dashboards')}
                className={`px-6 py-4 text-sm font-medium border-b-2 ${
                  activeTab === 'dashboards'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                } flex items-center`}
              >
                <LayoutGrid className="w-5 h-5 mr-2" />
                Dashboards
              </button>
            </nav>
          </div>
        </div>
        <DashboardBuilder />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">Enablement Reports</h1>
              <p className="text-gray-600">Analytics and insights from your enablement programs</p>
            </div>
            <div className="flex space-x-4">
              <div className="relative">
                <select
                  value={reportType}
                  onChange={(e) => setReportType(e.target.value)}
                  className="appearance-none bg-white border border-gray-200 rounded-lg px-4 py-2 pr-8"
                >
                  <option value="all">All Reports</option>
                  <option value="training">Training</option>
                  <option value="content">Content</option>
                  <option value="performance">Performance</option>
                </select>
                <ChevronDown className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 transform -translate-y-1/2" />
              </div>
              <div className="relative">
                <select
                  value={timeRange}
                  onChange={(e) => setTimeRange(e.target.value)}
                  className="appearance-none bg-white border border-gray-200 rounded-lg px-4 py-2 pr-8"
                >
                  <option value="7d">Last 7 days</option>
                  <option value="30d">Last 30 days</option>
                  <option value="90d">Last 90 days</option>
                  <option value="1y">Last year</option>
                </select>
                <ChevronDown className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 transform -translate-y-1/2" />
              </div>
              <button
                onClick={() => setActiveTab('custom')}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Target className="w-4 h-4" />
                <span>Custom Reports</span>
              </button>
            </div>
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            {metrics.map((metric) => (
              <div
                key={metric.title}
                className="bg-white p-6 rounded-lg shadow-sm"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="p-2 bg-gray-50 rounded-lg">
                    {metric.icon}
                  </div>
                  <span className="text-sm text-gray-500">vs last period</span>
                </div>
                <h3 className="text-2xl font-bold mb-1">{metric.value}</h3>
                <div className="flex items-center justify-between">
                  <p className="text-gray-600 text-sm">{metric.title}</p>
                  <div className={`flex items-center ${
                    metric.trend === 'up' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {metric.trend === 'up' ? (
                      <ArrowUpRight className="w-4 h-4" />
                    ) : (
                      <ArrowDownRight className="w-4 h-4" />
                    )}
                    <span className="text-sm">{Math.abs(metric.change)}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-2 gap-6">
            {/* Training Effectiveness */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-semibold">Training Effectiveness</h2>
                <div className="flex items-center space-x-2">
                  <button className="px-3 py-1 text-sm bg-blue-50 text-blue-600 rounded-full">Weekly</button>
                  <button className="px-3 py-1 text-sm text-gray-600 hover:bg-gray-50 rounded-full">Monthly</button>
                  <button className="px-3 py-1 text-sm text-gray-600 hover:bg-gray-50 rounded-full">Quarterly</button>
                </div>
              </div>
              <div className="space-y-4">
                {trendData.map((data, index) => (
                  <div key={index} className="flex items-center space-x-4">
                    <div className="w-20 text-sm text-gray-600">{data.date}</div>
                    <div className="flex-1">
                      <div className="h-4 w-full bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-blue-600 rounded-full"
                          style={{ width: `${data.value}%` }}
                        />
                      </div>
                    </div>
                    <div className="w-16 text-sm text-right font-medium">{data.value}%</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Content Performance */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-semibold">Content Performance</h2>
                <div className="flex items-center space-x-2">
                  <button className="px-3 py-1 text-sm bg-blue-50 text-blue-600 rounded-full">Views</button>
                  <button className="px-3 py-1 text-sm text-gray-600 hover:bg-gray-50 rounded-full">Engagement</button>
                  <button className="px-3 py-1 text-sm text-gray-600 hover:bg-gray-50 rounded-full">Impact</button>
                </div>
              </div>
              <div className="space-y-4">
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">Sales Methodology Guide</span>
                    <span className="text-green-600">+24%</span>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full bg-green-600 rounded-full" style={{ width: '85%' }} />
                  </div>
                </div>
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">Product Demo Templates</span>
                    <span className="text-green-600">+18%</span>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full bg-green-600 rounded-full" style={{ width: '72%' }} />
                  </div>
                </div>
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">Competitive Battlecards</span>
                    <span className="text-red-600">-5%</span>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full bg-red-600 rounded-full" style={{ width: '45%' }} />
                  </div>
                </div>
              </div>
            </div>

            {/* Team Performance */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-semibold">Team Performance</h2>
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4 text-gray-400" />
                  <span className="text-sm text-gray-600">This Quarter</span>
                </div>
              </div>
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="w-24 text-sm font-medium">Enterprise</div>
                  <div className="flex-1">
                    <div className="h-4 w-full bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-600 rounded-full" style={{ width: '90%' }} />
                    </div>
                  </div>
                  <div className="w-16 text-sm text-right">90%</div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-24 text-sm font-medium">Mid-Market</div>
                  <div className="flex-1">
                    <div className="h-4 w-full bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-600 rounded-full" style={{ width: '75%' }} />
                    </div>
                  </div>
                  <div className="w-16 text-sm text-right">75%</div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-24 text-sm font-medium">SMB</div>
                  <div className="flex-1">
                    <div className="h-4 w-full bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-600 rounded-full" style={{ width: '85%' }} />
                    </div>
                  </div>
                  <div className="w-16 text-sm text-right">85%</div>
                </div>
              </div>
            </div>

            {/* Key Insights */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h2 className="font-semibold mb-6">Key Insights</h2>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <TrendingUp className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium">Training Impact</p>
                    <p className="text-sm text-gray-600">15% boost in team productivity after sales training</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Brain className="w-4 h-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium">Learning Patterns</p>
                    <p className="text-sm text-gray-600">Most effective training sessions occur in morning hours</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <BarChart2 className="w-4 h-4 text-purple-600" />
                  </div>
                  <div>
                    <p className="font-medium">Content Strategy</p>
                    <p className="text-sm text-gray-600">Interactive content shows 3x higher engagement</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}