import React, { useState } from 'react';
import { AlertTriangle, ChevronDown, Search, Filter, Clock, Calendar, CheckCircle, ArrowRight, Brain, Target, BarChart2, MessageSquare, FileText, LayoutGrid, Zap, Award } from 'lucide-react';

interface Opportunity {
  id: string;
  name: string;
  stage: string;
  amount: number;
  owner: string;
  lastActivity: Date;
  status: string;
}

interface CallRecording {
  id: string;
  title: string;
  date: Date;
  duration: number;
  speaker: string;
  sentiment: 'positive' | 'neutral' | 'negative';
  keyInsights: string[];
  transcriptUrl: string;
}

interface ActionPlan {
  immediate: string[];
  shortTerm: string[];
  longTerm: string[];
  expectedOutcomes: {
    metric: string;
    target: string;
    timeline: string;
  }[];
}

interface Report {
  title: string;
  date: string;
  summary: string;
  keyMetrics: Array<{
    metric: string;
    historicalAvg: number;
    currentPeriod: number;
    variance: number;
  }>;
  observations: string[];
  rootCauses: string[];
  recommendations: {
    immediate: string[];
    midTerm: string[];
    longTerm: string[];
  };
  stakeholders: string[];
  followUpDate: string;
  actionPlan: ActionPlan;
}

interface Ticket {
  id: string;
  title: string;
  status: 'open' | 'in_progress' | 'resolved';
  priority: 'low' | 'medium' | 'high';
  createdAt: Date;
  type: 'anomaly' | 'conversion_drop';
  opportunities: Opportunity[];
  callRecordings: CallRecording[];
  report: Report;
}

export function EnablementTickets({ onNavigate }: { onNavigate?: (view: string) => void }) {
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [filterStatus, setFilterStatus] = useState<'all' | 'open' | 'in_progress' | 'resolved'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const tickets: Ticket[] = [
    {
      id: '1',
      title: 'Demo-to-Close Ratio Decline',
      status: 'open',
      priority: 'high',
      createdAt: new Date('2025-01-22'),
      type: 'conversion_drop',
      opportunities: [
        {
          id: 'opp1',
          name: 'InnovateTech Solutions',
          stage: 'Demo',
          amount: 175000,
          owner: 'Alex Chen',
          lastActivity: new Date('2025-01-20'),
          status: 'active'
        },
        {
          id: 'opp2',
          name: 'DataFlow Systems',
          stage: 'Demo',
          amount: 225000,
          owner: 'Rachel Kim',
          lastActivity: new Date('2025-01-21'),
          status: 'active'
        }
      ],
      callRecordings: [
        {
          id: 'call1',
          title: 'InnovateTech - Product Demo',
          date: new Date('2025-01-20'),
          duration: 60,
          speaker: 'Alex Chen',
          sentiment: 'neutral',
          keyInsights: [
            'Technical features overshadowed business value',
            'Limited customer engagement during demo',
            'Competitor comparison not addressed'
          ],
          transcriptUrl: '#'
        }
      ],
      report: {
        title: 'Demo Effectiveness Analysis',
        date: 'January 22, 2025',
        summary: 'Analysis shows a 30% decrease in demo-to-close conversion rates over the past month, primarily due to misalignment between product demonstrations and customer needs.',
        keyMetrics: [
          {
            metric: 'Demo-to-Close Rate',
            historicalAvg: 60,
            currentPeriod: 30,
            variance: -30
          }
        ],
        observations: [
          'Average demo duration increased by 20 minutes',
          'Customer engagement metrics down by 40%',
          'Technical questions dominating business value discussions'
        ],
        rootCauses: [
          'Product-centric rather than solution-centric demos',
          'Insufficient pre-demo discovery',
          'Limited customization of demos to specific use cases'
        ],
        recommendations: {
          immediate: [
            'Implement demo scorecard system',
            'Create industry-specific demo templates',
            'Schedule demo effectiveness workshop'
          ],
          midTerm: [
            'Develop personalized demo playbooks',
            'Create customer success story library'
          ],
          longTerm: [
            'Build interactive demo environment',
            'Implement automated demo analytics'
          ]
        },
        stakeholders: [
          'Sales Engineering Lead',
          'Product Marketing Manager',
          'Sales Enablement Director'
        ],
        followUpDate: 'February 5, 2025',
        actionPlan: {
          immediate: [
            'Create demo effectiveness training module',
            'Develop value proposition framework',
            'Schedule team workshop on solution selling'
          ],
          shortTerm: [
            'Build industry-specific demo templates',
            'Implement demo feedback system',
            'Create competitive battlecards'
          ],
          longTerm: [
            'Develop automated demo analytics dashboard',
            'Build comprehensive demo content library',
            'Implement AI-powered demo assistance'
          ],
          expectedOutcomes: [
            {
              metric: 'Demo-to-Close Rate',
              target: '50%',
              timeline: '90 days'
            },
            {
              metric: 'Customer Engagement Score',
              target: '8.5/10',
              timeline: '60 days'
            },
            {
              metric: 'Average Deal Size',
              target: '+15%',
              timeline: '120 days'
            }
          ]
        }
      }
    },
    {
      id: '2',
      title: 'Enterprise Deal Velocity Slowdown',
      status: 'in_progress',
      priority: 'high',
      createdAt: new Date('2025-01-21'),
      type: 'anomaly',
      opportunities: [
        {
          id: 'opp3',
          name: 'Global Financial Solutions',
          stage: 'Negotiation',
          amount: 450000,
          owner: 'Sarah Chen',
          lastActivity: new Date('2025-01-19'),
          status: 'delayed'
        }
      ],
      callRecordings: [
        {
          id: 'call2',
          title: 'GFS - Technical Requirements Review',
          date: new Date('2025-01-19'),
          duration: 90,
          speaker: 'David Kim',
          sentiment: 'negative',
          keyInsights: [
            'Security requirements need clarification',
            'Integration timeline concerns raised',
            'Budget approval process unclear'
          ],
          transcriptUrl: '#'
        }
      ],
      report: {
        title: 'Deal Velocity Analysis',
        date: 'January 21, 2025',
        summary: 'Enterprise deals are showing significant slowdown in progression through later stages, with security and compliance requirements being major friction points.',
        keyMetrics: [
          {
            metric: 'Average Sales Cycle',
            historicalAvg: 90,
            currentPeriod: 120,
            variance: 30
          }
        ],
        observations: [
          'Multiple stakeholder alignment challenges',
          'Extended security review processes',
          'Complex approval hierarchies'
        ],
        rootCauses: [
          'Insufficient early-stage discovery',
          'Reactive approach to security requirements',
          'Limited executive engagement'
        ],
        recommendations: {
          immediate: [
            'Create security requirement checklist',
            'Implement stakeholder mapping process',
            'Develop executive engagement strategy'
          ],
          midTerm: [
            'Build security compliance playbook',
            'Establish customer success council'
          ],
          longTerm: [
            'Develop automated compliance verification',
            'Create industry-specific frameworks'
          ]
        },
        stakeholders: [
          'Enterprise Sales Director',
          'Security Team Lead',
          'Customer Success Manager'
        ],
        followUpDate: 'February 1, 2025',
        actionPlan: {
          immediate: [
            'Schedule security assessment reviews',
            'Create stakeholder alignment framework',
            'Develop executive briefing materials'
          ],
          shortTerm: [
            'Build compliance documentation library',
            'Implement deal review process',
            'Create ROI calculator'
          ],
          longTerm: [
            'Automate security assessment process',
            'Develop industry vertical playbooks',
            'Create executive engagement program'
          ],
          expectedOutcomes: [
            {
              metric: 'Sales Cycle Length',
              target: '90 days',
              timeline: '120 days'
            },
            {
              metric: 'Security Approval Time',
              target: '14 days',
              timeline: '60 days'
            },
            {
              metric: 'Executive Engagement',
              target: '90%',
              timeline: '90 days'
            }
          ]
        }
      }
    },
    {
      id: '3',
      title: 'Mid-Market Win Rate Decline',
      status: 'open',
      priority: 'medium',
      createdAt: new Date('2025-01-20'),
      type: 'anomaly',
      opportunities: [
        {
          id: 'opp4',
          name: 'TechStart Solutions',
          stage: 'Proposal',
          amount: 85000,
          owner: 'Michael Rodriguez',
          lastActivity: new Date('2025-01-18'),
          status: 'at_risk'
        }
      ],
      callRecordings: [
        {
          id: 'call3',
          title: 'TechStart - Solution Review',
          date: new Date('2025-01-18'),
          duration: 45,
          speaker: 'Michael Rodriguez',
          sentiment: 'neutral',
          keyInsights: [
            'Price sensitivity evident',
            'Feature comparison with competitors',
            'Implementation timeline concerns'
          ],
          transcriptUrl: '#'
        }
      ],
      report: {
        title: 'Mid-Market Segment Analysis',
        date: 'January 20, 2025',
        summary: 'Mid-market segment showing decreased win rates against competitors, with pricing and implementation timeline being key decision factors.',
        keyMetrics: [
          {
            metric: 'Win Rate',
            historicalAvg: 45,
            currentPeriod: 32,
            variance: -13
          }
        ],
        observations: [
          'Increased price sensitivity',
          'Shorter evaluation cycles',
          'More competitive deals'
        ],
        rootCauses: [
          'Limited value differentiation',
          'Standard pricing model limitations',
          'Implementation complexity'
        ],
        recommendations: {
          immediate: [
            'Create value-based pricing guide',
            'Develop quick-start implementation plan',
            'Build competitive differentiation toolkit'
          ],
          midTerm: [
            'Implement flexible pricing models',
            'Create industry solution packages'
          ],
          longTerm: [
            'Develop self-service implementation',
            'Build automated ROI calculator'
          ]
        },
        stakeholders: [
          'Mid-Market Sales Director',
          'Product Marketing Manager',
          'Implementation Team Lead'
        ],
        followUpDate: 'February 3, 2025',
        actionPlan: {
          immediate: [
            'Create value messaging framework',
            'Develop competitive battlecards',
            'Build implementation timeline calculator'
          ],
          shortTerm: [
            'Design flexible pricing options',
            'Create quick-start guides',
            'Develop ROI templates'
          ],
          longTerm: [
            'Build self-service portal',
            'Create automated onboarding',
            'Develop predictive pricing model'
          ],
          expectedOutcomes: [
            {
              metric: 'Win Rate',
              target: '45%',
              timeline: '90 days'
            },
            {
              metric: 'Implementation Time',
              target: '-30%',
              timeline: '60 days'
            },
            {
              metric: 'Deal Velocity',
              target: '+25%',
              timeline: '120 days'
            }
          ]
        }
      }
    },
    {
      id: '4',
      title: 'Product Training Effectiveness',
      status: 'in_progress',
      priority: 'medium',
      createdAt: new Date('2025-01-19'),
      type: 'anomaly',
      opportunities: [
        {
          id: 'opp5',
          name: 'CloudScale Inc',
          stage: 'Demo',
          amount: 120000,
          owner: 'Emily Watson',
          lastActivity: new Date('2025-01-17'),
          status: 'active'
        }
      ],
      callRecordings: [
        {
          id: 'call4',
          title: 'CloudScale - Product Demo',
          date: new Date('2025-01-17'),
          duration: 55,
          speaker: 'Emily Watson',
          sentiment: 'neutral',
          keyInsights: [
            'New feature explanation gaps',
            'Use case alignment needed',
            'Technical questions unanswered'
          ],
          transcriptUrl: '#'
        }
      ],
      report: {
        title: 'Training Impact Analysis',
        date: 'January 19, 2025',
        summary: 'Recent product training shows gaps in effectiveness, particularly around new feature demonstrations and technical question handling.',
        keyMetrics: [
          {
            metric: 'Demo Confidence Score',
            historicalAvg: 85,
            currentPeriod: 65,
            variance: -20
          }
        ],
        observations: [
          'Inconsistent feature messaging',
          'Technical depth variations',
          'Limited hands-on practice'
        ],
        rootCauses: [
          'Rapid product updates',
          'Limited practice scenarios',
          'One-size-fits-all training'
        ],
        recommendations: {
          immediate: [
            'Create feature demo guides',
            'Implement practice sessions',
            'Develop technical FAQ'
          ],
          midTerm: [
            'Build simulation environment',
            'Create role-specific tracks'
          ],
          longTerm: [
            'Develop AI-powered training',
            'Create personalized learning paths'
          ]
        },
        stakeholders: [
          'Sales Enablement Manager',
          'Product Training Lead',
          'Sales Engineering Manager'
        ],
        followUpDate: 'January 31, 2025',
        actionPlan: {
          immediate: [
            'Schedule practice sessions',
            'Create feature cheat sheets',
            'Develop technical guides'
          ],
          shortTerm: [
            'Build demo environment',
            'Create assessment tools',
            'Develop mentorship program'
          ],
          longTerm: [
            'Implement VR training',
            'Create adaptive learning system',
            'Build certification program'
          ],
          expectedOutcomes: [
            {
              metric: 'Demo Confidence',
              target: '85%',
              timeline: '60 days'
            },
            {
              metric: 'Technical Accuracy',
              target: '95%',
              timeline: '90 days'
            },
            {
              metric: 'Training Completion',
              target: '100%',
              timeline: '30 days'
            }
          ]
        }
      }
    },
    {
      id: '5',
      title: 'New Feature Adoption Rate',
      status: 'open',
      priority: 'low',
      createdAt: new Date('2025-01-18'),
      type: 'anomaly',
      opportunities: [
        {
          id: 'opp6',
          name: 'Digital Dynamics',
          stage: 'Implementation',
          amount: 95000,
          owner: 'James Wilson',
          lastActivity: new Date('2025-01-16'),
          status: 'active'
        }
      ],
      callRecordings: [
        {
          id: 'call5',
          title: 'Digital Dynamics - Feature Review',
          date: new Date('2025-01-16'),
          duration: 40,
          speaker: 'James Wilson',
          sentiment: 'positive',
          keyInsights: [
            'Feature benefits well received',
            'Implementation questions raised',
            'Training needs identified'
          ],
          transcriptUrl: '#'
        }
      ],
      report: {
        title: 'Feature Adoption Analysis',
        date: 'January 18, 2025',
        summary: 'New feature adoption rates are below target, with implementation complexity and training needs identified as key barriers.',
        keyMetrics: [
          {
            metric: 'Feature Adoption Rate',
            historicalAvg: 75,
            currentPeriod: 45,
            variance: -30
          }
        ],
        observations: [
          'Complex implementation process',
          'Limited user training',
          'Unclear feature benefits'
        ],
        rootCauses: [
          'Technical complexity',
          'Resource constraints',
          'Change management gaps'
        ],
        recommendations: {
          immediate: [
            'Create quick-start guides',
            'Develop training videos',
            'Build feature benefit calculator'
          ],
          midTerm: [
            'Implement guided setup',
            'Create success metrics'
          ],
          longTerm: [
            'Develop automated onboarding',
            'Build predictive assistance'
          ]
        },
        stakeholders: [
          'Product Manager',
          'Customer Success Lead',
          'Training Manager'
        ],
        followUpDate: 'February 2, 2025',
        actionPlan: {
          immediate: [
            'Create implementation guides',
            'Develop training materials',
            'Build success metrics'
          ],
          shortTerm: [
            'Implement automated setup',
            'Create user feedback system',
            'Develop usage analytics'
          ],
          longTerm: [
            'Build AI-powered assistance',
            'Create predictive insights',
            'Develop personalization'
          ],
          expectedOutcomes: [
            {
              metric: 'Adoption Rate',
              target: '75%',
              timeline: '90 days'
            },
            {
              metric: 'User Satisfaction',
              target: '4.5/5',
              timeline: '60 days'
            },
            {
              metric: 'Support Tickets',
              target: '-40%',
              timeline: '120 days'
            }
          ]
        }
      }
    }
  ];

  const filteredTickets = tickets.filter(ticket => {
    const matchesStatus = filterStatus === 'all' || ticket.status === filterStatus;
    const matchesSearch = ticket.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">Enablement Tickets</h1>
              <p className="text-gray-600">Monitor and manage enablement issues</p>
            </div>
            <div className="flex space-x-4">
              <div className="relative">
                <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search tickets..."
                  className="pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Status</option>
                <option value="open">Open</option>
                <option value="in_progress">In Progress</option>
                <option value="resolved">Resolved</option>
              </select>
            </div>
          </div>

          <div className="space-y-4">
            {filteredTickets.map((ticket) => (
              <div
                key={ticket.id}
                className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-4">
                      <div className={`p-2 rounded-lg ${
                        ticket.type === 'anomaly' ? 'bg-red-100' : 'bg-yellow-100'
                      }`}>
                        <AlertTriangle className={`w-5 h-5 ${
                          ticket.type === 'anomaly' ? 'text-red-600' : 'text-yellow-600'
                        }`} />
                      </div>
                      <div>
                        <h3 className="text-lg font-medium">{ticket.title}</h3>
                        <div className="flex items-center space-x-4 mt-1">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            ticket.status === 'open' ? 'bg-red-100 text-red-800' :
                            ticket.status === 'in_progress' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-green-100 text-green-800'
                          }`}>
                            {ticket.status.replace('_', ' ')}
                          </span>
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            ticket.priority === 'high' ? 'bg-red-100 text-red-800' :
                            ticket.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-green-100 text-green-800'
                          }`}>
                            {ticket.priority} priority
                          </span>
                          <span className="text-sm text-gray-500 flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {ticket.createdAt.toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => setSelectedTicket(selectedTicket?.id === ticket.id ? null : ticket)}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <ChevronDown className={`w-5 h-5 transform transition-transform ${
                        selectedTicket?.id === ticket.id ? 'rotate-180' : ''
                      }`} />
                    </button>
                  </div>

                  {selectedTicket?.id === ticket.id && (
                    <div className="mt-4 space-y-6">
                      <div className="grid grid-cols-3 gap-4">
                        <div className="bg-gray-50 p-4 rounded-lg">
                          <h4 className="font-medium mb-2 flex items-center">
                            <BarChart2 className="w-4 h-4 mr-2" />
                            Key Metrics
                          </h4>
                          {ticket.report.keyMetrics.map((metric, index) => (
                            <div key={index} className="mb-2">
                              <p className="text-sm text-gray-600">{metric.metric}</p>
                              <div className="flex items-center justify-between">
                                <span className="font-medium">{metric.currentPeriod}%</span>
                                <span className={`text-sm ${
                                  metric.variance >= 0 ? 'text-green-600' : 'text-red-600'
                                }`}>
                                  {metric.variance >= 0 ? '+' : ''}{metric.variance}%
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>

                        <div className="bg-gray-50 p-4 rounded-lg">
                          <h4 className="font-medium mb-2 flex items-center">
                            <MessageSquare className="w-4 h-4 mr-2" />
                            Call Recordings
                          </h4>
                          {ticket.callRecordings.map(recording => (
                            <div key={recording.id} className="mb-2">
                              <p className="text-sm font-medium">{recording.title}</p>
                              <div className="flex items-center justify-between text-sm text-gray-600">
                                <span>{recording.duration} min</span>
                                <span className={`${
                                  recording.sentiment === 'positive' ? 'text-green-600' :
                                  recording.sentiment === 'negative' ? 'text-red-600' :
                                  'text-yellow-600'
                                }`}>
                                  {recording.sentiment}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>

                        <div className="bg-gray-50 p-4 rounded-lg">
                          <h4 className="font-medium mb-2 flex items-center">
                            <FileText className="w-4 h-4 mr-2" />
                            Recommendations
                          </h4>
                          <div className="space-y-2">
                            {ticket.report.recommendations.immediate.map((rec, index) => (
                              <p key={index} className="text-sm text-gray-600">• {rec}</p>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="bg-blue-50 p-6 rounded-lg relative">
                        <div className="flex items-center mb-4">
                          <Brain className="w-5 h-5 text-blue-600 mr-2" />
                          <h4 className="font-medium">AI-Generated Action Plan</h4>
                        </div>

                        <div className="grid grid-cols-2 gap-6">
                          <div>
                            <h5 className="text-sm font-medium text-blue-800 mb-2">Action Items</h5>
                            <div className="space-y-4">
                              <div>
                                <h6 className="text-sm font-medium text-blue-700 mb-1">Immediate Actions</h6>
                                <ul className="space-y-1">
                                  {ticket.report.actionPlan.immediate.map((action, index) => (
                                    <li key={index} className="text-sm text-blue-600 flex items-start">
                                      <ArrowRight className="w-4 h-4 mr-1 mt-0.5 flex-shrink-0" />
                                      {action}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                              <div>
                                <h6 className="text-sm font-medium text-blue-700 mb-1">Short-term Actions</h6>
                                <ul className="space-y-1">
                                  {ticket.report.actionPlan.shortTerm.map((action, index) => (
                                    <li key={index} className="text-sm text-blue-600 flex items-start">
                                      <ArrowRight className="w-4 h-4 mr-1 mt-0.5 flex-shrink-0" />
                                      {action}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                              <div>
                                <h6 className="text-sm font-medium text-blue-700 mb-1">Long-term Actions</h6>
                                <ul className="space-y-1">
                                  {ticket.report.actionPlan.longTerm.map((action, index) => (
                                    <li key={index} className="text-sm text-blue-600 flex items-start">
                                      <ArrowRight className="w-4 h-4 mr-1 mt-0.5 flex-shrink-0" />
                                      {action}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            </div>
                          </div>

                          <div>
                            <h5 className="text-sm font-medium text-blue-800 mb-2">Expected Outcomes</h5>
                            <div className="space-y-3">
                              {ticket.report.actionPlan.expectedOutcomes.map((outcome, index) => (
                                <div key={index} className="bg-white p-3 rounded-lg">
                                  <div className="flex items-center justify-between mb-1">
                                    <span className="text-sm font-medium text-gray-700">{outcome.metric}</span>
                                    <span className="text-sm text-blue-600">{outcome.timeline}</span>
                                  </div>
                                  <div className="flex items-center">
                                    <Target className="w-4 h-4 text-green-600 mr-2" />
                                    <span className="text-sm font-medium text-green-600">Target: {outcome.target}</span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="absolute bottom-6 right-6">
                          <button
                            onClick={() => onNavigate?.('config')}
                            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                          >
                            <LayoutGrid className="w-4 h-4 mr-2" />
                            Start Project
                          </button>
                        </div>
                      </div>

                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h4 className="font-medium mb-2">Opportunities Affected</h4>
                        <div className="space-y-2">
                          {ticket.opportunities.map(opp => (
                            <div key={opp.id} className="flex items-center justify-between">
                              <div>
                                <p className="font-medium">{opp.name}</p>
                                <p className="text-sm text-gray-600">
                                  {opp.owner} • {opp.stage}
                                </p>
                              </div>
                              <span className=" font-medium">
                                ${opp.amount.toLocaleString()}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}