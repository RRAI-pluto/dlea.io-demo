import React, { useState } from 'react';
import { Save, Plus, Trash2, ArrowRight, AlertTriangle, RefreshCw, Settings, Tag, Search, Download, ChevronDown, X } from 'lucide-react';
import { databaseService } from '../../services/databaseService';

interface TagCategory {
  id: string;
  name: string;
  description: string;
  tags: Tag[];
}

interface Tag {
  id: string;
  name: string;
  color: string;
  keywords: string[];
}

export function TagManager() {
  const [categories, setCategories] = useState<TagCategory[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryDescription, setNewCategoryDescription] = useState('');
  const [showNewCategoryForm, setShowNewCategoryForm] = useState(false);
  const [editingTagId, setEditingTagId] = useState<string | null>(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  const colors = ['blue', 'green', 'red', 'yellow', 'purple', 'orange', 'pink'];

  const getColorClasses = (color: string) => {
    switch (color) {
      case 'blue':
        return 'bg-blue-100 text-blue-800';
      case 'green':
        return 'bg-green-100 text-green-800';
      case 'red':
        return 'bg-red-100 text-red-800';
      case 'yellow':
        return 'bg-yellow-100 text-yellow-800';
      case 'purple':
        return 'bg-purple-100 text-purple-800';
      case 'orange':
        return 'bg-orange-100 text-orange-800';
      case 'pink':
        return 'bg-pink-100 text-pink-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleAddCategory = () => {
    if (!newCategoryName.trim()) return;

    const newCategory: TagCategory = {
      id: Date.now().toString(),
      name: newCategoryName,
      description: newCategoryDescription,
      tags: []
    };

    setCategories([...categories, newCategory]);
    setNewCategoryName('');
    setNewCategoryDescription('');
    setShowNewCategoryForm(false);
    setHasUnsavedChanges(true);
  };

  const handleDeleteCategory = (categoryId: string) => {
    setCategories(categories.filter(cat => cat.id !== categoryId));
    setHasUnsavedChanges(true);
  };

  const handleAddTag = (categoryId: string, tag: Tag) => {
    setCategories(categories.map(cat => {
      if (cat.id === categoryId) {
        return {
          ...cat,
          tags: [...cat.tags, tag]
        };
      }
      return cat;
    }));
    setHasUnsavedChanges(true);
  };

  const handleDeleteTag = (categoryId: string, tagId: string) => {
    setCategories(categories.map(cat => {
      if (cat.id === categoryId) {
        return {
          ...cat,
          tags: cat.tags.filter(tag => tag.id !== tagId)
        };
      }
      return cat;
    }));
    setHasUnsavedChanges(true);
  };

  const handleSaveChanges = async () => {
    try {
      const settings = {
        categories: categories
      };

      const { error } = await databaseService.settings.saveTagSettings(settings);
      
      if (error) throw error;
      
      setHasUnsavedChanges(false);
      alert('Tag settings saved successfully');
    } catch (error) {
      console.error('Error saving tag settings:', error);
      alert('Failed to save settings. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-sm">
          <div className="p-6 border-b">
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-2xl font-bold">Tag Manager</h1>
                <p className="text-gray-600">Manage content tags and keywords for AI analysis</p>
              </div>
              <div className="flex space-x-4">
                <button
                  onClick={() => setShowNewCategoryForm(true)}
                  className="flex items-center px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  New Category
                </button>
                <button
                  onClick={handleSaveChanges}
                  disabled={!hasUnsavedChanges}
                  className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save Changes
                </button>
              </div>
            </div>
          </div>

          <div className="p-6">
            {/* Search and Filter */}
            <div className="mb-6">
              <div className="relative">
                <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search tags..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Categories */}
            <div className="space-y-6">
              {categories.map((category) => (
                <div key={category.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-medium">{category.name}</h3>
                      <p className="text-sm text-gray-500">{category.description}</p>
                    </div>
                    <button
                      onClick={() => handleDeleteCategory(category.id)}
                      className="text-gray-400 hover:text-red-500"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {category.tags.map((tag) => (
                      <div
                        key={tag.id}
                        className={`flex items-center px-3 py-1 rounded-full ${getColorClasses(tag.color)}`}
                      >
                        <span>{tag.name}</span>
                        <button
                          onClick={() => handleDeleteTag(category.id, tag.id)}
                          className="ml-2 text-current opacity-60 hover:opacity-100"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Empty State */}
            {categories.length === 0 && !showNewCategoryForm && (
              <div className="text-center py-12">
                <Tag className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Categories Yet</h3>
                <p className="text-gray-500 mb-4">Create your first category to start organizing tags</p>
                <button
                  onClick={() => setShowNewCategoryForm(true)}
                  className="inline-flex items-center px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create Category
                </button>
              </div>
            )}

            {/* New Category Form */}
            {showNewCategoryForm && (
              <div className="border rounded-lg p-4">
                <h3 className="text-lg font-medium mb-4">New Category</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Category Name
                    </label>
                    <input
                      type="text"
                      value={newCategoryName}
                      onChange={(e) => setNewCategoryName(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter category name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Description
                    </label>
                    <input
                      type="text"
                      value={newCategoryDescription}
                      onChange={(e) => setNewCategoryDescription(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter category description"
                    />
                  </div>
                  <div className="flex justify-end space-x-4">
                    <button
                      onClick={() => setShowNewCategoryForm(false)}
                      className="px-4 py-2 text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleAddCategory}
                      disabled={!newCategoryName.trim()}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                    >
                      Create Category
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}