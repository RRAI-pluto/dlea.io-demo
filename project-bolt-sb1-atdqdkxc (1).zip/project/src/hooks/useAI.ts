import { useState } from 'react';
import { aiService, AIResponse } from '../services/aiService';

export function useAI() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const analyzeSalesCall = async (transcript: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await aiService.analyzeSalesCall(transcript);
      return response;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to analyze sales call'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const generateContentSuggestions = async (context: {
    dealStage: string;
    industry: string;
    painPoints: string[];
  }) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await aiService.generateContentSuggestions(context);
      return response;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to generate content suggestions'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const analyzeDealRisks = async (dealData: {
    stage: string;
    value: number;
    interactions: any[];
    timeline: any[];
  }) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await aiService.analyzeDealRisks(dealData);
      return response;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to analyze deal risks'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const generateCoachingInsights = async (performanceData: {
    metrics: any[];
    calls: any[];
    deals: any[];
  }) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await aiService.generateCoachingInsights(performanceData);
      return response;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to generate coaching insights'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    analyzeSalesCall,
    generateContentSuggestions,
    analyzeDealRisks,
    generateCoachingInsights,
    isLoading,
    error
  };
}