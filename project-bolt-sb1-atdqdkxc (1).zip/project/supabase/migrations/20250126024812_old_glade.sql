/*
  # Additional Tables for Enhanced Features

  1. New Tables
    - notifications
      - id (uuid, primary key)
      - user_id (uuid, references profiles)
      - title (text)
      - description (text) 
      - type (text)
      - status (text)
      - created_at (timestamptz)
      - metadata (jsonb)

    - gamification_settings
      - id (uuid, primary key)
      - enabled (boolean)
      - point_term (text)
      - point_expiration_days (integer)
      - leaderboard_visible (boolean)
      - created_at (timestamptz)
      - updated_at (timestamptz)

    - point_rules
      - id (uuid, primary key)
      - type (text)
      - points (integer)
      - description (text)
      - enabled (boolean)
      - created_at (timestamptz)

    - user_points
      - id (uuid, primary key)
      - user_id (uuid, references profiles)
      - points (integer)
      - earned_at (timestamptz)
      - expires_at (timestamptz)
      - rule_id (uuid, references point_rules)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  type text NOT NULL CHECK (type IN ('alert', 'insight', 'message')),
  status text NOT NULL CHECK (status IN ('unread', 'read')),
  created_at timestamptz DEFAULT now(),
  metadata jsonb DEFAULT '{}'::jsonb
);

-- Create gamification_settings table
CREATE TABLE IF NOT EXISTS gamification_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  enabled boolean DEFAULT false,
  point_term text DEFAULT 'points',
  point_expiration_days integer DEFAULT 90,
  leaderboard_visible boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create point_rules table
CREATE TABLE IF NOT EXISTS point_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL,
  points integer NOT NULL,
  description text NOT NULL,
  enabled boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create user_points table
CREATE TABLE IF NOT EXISTS user_points (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  points integer NOT NULL,
  earned_at timestamptz DEFAULT now(),
  expires_at timestamptz,
  rule_id uuid REFERENCES point_rules(id) ON DELETE SET NULL
);

-- Enable RLS
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE gamification_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE point_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_points ENABLE ROW LEVEL SECURITY;

-- Notifications policies
CREATE POLICY "Users can view their own notifications"
  ON notifications
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can update their own notifications"
  ON notifications
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Gamification settings policies
CREATE POLICY "Anyone can view gamification settings"
  ON gamification_settings
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage gamification settings"
  ON gamification_settings
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role_id IN (SELECT id FROM roles WHERE name IN ('Admin', 'Super Admin'))
    )
  );

-- Point rules policies
CREATE POLICY "Anyone can view point rules"
  ON point_rules
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage point rules"
  ON point_rules
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role_id IN (SELECT id FROM roles WHERE name IN ('Admin', 'Super Admin'))
    )
  );

-- User points policies
CREATE POLICY "Users can view their own points"
  ON user_points
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "System can manage user points"
  ON user_points
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role_id IN (SELECT id FROM roles WHERE name IN ('Admin', 'Super Admin'))
    )
  );

-- Add some default point rules
INSERT INTO point_rules (type, points, description) VALUES
  ('course_completion', 100, 'Complete a training course'),
  ('assessment_score', 50, 'Score 90% or higher on assessment'),
  ('completion_streak', 25, 'Complete 3 courses in a week'),
  ('early_completion', 30, 'Complete course before due date');

-- Add default gamification settings
INSERT INTO gamification_settings (enabled, point_term, point_expiration_days, leaderboard_visible)
VALUES (true, 'points', 90, true);