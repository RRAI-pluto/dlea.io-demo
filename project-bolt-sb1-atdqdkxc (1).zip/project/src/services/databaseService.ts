import { supabase } from '../lib/supabase';

// Generic type for database responses
interface DatabaseResponse<T> {
  data: T | null;
  error: Error | null;
}

// Settings interfaces
interface GamificationSettings {
  enabled: boolean;
  point_term: string;
  point_expiration_days: number;
  leaderboard_visible: boolean;
  point_rules: Array<{
    id: string;
    type: string;
    points: number;
    description: string;
    enabled: boolean;
  }>;
}

interface ICPSettings {
  criteria: Array<{
    id: string;
    name: string;
    description: string;
    attributes: string[];
  }>;
}

interface TagSettings {
  categories: Array<{
    id: string;
    name: string;
    description: string;
    tags: Array<{
      id: string;
      name: string;
      color: string;
      keywords: string[];
    }>;
  }>;
}

interface MicroLearningSettings {
  enabled: boolean;
  schedule: {
    frequency: 'daily' | 'weekly';
    questionsPerDay: number;
    timeWindow: {
      start: string;
      end: string;
    };
  };
  questions: Array<{
    id: string;
    question: string;
    options: string[];
    correctAnswer: number;
    category: string;
    enabled: boolean;
  }>;
}

interface IntegrationSettings {
  type: string;
  config: Record<string, any>;
  status?: 'connected' | 'disconnected' | 'error';
  lastSync?: Date;
}

export const databaseService = {
  // Settings
  settings: {
    async saveGamificationSettings(settings: GamificationSettings): Promise<DatabaseResponse<GamificationSettings>> {
      try {
        const { data, error } = await supabase
          .from('gamification_settings')
          .upsert([settings])
          .select()
          .single();

        return { data, error: error as Error | null };
      } catch (error) {
        return { data: null, error: error as Error };
      }
    },

    async saveICPSettings(settings: ICPSettings): Promise<DatabaseResponse<ICPSettings>> {
      try {
        const { data, error } = await supabase
          .from('icp_settings')
          .upsert([settings])
          .select()
          .single();

        return { data, error: error as Error | null };
      } catch (error) {
        return { data: null, error: error as Error };
      }
    },

    async saveTagSettings(settings: TagSettings): Promise<DatabaseResponse<TagSettings>> {
      try {
        const { data, error } = await supabase
          .from('tag_settings')
          .upsert([settings])
          .select()
          .single();

        return { data, error: error as Error | null };
      } catch (error) {
        return { data: null, error: error as Error };
      }
    },

    async saveMicroLearningSettings(settings: MicroLearningSettings): Promise<DatabaseResponse<MicroLearningSettings>> {
      try {
        const { data, error } = await supabase
          .from('microlearning_settings')
          .upsert([settings])
          .select()
          .single();

        return { data, error: error as Error | null };
      } catch (error) {
        return { data: null, error: error as Error };
      }
    }
  },

  // Integrations
  integrations: {
    async saveIntegrationSettings(settings: IntegrationSettings): Promise<DatabaseResponse<IntegrationSettings>> {
      try {
        const { data, error } = await supabase
          .from('integrations')
          .upsert([settings])
          .select()
          .single();

        return { data, error: error as Error | null };
      } catch (error) {
        return { data: null, error: error as Error };
      }
    }
  }
};