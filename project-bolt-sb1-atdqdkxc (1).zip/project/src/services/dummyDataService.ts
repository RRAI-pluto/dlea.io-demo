import { storageService } from './storageService';
import * as dummyData from '../data/dummyData';

export const dummyDataService = {
  async uploadDummyData() {
    try {
      // Create main folders
      await storageService.createFolder('training_data');
      await storageService.createFolder('training_data/sales_calls');
      await storageService.createFolder('training_data/content');
      await storageService.createFolder('training_data/performance');
      await storageService.createFolder('training_data/patterns');

      // Upload sales call transcripts
      const transcriptsBlob = new Blob(
        [JSON.stringify(dummyData.salesCallTranscripts, null, 2)],
        { type: 'application/json' }
      );
      await storageService.uploadFile(
        transcriptsBlob as File,
        'training_data/sales_calls/transcripts.json'
      );

      // Upload content library
      const contentBlob = new Blob(
        [JSON.stringify(dummyData.contentLibrary, null, 2)],
        { type: 'application/json' }
      );
      await storageService.uploadFile(
        contentBlob as File,
        'training_data/content/library.json'
      );

      // Upload training materials
      const trainingBlob = new Blob(
        [JSON.stringify(dummyData.trainingMaterials, null, 2)],
        { type: 'application/json' }
      );
      await storageService.uploadFile(
        trainingBlob as File,
        'training_data/content/training.json'
      );

      // Upload performance data
      const performanceBlob = new Blob(
        [JSON.stringify(dummyData.salesPerformanceData, null, 2)],
        { type: 'application/json' }
      );
      await storageService.uploadFile(
        performanceBlob as File,
        'training_data/performance/metrics.json'
      );

      // Upload interaction patterns
      const patternsBlob = new Blob(
        [JSON.stringify({
          interactions: dummyData.interactionPatterns,
          losses: dummyData.lossPatterns
        }, null, 2)],
        { type: 'application/json' }
      );
      await storageService.uploadFile(
        patternsBlob as File,
        'training_data/patterns/analysis.json'
      );

      // Upload AI training examples
      const aiExamplesBlob = new Blob(
        [JSON.stringify(dummyData.aiTrainingExamples, null, 2)],
        { type: 'application/json' }
      );
      await storageService.uploadFile(
        aiExamplesBlob as File,
        'training_data/sales_calls/ai_examples.json'
      );

      return true;
    } catch (error) {
      console.error('Error uploading dummy data:', error);
      throw error;
    }
  },

  async loadDummyData() {
    try {
      const transcriptsUrl = await storageService.getFileUrl('training_data/sales_calls/transcripts.json');
      const contentUrl = await storageService.getFileUrl('training_data/content/library.json');
      const trainingUrl = await storageService.getFileUrl('training_data/content/training.json');
      const performanceUrl = await storageService.getFileUrl('training_data/performance/metrics.json');
      const patternsUrl = await storageService.getFileUrl('training_data/patterns/analysis.json');
      const aiExamplesUrl = await storageService.getFileUrl('training_data/sales_calls/ai_examples.json');

      const [
        transcripts,
        content,
        training,
        performance,
        patterns,
        aiExamples
      ] = await Promise.all([
        fetch(transcriptsUrl).then(res => res.json()),
        fetch(contentUrl).then(res => res.json()),
        fetch(trainingUrl).then(res => res.json()),
        fetch(performanceUrl).then(res => res.json()),
        fetch(patternsUrl).then(res => res.json()),
        fetch(aiExamplesUrl).then(res => res.json())
      ]);

      return {
        transcripts,
        content,
        training,
        performance,
        patterns,
        aiExamples
      };
    } catch (error) {
      console.error('Error loading dummy data:', error);
      throw error;
    }
  }
};