import React, { useState, useRef, useEffect } from 'react';
import { Bot, X, Send, Loader, BarChart2, FileText, Users, Brain } from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  data?: any;
}

interface Suggestion {
  id: string;
  text: string;
  category: 'metrics' | 'content' | 'comparison';
}

interface SalesforceDataChatProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SalesforceDataChat({ isOpen, onClose }: SalesforceDataChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: "Hello! I'm your Salesforce Data Assistant. I can help you analyze metrics, find relevant content, and compare team performance. What would you like to know?",
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const suggestions: Suggestion[] = [
    {
      id: '1',
      text: 'Show me the top performing reps this quarter',
      category: 'metrics'
    },
    {
      id: '2',
      text: 'Find training content about value selling',
      category: 'content'
    },
    {
      id: '3',
      text: 'Compare Enterprise vs Mid-Market conversion rates',
      category: 'comparison'
    },
    {
      id: '4',
      text: 'What are the key sales enablement trends?',
      category: 'content'
    }
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: content.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate AI response with mock data
    setTimeout(() => {
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: generateResponse(content),
        timestamp: new Date(),
        data: generateMockData(content)
      };
      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const generateResponse = (query: string): string => {
    if (query.toLowerCase().includes('top performing')) {
      return "Based on this quarter's data, here are the top performing reps by revenue:";
    } else if (query.toLowerCase().includes('value selling')) {
      return "I found these relevant resources about value selling in Confluence:";
    } else if (query.toLowerCase().includes('compare')) {
      return "Here's a comparison of the conversion rates:";
    }
    return "I'll help you analyze that. Here's what I found:";
  };

  const generateMockData = (query: string): any => {
    if (query.toLowerCase().includes('top performing')) {
      return {
        type: 'performance',
        data: [
          { name: 'Sarah Chen', revenue: 1250000, deals: 12 },
          { name: 'Michael Rodriguez', revenue: 980000, deals: 8 },
          { name: 'Alex Kim', revenue: 875000, deals: 10 }
        ]
      };
    }
    return null;
  };

  const renderMessageContent = (message: Message) => {
    if (message.data?.type === 'performance') {
      return (
        <div className="mt-2">
          <div className="bg-gray-50 rounded-lg p-4">
            {message.data.data.map((rep: any, index: number) => (
              <div key={index} className="mb-3 last:mb-0">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium">{rep.name}</span>
                  <span className="text-green-600">${(rep.revenue / 1000000).toFixed(2)}M</span>
                </div>
                <div className="relative pt-1">
                  <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
                    <div
                      style={{ width: `${(rep.revenue / 1250000) * 100}%` }}
                      className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-600"
                    />
                  </div>
                </div>
                <div className="text-sm text-gray-500 mt-1">
                  {rep.deals} deals closed
                </div>
              </div>
            ))}
          </div>
        </div>
      );
    }
    return null;
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage(inputValue);
    }
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 w-96 h-[600px] bg-white rounded-lg shadow-xl flex flex-col">
      <div className="p-4 border-b flex justify-between items-center bg-gray-50 rounded-t-lg">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-medium">Data Assistant</h3>
            <p className="text-xs text-gray-500">Salesforce & Confluence</p>
          </div>
        </div>
        <button 
          onClick={onClose}
          className="text-gray-400 hover:text-gray-600"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] p-3 rounded-lg ${
                message.type === 'user'
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-100 text-gray-800'
              }`}
            >
              <p className="text-sm">{message.content}</p>
              {renderMessageContent(message)}
              <p className="text-xs mt-1 opacity-70">
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex items-center space-x-2 text-gray-500">
            <Loader className="w-4 h-4 animate-spin" />
            <span className="text-sm">Assistant is thinking...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t bg-gray-50">
        <div className="flex flex-wrap gap-2 mb-4">
          {suggestions.map((suggestion) => (
            <button
              key={suggestion.id}
              onClick={() => handleSendMessage(suggestion.text)}
              className="text-xs px-3 py-1.5 bg-white border border-gray-200 rounded-full hover:bg-gray-100 transition-colors flex items-center space-x-1"
            >
              {suggestion.category === 'metrics' && <BarChart2 className="w-3 h-3" />}
              {suggestion.category === 'content' && <FileText className="w-3 h-3" />}
              {suggestion.category === 'comparison' && <Users className="w-3 h-3" />}
              <span>{suggestion.text}</span>
            </button>
          ))}
        </div>

        <div className="relative">
          <input
            ref={inputRef}
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask about metrics, content, or comparisons..."
            className="w-full pr-10 pl-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
          />
          <button
            onClick={() => handleSendMessage(inputValue)}
            disabled={!inputValue.trim() || isTyping}
            className={`absolute right-2 top-1/2 transform -translate-y-1/2 ${
              inputValue.trim() && !isTyping ? 'text-green-600' : 'text-gray-400'
            }`}
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}