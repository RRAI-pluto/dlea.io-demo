import { Router } from 'express';
import { TeamController } from '../controllers/teamController.js';
import { authMiddleware } from '../middleware/authMiddleware.js';

const router = Router();
const teamController = new TeamController();

router.get('/', authMiddleware, teamController.getTeams);
router.get('/:id', authMiddleware, teamController.getTeamById);
router.post('/', authMiddleware, teamController.createTeam);
router.put('/:id', authMiddleware, teamController.updateTeam);
router.delete('/:id', authMiddleware, teamController.deleteTeam);

// Team members
router.get('/:id/members', authMiddleware, teamController.getTeamMembers);
router.post('/:id/members', authMiddleware, teamController.addTeamMember);
router.delete('/:id/members/:userId', authMiddleware, teamController.removeTeamMember);

// Team metrics
router.get('/:id/metrics', authMiddleware, teamController.getTeamMetrics);
router.post('/:id/metrics', authMiddleware, teamController.updateTeamMetrics);

export default router;