import React from 'react';
import { Settings, User, Building, LogOut, Sun, Moon, Bell, HelpCircle } from 'lucide-react';

interface UserMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: string) => void;
  isDarkMode: boolean;
  onDarkModeToggle: () => void;
  onLogout: () => void;
}

export function UserMenu({ isOpen, onClose, onNavigate, isDarkMode, onDarkModeToggle, onLogout }: UserMenuProps) {
  if (!isOpen) return null;

  return (
    <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-3">
          <img
            src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
            alt="Profile"
            className="w-10 h-10 rounded-full"
          />
          <div>
            <p className="font-medium text-gray-900 dark:text-white">Dominic Lacy</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">VP of Enablement</p>
          </div>
        </div>
      </div>

      <div className="py-2">
        <button
          onClick={() => onNavigate('profile')}
          className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center"
        >
          <User className="w-4 h-4 mr-3" />
          Profile Settings
        </button>
        <button
          onClick={() => onNavigate('team-management')}
          className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center"
        >
          <Building className="w-4 h-4 mr-3" />
          Team Management
        </button>
        <button
          onClick={() => onNavigate('notifications')}
          className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center"
        >
          <Bell className="w-4 h-4 mr-3" />
          Notification Settings
        </button>
        <button
          onClick={() => onNavigate('settings')}
          className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center"
        >
          <Settings className="w-4 h-4 mr-3" />
          Account Settings
        </button>
      </div>

      <div className="border-t border-gray-200 dark:border-gray-700 py-2">
        <button
          onClick={onDarkModeToggle}
          className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center justify-between"
        >
          <div className="flex items-center">
            {isDarkMode ? (
              <Sun className="w-4 h-4 mr-3" />
            ) : (
              <Moon className="w-4 h-4 mr-3" />
            )}
            Dark Mode
          </div>
          <div className={`w-8 h-4 rounded-full relative ${isDarkMode ? 'bg-blue-600' : 'bg-gray-200'}`}>
            <div
              className={`w-3 h-3 bg-white rounded-full absolute top-0.5 transition-transform ${
                isDarkMode ? 'translate-x-4' : 'translate-x-0.5'
              }`}
            />
          </div>
        </button>
        <button
          onClick={() => onNavigate('help')}
          className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center"
        >
          <HelpCircle className="w-4 h-4 mr-3" />
          Help & Support
        </button>
      </div>

      <div className="border-t border-gray-200 dark:border-gray-700 py-2">
        <button
          onClick={onLogout}
          className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center"
        >
          <LogOut className="w-4 h-4 mr-3" />
          Sign Out
        </button>
      </div>
    </div>
  );
}