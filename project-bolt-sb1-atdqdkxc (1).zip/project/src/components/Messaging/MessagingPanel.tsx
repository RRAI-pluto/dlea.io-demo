import React, { useState, useRef, useEffect } from 'react';
import { Send, X, Users, Search, Settings, ExternalLink, RefreshCw, Plus, Mail, Hash } from 'lucide-react';
import { MessageList } from './MessageList';
import { ConversationList } from './ConversationList';
import { SlackIntegrationModal } from './SlackIntegrationModal';
import { SidePanel } from './SidePanel';

interface Message {
  id: string;
  content: string;
  sender: {
    id: string;
    name: string;
    avatar?: string;
    platform: 'dlea' | 'slack';
  };
  timestamp: Date;
  status: 'sent' | 'delivered' | 'read';
}

interface Conversation {
  id: string;
  name: string;
  avatar?: string;
  platform: 'dlea' | 'slack';
  lastMessage?: Message;
  unreadCount: number;
  channelName?: string;
}

interface MessagingPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export function MessagingPanel({ isOpen, onClose }: MessagingPanelProps) {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showSlackModal, setShowSlackModal] = useState(false);
  const [isSlackConnected, setIsSlackConnected] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [showSidePanel, setShowSidePanel] = useState(false);
  const [showNewConversation, setShowNewConversation] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen, selectedConversation]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = () => {
    if (!inputValue.trim() || !selectedConversation) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      content: inputValue.trim(),
      sender: {
        id: 'current-user',
        name: 'You',
        platform: 'dlea'
      },
      timestamp: new Date(),
      status: 'sent'
    };

    setMessages([...messages, newMessage]);
    setInputValue('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const syncWithSlack = async () => {
    setIsSyncing(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
    } catch (error) {
      console.error('Failed to sync with Slack:', error);
    } finally {
      setIsSyncing(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-4 right-4 w-[1000px] h-[600px] bg-white rounded-lg shadow-xl flex flex-col">
      <div className="p-4 border-b flex justify-between items-center bg-white rounded-t-lg">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
            <Users className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-medium">Messages</h3>
            <p className="text-xs text-gray-500">Connected with Slack</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          {isSlackConnected ? (
            <button
              onClick={syncWithSlack}
              disabled={isSyncing}
              className="flex items-center space-x-1 px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-100 rounded-lg"
            >
              <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>Sync</span>
            </button>
          ) : (
            <button
              onClick={() => setShowSlackModal(true)}
              className="flex items-center space-x-1 px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-100 rounded-lg"
            >
              <ExternalLink className="w-4 h-4" />
              <span>Connect Slack</span>
            </button>
          )}
          <button
            onClick={() => setShowSidePanel(!showSidePanel)}
            className={`p-2 rounded-lg hover:bg-gray-100 ${
              showSidePanel ? 'text-blue-600 bg-blue-50' : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            <Users className="w-5 h-5" />
          </button>
          <button
            onClick={() => setShowSlackModal(true)}
            className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
          >
            <Settings className="w-5 h-5" />
          </button>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex-1 flex">
        <div className="w-72 border-r flex flex-col">
          <div className="p-4">
            <div className="relative">
              <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search messages..."
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="flex space-x-2 mt-4">
              <button
                onClick={() => {
                  setShowNewConversation(true);
                  setShowSidePanel(true);
                }}
                className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Mail className="w-4 h-4" />
                <span>Message</span>
              </button>
              <button
                onClick={() => {
                  setShowNewConversation(false);
                  setShowSidePanel(true);
                }}
                className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50"
              >
                <Hash className="w-4 h-4" />
                <span>Channel</span>
              </button>
            </div>
          </div>
          <ConversationList
            conversations={conversations}
            selectedConversation={selectedConversation}
            onSelectConversation={setSelectedConversation}
            searchQuery={searchQuery}
          />
        </div>

        <div className="flex-1 flex flex-col">
          {selectedConversation ? (
            <>
              <MessageList
                messages={messages}
                conversation={selectedConversation}
                messagesEndRef={messagesEndRef}
              />
              <div className="p-4 border-t">
                <div className="relative">
                  <input
                    ref={inputRef}
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Type your message..."
                    className="w-full pr-10 pl-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    onClick={handleSendMessage}
                    disabled={!inputValue.trim()}
                    className={`absolute right-2 top-1/2 transform -translate-y-1/2 ${
                      inputValue.trim() ? 'text-blue-600' : 'text-gray-400'
                    }`}
                  >
                    <Send className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-gray-500">
              Select a conversation to start messaging
            </div>
          )}
        </div>

        {showSidePanel && (
          <SidePanel
            onClose={() => setShowSidePanel(false)}
            isNewConversation={showNewConversation}
            onStartConversation={(participants) => {
              console.log('Starting conversation with:', participants);
              setShowSidePanel(false);
            }}
            onCreateChannel={(channelData) => {
              console.log('Creating channel:', channelData);
              setShowSidePanel(false);
            }}
          />
        )}
      </div>

      {showSlackModal && (
        <SlackIntegrationModal
          onClose={() => setShowSlackModal(false)}
          onConnect={() => setIsSlackConnected(true)}
          isConnected={isSlackConnected}
        />
      )}
    </div>
  );
}