import React from 'react';
import { Check, CheckCheck } from 'lucide-react';

interface Message {
  id: string;
  content: string;
  sender: {
    id: string;
    name: string;
    avatar?: string;
    platform: 'dlea' | 'slack';
  };
  timestamp: Date;
  status: 'sent' | 'delivered' | 'read';
}

interface Conversation {
  id: string;
  name: string;
  avatar?: string;
  platform: 'dlea' | 'slack';
  lastMessage?: Message;
  unreadCount: number;
  channelName?: string;
}

interface ConversationListProps {
  conversations: Conversation[];
  selectedConversation: Conversation | null;
  onSelectConversation: (conversation: Conversation) => void;
  searchQuery: string;
}

export function ConversationList({
  conversations,
  selectedConversation,
  onSelectConversation,
  searchQuery
}: ConversationListProps) {
  const formatTime = (date: Date) => {
    const now = new Date();
    const messageDate = new Date(date);
    const diff = now.getTime() - messageDate.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (days === 0) {
      return messageDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (days === 1) {
      return 'Yesterday';
    } else if (days < 7) {
      return messageDate.toLocaleDateString([], { weekday: 'short' });
    } else {
      return messageDate.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };

  const filteredConversations = conversations.filter(conversation => {
    const searchLower = searchQuery.toLowerCase();
    return (
      conversation.name.toLowerCase().includes(searchLower) ||
      conversation.channelName?.toLowerCase().includes(searchLower) ||
      conversation.lastMessage?.content.toLowerCase().includes(searchLower)
    );
  });

  return (
    <div className="flex-1 overflow-y-auto">
      {filteredConversations.length === 0 ? (
        <div className="p-4 text-center text-gray-500">
          {searchQuery ? 'No conversations found' : 'No conversations yet'}
        </div>
      ) : (
        <div className="divide-y divide-gray-100">
          {filteredConversations.map((conversation) => (
            <button
              key={conversation.id}
              onClick={() => onSelectConversation(conversation)}
              className={`w-full p-4 text-left hover:bg-gray-50 transition-colors ${
                selectedConversation?.id === conversation.id ? 'bg-blue-50' : ''
              }`}
            >
              <div className="flex items-start space-x-3">
                <div className="relative">
                  <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
                    {conversation.avatar ? (
                      <img
                        src={conversation.avatar}
                        alt={conversation.name}
                        className="w-10 h-10 rounded-full"
                      />
                    ) : (
                      <span className="text-sm font-medium text-gray-600">
                        {conversation.name.charAt(0)}
                      </span>
                    )}
                  </div>
                  {conversation.platform === 'slack' && (
                    <div className="absolute -bottom-1 -right-1 px-1.5 py-0.5 bg-purple-100 rounded text-[10px] text-purple-600 font-medium">
                      Slack
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start">
                    <h4 className="font-medium text-sm truncate">
                      {conversation.platform === 'slack'
                        ? `#${conversation.channelName}`
                        : conversation.name}
                    </h4>
                    {conversation.lastMessage && (
                      <span className="text-xs text-gray-500 whitespace-nowrap ml-2">
                        {formatTime(conversation.lastMessage.timestamp)}
                      </span>
                    )}
                  </div>
                  {conversation.lastMessage && (
                    <p className="text-sm text-gray-600 truncate mt-1">
                      {conversation.lastMessage.sender.id === 'current-user' && (
                        <>
                          <span className="text-gray-400 mr-1">You:</span>
                          {conversation.lastMessage.content}
                        </>
                      )}
                    </p>
                  )}
                  <div className="flex items-center justify-between mt-1">
                    <div className="flex items-center space-x-1">
                      {conversation.lastMessage?.sender.id === 'current-user' && (
                        <span className="text-gray-400">
                          {conversation.lastMessage.status === 'read' ? (
                            <CheckCheck className="w-4 h-4 text-blue-600" />
                          ) : (
                            <Check className="w-4 h-4" />
                          )}
                        </span>
                      )}
                    </div>
                    {conversation.unreadCount > 0 && (
                      <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-xs font-medium rounded-full">
                        {conversation.unreadCount}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}