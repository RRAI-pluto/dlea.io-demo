#!/bin/bash

# Exit on error
set -e

# Load environment variables
source .env.production

# Function to display usage
usage() {
  echo "Usage: $0 -v <version> [-e <environment>]"
  echo "  -v: Version to rollback to"
  echo "  -e: Environment (default: production)"
  exit 1
}

# Parse command line arguments
while getopts "v:e:" opt; do
  case $opt in
    v) VERSION="$OPTARG";;
    e) ENV="$OPTARG";;
    *) usage;;
  esac
done

# Check required parameters
if [ -z "$VERSION" ]; then
  usage
fi

# Set default environment
ENV=${ENV:-production}

echo "Rolling back to version $VERSION in $ENV environment..."

# Stop the current deployment
ssh root@$DEPLOY_HOST << 'ENDSSH'
  cd /opt/dlea
  docker-compose down
ENDSSH

# Checkout specific version
ssh root@$DEPLOY_HOST << ENDSSH
  cd /opt/dlea
  git fetch --all
  git checkout $VERSION
ENDSSH

# Deploy the specified version
ssh root@$DEPLOY_HOST << 'ENDSSH'
  cd /opt/dlea
  docker-compose build
  docker-compose up -d
ENDSSH

echo "Rollback complete! Monitoring logs..."
ssh root@$DEPLOY_HOST "docker-compose logs -f"