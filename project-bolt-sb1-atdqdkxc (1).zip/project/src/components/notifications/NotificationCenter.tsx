import React, { useState, useEffect } from 'react';
import { Bell, X, Check, AlertTriangle, MessageSquare, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { dummyNotifications } from '../../services/dummyData';
import type { Notification } from '../../services/dummyData';

interface NotificationCenterProps {
  onNavigateToTicket?: (ticketId: string) => void;
}

export function NotificationCenter({ onNavigateToTicket }: NotificationCenterProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>(dummyNotifications);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    setUnreadCount(notifications.filter(n => n.status === 'unread').length);
  }, [notifications]);

  const handleMarkAsRead = (id: string) => {
    setNotifications(notifications.map(notification => 
      notification.id === id ? { ...notification, status: 'read' } : notification
    ));
  };

  const handleClearAll = () => {
    setNotifications([]);
  };

  const handleNotificationClick = (notification: Notification) => {
    if (notification.ticketId && onNavigateToTicket) {
      handleMarkAsRead(notification.id);
      onNavigateToTicket(notification.ticketId);
      setIsOpen(false);
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'alert':
        return <AlertTriangle className="w-4 h-4 text-red-600" />;
      case 'insight':
        return <MessageSquare className="w-4 h-4 text-blue-600" />;
      case 'message':
        return <MessageSquare className="w-4 h-4 text-purple-600" />;
      default:
        return <Bell className="w-4 h-4 text-gray-600" />;
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
      >
        <Bell className="w-6 h-6" />
        {unreadCount > 0 && (
          <span className="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2 bg-red-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
            {unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-96 bg-white rounded-lg shadow-xl border border-gray-200 z-50">
          <div className="p-4 border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Bell className="w-5 h-5 text-gray-600 mr-2" />
                <h3 className="font-medium">Notifications</h3>
                {unreadCount > 0 && (
                  <span className="ml-2 px-2 py-0.5 bg-blue-100 text-blue-800 text-xs font-medium rounded-full">
                    {unreadCount} new
                  </span>
                )}
              </div>
              <div className="flex items-center space-x-4">
                {notifications.length > 0 && (
                  <button
                    onClick={handleClearAll}
                    className="text-sm text-gray-600 hover:text-gray-800"
                  >
                    Clear all
                  </button>
                )}
                <button
                  onClick={() => setIsOpen(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          <div className="max-h-[400px] overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="p-8 text-center">
                <Check className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No new notifications</p>
              </div>
            ) : (
              <div className="divide-y divide-gray-100">
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    onClick={() => handleNotificationClick(notification)}
                    className={`p-4 hover:bg-gray-50 transition-colors ${
                      notification.status === 'unread' ? 'bg-blue-50' : ''
                    } ${notification.ticketId ? 'cursor-pointer' : ''}`}
                  >
                    <div className="flex items-start space-x-3">
                      <div className={`p-2 rounded-lg ${
                        notification.type === 'alert' ? 'bg-red-100' :
                        notification.type === 'insight' ? 'bg-blue-100' :
                        'bg-purple-100'
                      }`}>
                        {getNotificationIcon(notification.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                          <p className="font-medium text-sm truncate pr-4">{notification.title}</p>
                          <span className="text-xs text-gray-500 whitespace-nowrap">
                            {notification.createdAt.toLocaleTimeString([], { 
                              hour: '2-digit', 
                              minute: '2-digit' 
                            })}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mt-0.5 line-clamp-2">
                          {notification.description}
                        </p>
                        
                        {notification.metrics && (
                          <div className="mt-2 grid grid-cols-2 gap-2">
                            {notification.metrics.map((metric, index) => (
                              <div key={index} className="bg-gray-50 p-2 rounded">
                                <div className="flex items-center justify-between">
                                  <span className="text-xs text-gray-500">{metric.label}</span>
                                  <span className={`text-xs font-medium flex items-center ${
                                    metric.change > 0 ? 'text-green-600' : 'text-red-600'
                                  }`}>
                                    {metric.change > 0 ? (
                                      <ArrowUpRight className="w-3 h-3 mr-1" />
                                    ) : (
                                      <ArrowDownRight className="w-3 h-3 mr-1" />
                                    )}
                                    {Math.abs(metric.change)}%
                                  </span>
                                </div>
                                <p className="text-sm font-medium mt-0.5">{metric.value}</p>
                              </div>
                            ))}
                          </div>
                        )}

                        {notification.status === 'unread' && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleMarkAsRead(notification.id);
                            }}
                            className="mt-2 text-xs text-blue-600 hover:text-blue-700 font-medium"
                          >
                            Mark as read
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}