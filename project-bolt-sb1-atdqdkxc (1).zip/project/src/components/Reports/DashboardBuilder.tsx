import React, { useState } from 'react';
import { LayoutGrid, Plus, Save, Trash2, Settings, Move, Maximize2, Copy, X } from 'lucide-react';

interface DashboardReport {
  id: string;
  reportId: string;
  name: string;
  type: 'table' | 'bar' | 'line' | 'pie';
  size: 'small' | 'medium' | 'large';
  position: {
    x: number;
    y: number;
  };
}

interface Dashboard {
  id: string;
  name: string;
  description: string;
  reports: DashboardReport[];
  createdAt: Date;
  updatedAt: Date;
}

interface Report {
  id: string;
  name: string;
  description: string;
  type: 'table' | 'bar' | 'line' | 'pie';
}

export function DashboardBuilder() {
  const [dashboards, setDashboards] = useState<Dashboard[]>([]);
  const [selectedDashboard, setSelectedDashboard] = useState<Dashboard | null>(null);
  const [showNewDashboard, setShowNewDashboard] = useState(false);
  const [showAddReport, setShowAddReport] = useState(false);
  const [newDashboard, setNewDashboard] = useState({
    name: '',
    description: ''
  });

  // Sample available reports
  const availableReports: Report[] = [
    { id: '1', name: 'Revenue Overview', description: 'Monthly revenue breakdown', type: 'bar' },
    { id: '2', name: 'Sales Pipeline', description: 'Current pipeline status', type: 'pie' },
    { id: '3', name: 'Team Performance', description: 'Performance metrics by team', type: 'table' },
    { id: '4', name: 'Conversion Trends', description: 'Conversion rate over time', type: 'line' }
  ];

  const handleCreateDashboard = () => {
    if (!newDashboard.name) return;

    const dashboard: Dashboard = {
      id: Date.now().toString(),
      name: newDashboard.name,
      description: newDashboard.description,
      reports: [],
      createdAt: new Date(),
      updatedAt: new Date()
    };

    setDashboards([...dashboards, dashboard]);
    setSelectedDashboard(dashboard);
    setShowNewDashboard(false);
    setNewDashboard({ name: '', description: '' });
  };

  const handleAddReport = (report: Report) => {
    if (!selectedDashboard) return;

    const dashboardReport: DashboardReport = {
      id: Date.now().toString(),
      reportId: report.id,
      name: report.name,
      type: report.type,
      size: 'medium',
      position: {
        x: selectedDashboard.reports.length * 2,
        y: 0
      }
    };

    const updatedDashboard = {
      ...selectedDashboard,
      reports: [...selectedDashboard.reports, dashboardReport],
      updatedAt: new Date()
    };

    setDashboards(dashboards.map(d => 
      d.id === selectedDashboard.id ? updatedDashboard : d
    ));
    setSelectedDashboard(updatedDashboard);
    setShowAddReport(false);
  };

  const handleRemoveReport = (reportId: string) => {
    if (!selectedDashboard) return;

    const updatedDashboard = {
      ...selectedDashboard,
      reports: selectedDashboard.reports.filter(r => r.id !== reportId),
      updatedAt: new Date()
    };

    setDashboards(dashboards.map(d => 
      d.id === selectedDashboard.id ? updatedDashboard : d
    ));
    setSelectedDashboard(updatedDashboard);
  };

  const handleUpdateReportSize = (reportId: string, size: 'small' | 'medium' | 'large') => {
    if (!selectedDashboard) return;

    const updatedDashboard = {
      ...selectedDashboard,
      reports: selectedDashboard.reports.map(r => 
        r.id === reportId ? { ...r, size } : r
      ),
      updatedAt: new Date()
    };

    setDashboards(dashboards.map(d => 
      d.id === selectedDashboard.id ? updatedDashboard : d
    ));
    setSelectedDashboard(updatedDashboard);
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">Dashboards</h1>
              <p className="text-gray-600">Create and manage custom dashboards</p>
            </div>
            <div className="flex space-x-4">
              <select
                value={selectedDashboard?.id || ''}
                onChange={(e) => {
                  const dashboard = dashboards.find(d => d.id === e.target.value);
                  setSelectedDashboard(dashboard || null);
                }}
                className="px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Select Dashboard</option>
                {dashboards.map(dashboard => (
                  <option key={dashboard.id} value={dashboard.id}>
                    {dashboard.name}
                  </option>
                ))}
              </select>
              <button
                onClick={() => setShowNewDashboard(true)}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Plus className="w-5 h-5 mr-2" />
                New Dashboard
              </button>
            </div>
          </div>

          {showNewDashboard && (
            <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
              <h2 className="text-lg font-medium mb-4">Create New Dashboard</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Dashboard Name
                  </label>
                  <input
                    type="text"
                    value={newDashboard.name}
                    onChange={(e) => setNewDashboard({ ...newDashboard, name: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter dashboard name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    value={newDashboard.description}
                    onChange={(e) => setNewDashboard({ ...newDashboard, description: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter dashboard description"
                    rows={3}
                  />
                </div>
                <div className="flex justify-end space-x-4">
                  <button
                    onClick={() => setShowNewDashboard(false)}
                    className="px-4 py-2 text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleCreateDashboard}
                    disabled={!newDashboard.name}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  >
                    Create Dashboard
                  </button>
                </div>
              </div>
            </div>
          )}

          {selectedDashboard && (
            <div className="bg-white rounded-lg shadow-sm">
              <div className="p-6 border-b">
                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="text-xl font-bold">{selectedDashboard.name}</h2>
                    <p className="text-gray-600 mt-1">{selectedDashboard.description}</p>
                  </div>
                  <div className="flex items-center space-x-4">
                    <button
                      onClick={() => setShowAddReport(true)}
                      className="flex items-center px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Report
                    </button>
                    <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                      <Save className="w-4 h-4 mr-2" />
                      Save Layout
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-6">
                {selectedDashboard.reports.length === 0 ? (
                  <div className="text-center py-12">
                    <LayoutGrid className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No reports added yet</h3>
                    <p className="text-gray-500">Add reports to start building your dashboard</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-6">
                    {selectedDashboard.reports.map((report) => (
                      <div
                        key={report.id}
                        className={`bg-white border rounded-lg shadow-sm ${
                          report.size === 'large' ? 'col-span-2' :
                          report.size === 'small' ? 'col-span-1' : 'col-span-1'
                        }`}
                      >
                        <div className="p-4 border-b">
                          <div className="flex items-center justify-between">
                            <h3 className="font-medium">{report.name}</h3>
                            <div className="flex items-center space-x-2">
                              <button className="p-1 text-gray-400 hover:text-gray-600">
                                <Move className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleUpdateReportSize(report.id, 
                                  report.size === 'small' ? 'medium' :
                                  report.size === 'medium' ? 'large' : 'small'
                                )}
                                className="p-1 text-gray-400 hover:text-gray-600"
                              >
                                <Maximize2 className="w-4 h-4" />
                              </button>
                              <button className="p-1 text-gray-400 hover:text-gray-600">
                                <Settings className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleRemoveReport(report.id)}
                                className="p-1 text-gray-400 hover:text-red-500"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        </div>
                        <div className="p-4">
                          <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
                            [Report Visualization]
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Add Report Modal */}
          {showAddReport && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
              <div className="bg-white rounded-lg w-[600px] max-h-[80vh] overflow-y-auto">
                <div className="p-6 border-b">
                  <div className="flex justify-between items-center">
                    <h2 className="text-xl font-bold">Add Report to Dashboard</h2>
                    <button
                      onClick={() => setShowAddReport(false)}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <X className="w-6 h-6" />
                    </button>
                  </div>
                </div>

                <div className="p-6">
                  <div className="space-y-4">
                    {availableReports.map((report) => (
                      <button
                        key={report.id}
                        onClick={() => handleAddReport(report)}
                        className="w-full flex items-center justify-between p-4 border rounded-lg hover:border-blue-500 transition-colors"
                      >
                        <div>
                          <h3 className="font-medium">{report.name}</h3>
                          <p className="text-sm text-gray-500">{report.description}</p>
                        </div>
                        <Plus className="w-5 h-5 text-gray-400" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}