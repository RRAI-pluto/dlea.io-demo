import React, { useState } from 'react';
import { X, Check, AlertTriangle, RefreshCw } from 'lucide-react';

interface SlackIntegrationModalProps {
  onClose: () => void;
  onConnect: () => void;
  isConnected: boolean;
}

export function SlackIntegrationModal({ onClose, onConnect, isConnected }: SlackIntegrationModalProps) {
  const [isConnecting, setIsConnecting] = useState(false);
  const [workspaceUrl, setWorkspaceUrl] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleConnect = async () => {
    if (!workspaceUrl) {
      setError('Please enter your Slack workspace URL');
      return;
    }

    setIsConnecting(true);
    setError(null);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      onConnect();
      onClose();
    } catch (err) {
      setError('Failed to connect to Slack. Please try again.');
    } finally {
      setIsConnecting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-[500px] max-h-[80vh] overflow-y-auto">
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Slack Integration</h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-6">
          {isConnected ? (
            <div className="space-y-4">
              <div className="flex items-center space-x-3 text-green-600 bg-green-50 p-4 rounded-lg">
                <Check className="w-5 h-5" />
                <span className="font-medium">Connected to Slack</span>
              </div>
              <div>
                <h3 className="font-medium mb-2">Connected Workspace</h3>
                <p className="text-gray-600">your-workspace.slack.com</p>
              </div>
              <div>
                <h3 className="font-medium mb-2">Permissions</h3>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• Read messages and channels</li>
                  <li>• Send messages as dlea.io</li>
                  <li>• Access user information</li>
                </ul>
              </div>
              <div className="flex justify-end space-x-4">
                <button
                  onClick={onClose}
                  className="px-4 py-2 text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    // Implement disconnect logic
                  }}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  Disconnect
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-gray-600">
                Connect your Slack workspace to send and receive messages directly from dlea.io.
              </p>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Slack Workspace URL
                </label>
                <input
                  type="text"
                  value={workspaceUrl}
                  onChange={(e) => setWorkspaceUrl(e.target.value)}
                  placeholder="your-workspace.slack.com"
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {error && (
                <div className="flex items-center space-x-2 text-red-600 bg-red-50 p-4 rounded-lg">
                  <AlertTriangle className="w-5 h-5" />
                  <span>{error}</span>
                </div>
              )}

              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-medium mb-2">Required Permissions</h3>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• Read messages and channels</li>
                  <li>• Send messages as dlea.io</li>
                  <li>• Access user information</li>
                </ul>
              </div>

              <div className="flex justify-end space-x-4">
                <button
                  onClick={onClose}
                  className="px-4 py-2 text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConnect}
                  disabled={isConnecting}
                  className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  {isConnecting ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Connecting...
                    </>
                  ) : (
                    'Connect to Slack'
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}