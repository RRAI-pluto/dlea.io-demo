import axios from 'axios';

interface ApolloConfig {
  apiKey: string;
  organizationId: string;
}

class ApolloAPI {
  private config: ApolloConfig;
  private axiosInstance;

  constructor(config: ApolloConfig) {
    this.config = config;
    this.axiosInstance = axios.create({
      baseURL: 'https://api.apollo.io/v1',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.apiKey}`
      }
    });
  }

  async testConnection() {
    try {
      const response = await this.axiosInstance.get('/auth/health');
      return response.data;
    } catch (error) {
      throw new Error('Failed to connect to Apollo');
    }
  }

  async searchPeople(query: {
    q_organization_domains?: string[];
    q_titles?: string[];
    q_locations?: string[];
    page?: number;
    per_page?: number;
  }) {
    try {
      const response = await this.axiosInstance.post('/people/search', {
        ...query,
        organization_id: this.config.organizationId
      });
      return response.data;
    } catch (error) {
      throw new Error('Failed to search people in Apollo');
    }
  }

  async enrichContact(email: string) {
    try {
      const response = await this.axiosInstance.post('/people/match', {
        email,
        organization_id: this.config.organizationId
      });
      return response.data;
    } catch (error) {
      throw new Error('Failed to enrich contact data');
    }
  }

  async getAccount(domain: string) {
    try {
      const response = await this.axiosInstance.post('/organizations/enrich', {
        domain,
        organization_id: this.config.organizationId
      });
      return response.data;
    } catch (error) {
      throw new Error('Failed to get account details');
    }
  }

  async getSequenceAnalytics(sequenceId: string) {
    try {
      const response = await this.axiosInstance.get(`/sequences/${sequenceId}/analytics`, {
        params: { organization_id: this.config.organizationId }
      });
      return response.data;
    } catch (error) {
      throw new Error('Failed to get sequence analytics');
    }
  }

  async getTeamStats() {
    try {
      const response = await this.axiosInstance.get('/team/stats', {
        params: { organization_id: this.config.organizationId }
      });
      return response.data;
    } catch (error) {
      throw new Error('Failed to get team statistics');
    }
  }

  async getApiUsage() {
    try {
      const response = await this.axiosInstance.get('/usage', {
        params: { organization_id: this.config.organizationId }
      });
      return response.data;
    } catch (error) {
      throw new Error('Failed to get API usage data');
    }
  }
}

export default ApolloAPI;