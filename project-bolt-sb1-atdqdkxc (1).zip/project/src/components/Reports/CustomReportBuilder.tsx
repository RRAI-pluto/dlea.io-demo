import React, { useState } from 'react';
import { BarChart2, Plus, Save, Trash2, Settings, Filter, Calendar, Download, ChevronDown } from 'lucide-react';

interface ReportField {
  id: string;
  name: string;
  label: string;
  type: 'number' | 'text' | 'date' | 'boolean';
  aggregation?: 'sum' | 'avg' | 'count' | 'min' | 'max';
  filter?: {
    operator: 'equals' | 'contains' | 'greater' | 'less' | 'between';
    value: any;
  };
}

interface ReportConfig {
  id: string;
  name: string;
  description: string;
  type: 'table' | 'bar' | 'line' | 'pie';
  fields: ReportField[];
  filters: any[];
  groupBy?: string[];
  sortBy?: { field: string; direction: 'asc' | 'desc' }[];
  createdAt: Date;
  updatedAt: Date;
}

export function CustomReportBuilder() {
  const [reports, setReports] = useState<ReportConfig[]>([]);
  const [showNewReport, setShowNewReport] = useState(false);
  const [selectedReport, setSelectedReport] = useState<ReportConfig | null>(null);
  const [reportName, setReportName] = useState('');
  const [reportDescription, setReportDescription] = useState('');
  const [reportType, setReportType] = useState<'table' | 'bar' | 'line' | 'pie'>('table');
  const [selectedFields, setSelectedFields] = useState<ReportField[]>([]);
  const [timeRange, setTimeRange] = useState('30d');

  // Available fields for reports
  const availableFields: ReportField[] = [
    { id: '1', name: 'revenue', label: 'Revenue', type: 'number' },
    { id: '2', name: 'deals_closed', label: 'Deals Closed', type: 'number' },
    { id: '3', name: 'win_rate', label: 'Win Rate', type: 'number' },
    { id: '4', name: 'team', label: 'Team', type: 'text' },
    { id: '5', name: 'close_date', label: 'Close Date', type: 'date' },
    { id: '6', name: 'deal_size', label: 'Deal Size', type: 'number' },
    { id: '7', name: 'stage', label: 'Stage', type: 'text' },
    { id: '8', name: 'product', label: 'Product', type: 'text' }
  ];

  const handleCreateReport = () => {
    if (!reportName) return;

    const newReport: ReportConfig = {
      id: Date.now().toString(),
      name: reportName,
      description: reportDescription,
      type: reportType,
      fields: selectedFields,
      filters: [],
      createdAt: new Date(),
      updatedAt: new Date()
    };

    setReports([...reports, newReport]);
    setSelectedReport(newReport);
    setShowNewReport(false);
    resetForm();
  };

  const handleAddField = (field: ReportField) => {
    setSelectedFields([...selectedFields, { ...field }]);
  };

  const handleRemoveField = (fieldId: string) => {
    setSelectedFields(selectedFields.filter(f => f.id !== fieldId));
  };

  const handleUpdateFieldAggregation = (fieldId: string, aggregation: string) => {
    setSelectedFields(selectedFields.map(field => {
      if (field.id === fieldId) {
        return { ...field, aggregation: aggregation as any };
      }
      return field;
    }));
  };

  const resetForm = () => {
    setReportName('');
    setReportDescription('');
    setReportType('table');
    setSelectedFields([]);
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">Custom Reports</h1>
              <p className="text-gray-600">Build and manage custom reports</p>
            </div>
            <div className="flex space-x-4">
              <div className="relative">
                <select
                  value={timeRange}
                  onChange={(e) => setTimeRange(e.target.value)}
                  className="appearance-none bg-white border border-gray-200 rounded-lg px-4 py-2 pr-8"
                >
                  <option value="7d">Last 7 days</option>
                  <option value="30d">Last 30 days</option>
                  <option value="90d">Last 90 days</option>
                  <option value="1y">Last year</option>
                </select>
                <ChevronDown className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 transform -translate-y-1/2" />
              </div>
              <button
                onClick={() => setShowNewReport(true)}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Plus className="w-5 h-5 mr-2" />
                New Report
              </button>
            </div>
          </div>

          {showNewReport && (
            <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
              <h2 className="text-lg font-medium mb-4">Create New Report</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Report Name
                  </label>
                  <input
                    type="text"
                    value={reportName}
                    onChange={(e) => setReportName(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter report name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    value={reportDescription}
                    onChange={(e) => setReportDescription(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter report description"
                    rows={3}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Report Type
                  </label>
                  <select
                    value={reportType}
                    onChange={(e) => setReportType(e.target.value as any)}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="table">Table</option>
                    <option value="bar">Bar Chart</option>
                    <option value="line">Line Chart</option>
                    <option value="pie">Pie Chart</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Fields
                  </label>
                  <div className="space-y-2">
                    {selectedFields.map((field) => (
                      <div
                        key={field.id}
                        className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                      >
                        <div className="flex items-center space-x-3">
                          <span className="font-medium text-sm">{field.label}</span>
                          {field.type === 'number' && (
                            <select
                              value={field.aggregation || ''}
                              onChange={(e) => handleUpdateFieldAggregation(field.id, e.target.value)}
                              className="text-sm px-2 py-1 border border-gray-200 rounded"
                            >
                              <option value="">No Aggregation</option>
                              <option value="sum">Sum</option>
                              <option value="avg">Average</option>
                              <option value="min">Minimum</option>
                              <option value="max">Maximum</option>
                            </select>
                          )}
                        </div>
                        <button
                          onClick={() => handleRemoveField(field.id)}
                          className="text-gray-400 hover:text-red-500"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                  <div className="mt-2">
                    <select
                      onChange={(e) => {
                        const field = availableFields.find(f => f.id === e.target.value);
                        if (field) handleAddField(field);
                      }}
                      value=""
                      className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Add field...</option>
                      {availableFields
                        .filter(field => !selectedFields.find(f => f.id === field.id))
                        .map(field => (
                          <option key={field.id} value={field.id}>
                            {field.label}
                          </option>
                        ))}
                    </select>
                  </div>
                </div>

                <div className="flex justify-end space-x-4 pt-4">
                  <button
                    onClick={() => {
                      setShowNewReport(false);
                      resetForm();
                    }}
                    className="px-4 py-2 text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleCreateReport}
                    disabled={!reportName || selectedFields.length === 0}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  >
                    Create Report
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Reports Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reports.map((report) => (
              <div
                key={report.id}
                className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-blue-50 rounded-lg">
                        <BarChart2 className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-medium">{report.name}</h3>
                        <p className="text-sm text-gray-500">{report.description}</p>
                      </div>
                    </div>
                    <button className="text-gray-400 hover:text-gray-600">
                      <Settings className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="space-y-3">
                    {report.fields.map((field, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">{field.label}</span>
                        {field.aggregation && (
                          <span className="text-sm font-medium text-blue-600">
                            {field.aggregation}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="flex justify-between mt-6">
                    <button className="flex items-center px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-50 rounded-lg">
                      <Settings className="w-4 h-4 mr-2" />
                      Configure
                    </button>
                    <button className="flex items-center px-3 py-1.5 text-sm text-blue-600 hover:bg-blue-50 rounded-lg">
                      <Download className="w-4 h-4 mr-2" />
                      Export
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}