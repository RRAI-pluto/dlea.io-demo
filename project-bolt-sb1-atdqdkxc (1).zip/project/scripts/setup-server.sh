#!/bin/bash

# Exit on error
set -e

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Install Docker Compose
curl -L "https://github.com/docker/compose/releases/download/v2.24.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

# Install Certbot
apt-get update
apt-get install -y certbot python3-certbot-nginx

# Set up SSL certificate
certbot certonly --nginx -d dlea.io -d www.dlea.io

# Create app directory
mkdir -p /opt/dlea
chown -R $USER:$USER /opt/dlea

# Set up firewall
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable