import axios from 'axios';

interface ConfluenceConfig {
  baseUrl: string;
  email: string;
  apiKey: string;
}

interface ConfluencePage {
  id: string;
  type: 'page';
  status: 'current' | 'draft';
  title: string;
  body: {
    storage: {
      value: string;
      representation: 'storage' | 'view';
    };
  };
  version: {
    number: number;
  };
  _links: {
    webui: string;
  };
}

interface ConfluenceSpace {
  id: string;
  key: string;
  name: string;
  type: 'global' | 'personal';
}

interface SearchResult {
  results: Array<{
    content: ConfluencePage;
    title: string;
    excerpt: string;
    url: string;
    lastModified: string;
  }>;
  start: number;
  limit: number;
  size: number;
}

class ConfluenceAPI {
  private config: ConfluenceConfig;
  private axiosInstance;

  constructor(config: ConfluenceConfig) {
    this.config = config;
    this.axiosInstance = axios.create({
      baseURL: `${config.baseUrl}/wiki/rest/api`,
      auth: {
        username: config.email,
        password: config.apiKey
      },
      headers: {
        'Content-Type': 'application/json'
      }
    });
  }

  // Get a specific page by ID
  async getPage(pageId: string): Promise<ConfluencePage> {
    try {
      const response = await this.axiosInstance.get(`/content/${pageId}`, {
        params: {
          expand: 'body.storage,version'
        }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching Confluence page:', error);
      throw error;
    }
  }

  // Search for content
  async searchContent(query: string, spaceKey?: string): Promise<SearchResult> {
    try {
      const params: Record<string, string> = {
        cql: `text ~ "${query}"${spaceKey ? ` AND space = "${spaceKey}"` : ''}`
      };

      const response = await this.axiosInstance.get('/search', { params });
      return response.data;
    } catch (error) {
      console.error('Error searching Confluence content:', error);
      throw error;
    }
  }

  // Get all spaces
  async getSpaces(): Promise<ConfluenceSpace[]> {
    try {
      const response = await this.axiosInstance.get('/space');
      return response.data.results;
    } catch (error) {
      console.error('Error fetching Confluence spaces:', error);
      throw error;
    }
  }

  // Create a new page
  async createPage(spaceKey: string, title: string, content: string, parentId?: string): Promise<ConfluencePage> {
    try {
      const payload = {
        type: 'page',
        title,
        space: { key: spaceKey },
        body: {
          storage: {
            value: content,
            representation: 'storage'
          }
        },
        ...(parentId && { ancestors: [{ id: parentId }] })
      };

      const response = await this.axiosInstance.post('/content', payload);
      return response.data;
    } catch (error) {
      console.error('Error creating Confluence page:', error);
      throw error;
    }
  }

  // Update an existing page
  async updatePage(pageId: string, title: string, content: string, version: number): Promise<ConfluencePage> {
    try {
      const payload = {
        version: { number: version + 1 },
        title,
        type: 'page',
        body: {
          storage: {
            value: content,
            representation: 'storage'
          }
        }
      };

      const response = await this.axiosInstance.put(`/content/${pageId}`, payload);
      return response.data;
    } catch (error) {
      console.error('Error updating Confluence page:', error);
      throw error;
    }
  }

  // Get page history
  async getPageHistory(pageId: string) {
    try {
      const response = await this.axiosInstance.get(`/content/${pageId}/history`);
      return response.data;
    } catch (error) {
      console.error('Error fetching page history:', error);
      throw error;
    }
  }

  // Get page children
  async getPageChildren(pageId: string) {
    try {
      const response = await this.axiosInstance.get(`/content/${pageId}/child/page`);
      return response.data;
    } catch (error) {
      console.error('Error fetching page children:', error);
      throw error;
    }
  }
}

export default ConfluenceAPI;