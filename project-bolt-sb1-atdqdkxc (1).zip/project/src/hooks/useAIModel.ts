import { useState } from 'react';
import { aiModelService, AIModel } from '../services/aiModelService';

export function useAIModel() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const createModel = async (model: Omit<AIModel, 'id' | 'created_at' | 'updated_at'>) => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await aiModelService.createModel(model);
      return result;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to create model'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const generateResponse = async (modelId: string, input: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await aiModelService.generateResponse(modelId, input);
      return response;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to generate response'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const getModelPerformance = async (modelId: string, timeRange: { start: Date; end: Date }) => {
    setIsLoading(true);
    setError(null);
    try {
      const performance = await aiModelService.getModelPerformance(modelId, timeRange);
      return performance;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to get model performance'));
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    createModel,
    generateResponse,
    getModelPerformance,
    isLoading,
    error
  };
}