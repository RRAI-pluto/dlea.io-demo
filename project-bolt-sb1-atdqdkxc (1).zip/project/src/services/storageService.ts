import { supabase } from '../lib/supabase';

export interface StorageFile {
  path: string;
  size: number;
  type: string;
  created_at: string;
  updated_at: string;
  metadata?: Record<string, any>;
}

export const storageService = {
  // Upload file to storage
  async uploadFile(file: File, path: string): Promise<StorageFile> {
    try {
      const { data, error } = await supabase.storage
        .from('dlea.io')
        .upload(path, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error uploading file:', error);
      throw error;
    }
  },

  // Get file URL
  async getFileUrl(path: string): Promise<string> {
    try {
      const { data } = supabase.storage
        .from('dlea.io')
        .getPublicUrl(path);

      return data.publicUrl;
    } catch (error) {
      console.error('Error getting file URL:', error);
      throw error;
    }
  },

  // List files in a folder
  async listFiles(folder: string): Promise<StorageFile[]> {
    try {
      const { data, error } = await supabase.storage
        .from('dlea.io')
        .list(folder);

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error listing files:', error);
      throw error;
    }
  },

  // Delete file
  async deleteFile(path: string): Promise<void> {
    try {
      const { error } = await supabase.storage
        .from('dlea.io')
        .remove([path]);

      if (error) throw error;
    } catch (error) {
      console.error('Error deleting file:', error);
      throw error;
    }
  },

  // Move/rename file
  async moveFile(fromPath: string, toPath: string): Promise<StorageFile> {
    try {
      const { data, error } = await supabase.storage
        .from('dlea.io')
        .move(fromPath, toPath);

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error moving file:', error);
      throw error;
    }
  },

  // Create folder
  async createFolder(path: string): Promise<void> {
    try {
      const { error } = await supabase.storage
        .from('dlea.io')
        .upload(`${path}/.keep`, new Blob(['']));

      if (error) throw error;
    } catch (error) {
      console.error('Error creating folder:', error);
      throw error;
    }
  },

  // Get file metadata
  async getFileMetadata(path: string): Promise<StorageFile> {
    try {
      const { data, error } = await supabase.storage
        .from('dlea.io')
        .list('', {
          limit: 1,
          offset: 0,
          search: path
        });

      if (error) throw error;
      return data[0];
    } catch (error) {
      console.error('Error getting file metadata:', error);
      throw error;
    }
  }
};