/*
  # Fix Roles and Permissions Schema

  1. Changes
    - Restructure roles table and policies to avoid recursion
    - Add safe role checking functions
    - Update profile role handling
    - Add proper RLS policies

  2. Security
    - Enable RLS on roles table
    - Add policies for role access
    - Add secure permission checking function
*/

-- Create roles table if it doesn't exist
CREATE TABLE IF NOT EXISTS roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text,
  permissions jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add role_id to profiles if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'role_id'
  ) THEN
    ALTER TABLE profiles ADD COLUMN role_id uuid REFERENCES roles(id);
  END IF;
END $$;

-- Enable RLS
ALTER TABLE roles ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Super admins can manage roles" ON roles;
DROP POLICY IF EXISTS "Admins can read roles" ON roles;
DROP POLICY IF EXISTS "Managers can read roles" ON roles;
DROP POLICY IF EXISTS "Users can read their own role" ON roles;

-- Create function to safely check user role
CREATE OR REPLACE FUNCTION get_user_role_name()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  role_name text;
BEGIN
  SELECT r.name INTO role_name
  FROM roles r
  INNER JOIN profiles p ON p.role_id = r.id
  WHERE p.id = auth.uid();
  
  RETURN role_name;
END;
$$;

-- Create safer role-based policies
CREATE POLICY "Allow super admins full access"
ON roles
FOR ALL
TO authenticated
USING (
  get_user_role_name() = 'Super Admin'
);

CREATE POLICY "Allow admins to read roles"
ON roles
FOR SELECT
TO authenticated
USING (
  get_user_role_name() IN ('Admin', 'Super Admin')
);

CREATE POLICY "Allow users to read their assigned role"
ON roles
FOR SELECT
TO authenticated
USING (
  id IN (
    SELECT role_id 
    FROM profiles 
    WHERE id = auth.uid()
  )
);

-- Function to check permissions safely
CREATE OR REPLACE FUNCTION check_permission(feature text, action text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_role_permissions jsonb;
BEGIN
  SELECT r.permissions INTO user_role_permissions
  FROM roles r
  INNER JOIN profiles p ON p.role_id = r.id
  WHERE p.id = auth.uid();

  -- Super Admin override
  IF get_user_role_name() = 'Super Admin' THEN
    RETURN true;
  END IF;

  -- Check permissions
  IF user_role_permissions IS NULL THEN
    RETURN false;
  END IF;

  -- Check all_data permission first
  IF (user_role_permissions->>'all_data')::boolean = true THEN
    RETURN true;
  END IF;

  -- Check specific feature permission
  RETURN COALESCE((user_role_permissions->feature->>action)::boolean, false);
END;
$$;

-- Insert default roles if they don't exist
INSERT INTO roles (name, description, permissions)
SELECT 'Super Admin', 'Full access to all features and data', '{
  "dashboard": {"read": true, "write": true},
  "funnel": {"read": true, "write": true},
  "config": {"read": true, "write": true},
  "users": {"read": true, "write": true},
  "tickets": {"read": true, "write": true},
  "reports": {"read": true, "write": true},
  "settings": {"read": true, "write": true},
  "sales_planner": {"read": true, "write": true},
  "all_data": true
}'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM roles WHERE name = 'Super Admin');

INSERT INTO roles (name, description, permissions)
SELECT 'Admin', 'Access to most features except sales planner', '{
  "dashboard": {"read": true, "write": true},
  "funnel": {"read": true, "write": true},
  "config": {"read": true, "write": true},
  "users": {"read": true, "write": true},
  "tickets": {"read": true, "write": true},
  "reports": {"read": true, "write": true},
  "settings": {"read": true, "write": true},
  "sales_planner": {"read": false, "write": false},
  "all_data": true
}'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM roles WHERE name = 'Admin');

INSERT INTO roles (name, description, permissions)
SELECT 'Manager', 'Access to team data and funnels', '{
  "dashboard": {"read": true, "write": true},
  "funnel": {"read": true, "write": true},
  "config": {"read": true, "write": true},
  "users": {"read": "team", "write": false},
  "tickets": {"read": "team", "write": true},
  "reports": {"read": true, "write": true},
  "settings": {"read": true, "write": false},
  "sales_planner": {"read": false, "write": false},
  "all_data": false
}'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM roles WHERE name = 'Manager');

INSERT INTO roles (name, description, permissions)
SELECT 'User', 'Access to own data and funnels', '{
  "dashboard": {"read": true, "write": false},
  "funnel": {"read": "own", "write": "own"},
  "config": {"read": true, "write": false},
  "users": {"read": "own", "write": false},
  "tickets": {"read": "own", "write": true},
  "reports": {"read": true, "write": false},
  "settings": {"read": false, "write": false},
  "sales_planner": {"read": false, "write": false},
  "all_data": false
}'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM roles WHERE name = 'User');

-- Update or create the handle_new_user function
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, role_id)
  VALUES (
    new.id,
    new.raw_user_meta_data->>'full_name',
    (SELECT id FROM roles WHERE name = 'User' LIMIT 1)
  );
  RETURN new;
END;
$$;

-- Recreate the trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();