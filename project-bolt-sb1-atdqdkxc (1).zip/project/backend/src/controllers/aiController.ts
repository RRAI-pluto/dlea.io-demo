import { Request, Response } from 'express';
import { OpenAIService } from '../services/openaiService';
import { AIModelService } from '../services/aiModelService';
import { DatabaseService } from '../services/databaseService';

export class AIController {
  private openaiService: OpenAIService;
  private modelService: AIModelService;
  private dbService: DatabaseService;

  constructor() {
    this.openaiService = new OpenAIService();
    this.modelService = new AIModelService();
    this.dbService = new DatabaseService();
  }

  handleQuery = async (req: Request, res: Response) => {
    try {
      const { query, modelId, context } = req.body;

      // Get relevant data from database
      const data = await this.dbService.fetchRelevantData(context);

      // Generate response using AI
      const response = await this.modelService.generateResponse(modelId, {
        query,
        context,
        data
      });

      // Store interaction
      await this.dbService.storeInteraction({
        modelId,
        input: query,
        output: response.content,
        metadata: {
          context,
          timestamp: new Date().toISOString(),
          userId: req.user?.id
        }
      });

      res.json({ success: true, data: response });
    } catch (error) {
      console.error('Error handling AI query:', error);
      res.status(500).json({ 
        success: false, 
        error: error instanceof Error ? error.message : 'Internal server error' 
      });
    }
  };

  // Model management endpoints
  getModels = async (req: Request, res: Response) => {
    try {
      const models = await this.modelService.getModels();
      res.json({ success: true, data: models });
    } catch (error) {
      console.error('Error getting AI models:', error);
      res.status(500).json({ success: false, error: 'Failed to get models' });
    }
  };

  createModel = async (req: Request, res: Response) => {
    try {
      const model = await this.modelService.createModel(req.body);
      res.status(201).json({ success: true, data: model });
    } catch (error) {
      console.error('Error creating AI model:', error);
      res.status(500).json({ success: false, error: 'Failed to create model' });
    }
  };

  getModel = async (req: Request, res: Response) => {
    try {
      const model = await this.modelService.getModel(req.params.id);
      if (!model) {
        return res.status(404).json({ success: false, error: 'Model not found' });
      }
      res.json({ success: true, data: model });
    } catch (error) {
      console.error('Error getting AI model:', error);
      res.status(500).json({ success: false, error: 'Failed to get model' });
    }
  };

  updateModel = async (req: Request, res: Response) => {
    try {
      const model = await this.modelService.updateModel(req.params.id, req.body);
      res.json({ success: true, data: model });
    } catch (error) {
      console.error('Error updating AI model:', error);
      res.status(500).json({ success: false, error: 'Failed to update model' });
    }
  };

  deleteModel = async (req: Request, res: Response) => {
    try {
      await this.modelService.deleteModel(req.params.id);
      res.json({ success: true, message: 'Model deleted successfully' });
    } catch (error) {
      console.error('Error deleting AI model:', error);
      res.status(500).json({ success: false, error: 'Failed to delete model' });
    }
  };

  // Performance monitoring endpoints
  getModelPerformance = async (req: Request, res: Response) => {
    try {
      const { start, end } = req.query;
      const performance = await this.modelService.getModelPerformance(
        req.params.id,
        {
          start: new Date(start as string),
          end: new Date(end as string)
        }
      );
      res.json({ success: true, data: performance });
    } catch (error) {
      console.error('Error getting model performance:', error);
      res.status(500).json({ success: false, error: 'Failed to get performance data' });
    }
  };

  getModelInteractions = async (req: Request, res: Response) => {
    try {
      const interactions = await this.modelService.getModelInteractions(req.params.id);
      res.json({ success: true, data: interactions });
    } catch (error) {
      console.error('Error getting model interactions:', error);
      res.status(500).json({ success: false, error: 'Failed to get interactions' });
    }
  };

  // Specialized endpoints
  analyzeSalesCall = async (req: Request, res: Response) => {
    try {
      const { transcript } = req.body;
      const analysis = await this.openaiService.analyzeSalesCall(transcript);
      res.json({ success: true, data: analysis });
    } catch (error) {
      console.error('Error analyzing sales call:', error);
      res.status(500).json({ success: false, error: 'Failed to analyze sales call' });
    }
  };

  generateContentSuggestions = async (req: Request, res: Response) => {
    try {
      const { context } = req.body;
      const suggestions = await this.openaiService.generateContentSuggestions(context);
      res.json({ success: true, data: suggestions });
    } catch (error) {
      console.error('Error generating content suggestions:', error);
      res.status(500).json({ success: false, error: 'Failed to generate suggestions' });
    }
  };

  analyzeDealRisks = async (req: Request, res: Response) => {
    try {
      const { dealData } = req.body;
      const analysis = await this.openaiService.analyzeDealRisks(dealData);
      res.json({ success: true, data: analysis });
    } catch (error) {
      console.error('Error analyzing deal risks:', error);
      res.status(500).json({ success: false, error: 'Failed to analyze risks' });
    }
  };

  generateCoachingInsights = async (req: Request, res: Response) => {
    try {
      const { performanceData } = req.body;
      const insights = await this.openaiService.generateCoachingInsights(performanceData);
      res.json({ success: true, data: insights });
    } catch (error) {
      console.error('Error generating coaching insights:', error);
      res.status(500).json({ success: false, error: 'Failed to generate insights' });
    }
  };
}